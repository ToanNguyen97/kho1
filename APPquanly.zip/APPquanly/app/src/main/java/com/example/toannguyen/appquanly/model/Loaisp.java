package com.example.toannguyen.appquanly.model;

public class Loaisp {
    public int id ;
    public String tenlsp ;
    public String hinhanhslp;

    public Loaisp(int id, String tenlsp, String hinhanhslp) {
        this.id = id;
        this.tenlsp = tenlsp;
        this.hinhanhslp = hinhanhslp;
    }

    public int getId() {
        return id;
    }

    public String getTenlsp() {
        return tenlsp;
    }

    public String getHinhanhslp() {
        return hinhanhslp;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTenlsp(String tenlsp) {
        this.tenlsp = tenlsp;
    }

    public void setHinhanhslp(String hinhanhslp) {
        this.hinhanhslp = hinhanhslp;
    }
}
