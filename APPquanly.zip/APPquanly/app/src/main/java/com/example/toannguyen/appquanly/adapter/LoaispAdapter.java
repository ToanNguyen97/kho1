package com.example.toannguyen.appquanly.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.toannguyen.appquanly.R;
import com.example.toannguyen.appquanly.model.Loaisp;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class LoaispAdapter extends BaseAdapter {
    ArrayList<Loaisp> arraylistloaisp;
    Context context;//man hinh de ve

    public LoaispAdapter(ArrayList<Loaisp> arraylistloaisp, Context context) {
        this.arraylistloaisp = arraylistloaisp;
        this.context = context;
    }

    @Override
    public int getCount() {
        return arraylistloaisp.size() ;
    }

    @Override
    public Object getItem(int i) {
        return arraylistloaisp.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }
    // khi du lieu dua len lan dau se anh xa dc va nhung lan sau khong can load lai
    public class ViewHolder{
        TextView txtenlsp;
        ImageView imglsp;
    }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        ViewHolder viewholder = null;
        if(view == null)
        {
            viewholder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_listview_loaisp,null);
            viewholder.txtenlsp = view.findViewById(R.id.textviewloaisp);
            viewholder.imglsp = view.findViewById(R.id.imageviewloaisp);
            view.setTag(viewholder);
        }
        else
        {
            viewholder = (ViewHolder) view.getTag();
            Loaisp loaisp = (Loaisp) getItem(i);
            viewholder.txtenlsp.setText(loaisp.getTenlsp());
            Picasso.with(context).load(loaisp.getHinhanhslp())
                    .placeholder(R.drawable.common_full_open_on_phone)
                    .error(R.drawable.common_google_signin_btn_icon_dark)
                    .into(viewholder.imglsp);
        }
        return view;
    }
}
