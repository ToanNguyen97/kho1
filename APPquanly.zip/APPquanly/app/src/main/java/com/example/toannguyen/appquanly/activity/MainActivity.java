package com.example.toannguyen.appquanly.activity;

import android.animation.Animator;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ViewFlipper;

import com.example.toannguyen.appquanly.R;
import com.example.toannguyen.appquanly.adapter.LoaispAdapter;
import com.example.toannguyen.appquanly.model.Loaisp;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Toolbar toollbar ;
    ViewFlipper viewflipperr;
    RecyclerView recyclemanhinhchinh;
    NavigationView navigationviewmanhinhchinh;
    DrawerLayout drawerLayout ;
    ListView listView;
    ArrayList<Loaisp> mangloaisp;
    LoaispAdapter loaispadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Anhxa();
        ActionBar(); // chay toolbar
       ActionViewFliper(); // dùng viewFilper chay quảng cáo
    }

    private void ActionViewFliper() {
        ArrayList<String> mangquangcao = new ArrayList<>();// đổ hình quảng cáo vào trong mảng
        mangquangcao.add("http://vnreview.vn/image/17/23/61/1723619.jpg");
        mangquangcao.add("http://sempocell.com/wp-content/uploads/2017/12/170923-huawei-nova-2i-malaysia-3-580x547.jpg");
        mangquangcao.add("https://image.vtc.vn/files/thy.hue/2018/03/30/lllllllllllllll-1104349.png");
        mangquangcao.add("https://cdn.fptshop.com.vn/Uploads/Originals/2018/4/7/636586929636409378_1.jpg");
        for(int i = 0 ; i<mangquangcao.size();i++)
        {
            ImageView imageview = new ImageView(getApplicationContext());//
            Picasso.with(getApplicationContext()).load(mangquangcao.get(i)).into(imageview); // load hình ảnh từ đường dẫn url
            imageview.setScaleType(ImageView.ScaleType.FIT_XY);// set hình ảnh phù hợp với kích thước của viewfilper
            viewflipperr.addView(imageview);// đổ hình vào viewfliper
        }
        viewflipperr.setFlipInterval(5000);// set hình tự động load và thay đổi hình trong 5 giây
        viewflipperr.setAutoStart(true);// cho nó tự động chạy
        // gán 2 animtion vừa tạo trong thư mục anim
        Animation animation_slide_in = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_in_right);
        Animation animation_slide_out = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_out_right);
        //set 2 animation vao viewfliper
        viewflipperr.setInAnimation(animation_slide_in);
        viewflipperr.setOutAnimation(animation_slide_out);
    }

    private void ActionBar() {
        setSupportActionBar(toollbar); // hàm hỗ trợ cho biến toolbar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); // nút dùng show toolbar ra
        toollbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size); //set icon cho toolbar
        toollbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START); // mở toolbar khi click và ra giữa
            }
        });
    }

    private void Anhxa() {
        toollbar =(Toolbar) findViewById(R.id.toolbarmanhinhchinh);
        viewflipperr =(ViewFlipper) findViewById(R.id.viewflippermanhinhchinh);
        recyclemanhinhchinh =(RecyclerView) findViewById(R.id.recylemanhinhchinh);
        navigationviewmanhinhchinh =(NavigationView) findViewById(R.id.navigationmanhinhchinh);
        listView =(ListView) findViewById(R.id.listviewmanhinhchinh);
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerlayo);
        mangloaisp = new ArrayList<>();
        loaispadapter = new LoaispAdapter(mangloaisp,getApplicationContext());
        listView.setAdapter(loaispadapter);
    }
}
