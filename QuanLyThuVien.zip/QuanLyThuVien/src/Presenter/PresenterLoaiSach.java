/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import model.NewHibernateUtil;
import model.POJO.Loaisach;
import org.hibernate.Session;

/**
 *
 * @author TOAN NGUYEN
 */
public class PresenterLoaiSach extends EntityPresenter<Loaisach>{

    public PresenterLoaiSach() {
        super();
    }
    
    @Override
    protected String getHql_List() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    return "from Loaisach";
    }
    
    @Override
    protected Loaisach getEntity(Loaisach entity, Session session) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       Loaisach ls = (Loaisach) session.get(entity.getClass(),entity.getIdloaisach());
       return ls;
    }
    public Loaisach getHoadonByID(String id) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Loaisach hd =  (Loaisach) session.get(Loaisach.class, id);
        session.close();
        return hd;
    }
    
}
