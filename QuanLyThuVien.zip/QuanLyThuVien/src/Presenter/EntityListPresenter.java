/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import java.util.List;
import model.NewHibernateUtil;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

/**
 *
 * @author TOAN NGUYEN
 */
public abstract class EntityListPresenter<T> {
      List<T> entities;
    SessionFactory factory = NewHibernateUtil.getSessionFactory();

    abstract protected String getHql_List();  

    // hàm tạo query
    public List<T> queryListEntities() {
        Session s = factory.openSession();
        s.beginTransaction();
        Query q = s.createQuery(getHql_List());
        entities = q.list();
        s.close();
        return entities;
    }
    
}
