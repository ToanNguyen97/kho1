/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import model.POJO.Sach;
import org.hibernate.Session;

/**
 *
 * @author TOAN NGUYEN
 */
public class PresenterSach extends EntityPresenter<Sach>{

    public PresenterSach() {
        super();
    }
    
    @Override
    protected String getHql_List() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       return "from Sach";
    }

    @Override
    protected Sach getEntity(Sach entity, Session session) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Sach sach = (Sach) session.get(entity.getClass(), entity.getIdsach());
        return sach;
    }
    
    
}
