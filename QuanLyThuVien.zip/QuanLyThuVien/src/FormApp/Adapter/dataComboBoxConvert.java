/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormApp.Adapter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author TOAN NGUYEN
 */
public class dataComboBoxConvert<T> {

    String getterDisplayMethod;
    String getterValueMethod;
    List<T> source;
    DefaultComboBoxModel<String> model;

    public void setSource(List<T> source, String getterDisplayMethod, String getterValueMethod) {
        this.source = source;
        this.getterDisplayMethod = getterDisplayMethod;
        this.getterValueMethod = getterValueMethod;

    }

    public void setModel(DefaultComboBoxModel<String> model1) {
        this.model = model1;
        addComboBoxItems();
    }

    private void addComboBoxItems() {
        if (source.size() > 0) {
            int length = source.size();
            T t = source.get(0);
            try {
                Method method = t.getClass().getMethod(getterDisplayMethod);
                for (int i = 0; i < length; i++) {
                    String s;
                    try {
                        s = (String) method.invoke(source.get(i)).toString();
                        model.addElement((i + 1) + ". " + s);
                    } catch (IllegalAccessException ex) {
                        Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IllegalArgumentException ex) {
                        Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (InvocationTargetException ex) {
                        Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } catch (NoSuchMethodException ex) {
                Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SecurityException ex) {
                Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public Object getValueAt() {

        try {
            int index = model.getIndexOf(model.getSelectedItem());
            T t = source.get(0);
            Method method = t.getClass().getMethod(getterValueMethod);
            return method.invoke(source.get(index));
        } catch (NoSuchMethodException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvocationTargetException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public int getIndexByID(Object Id) {
        int index = -1;

        try {

            int length = source.size();
            T t = source.get(0);
            Method method = t.getClass().getMethod(getterValueMethod);
            for (int i = 0; i < length; i++) {
                Object s;
                try {
                    s = method.invoke(source.get(i));
                    if (s.equals(Id)) {
                        return i;
                    }
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalArgumentException ex) {
                    Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InvocationTargetException ex) {
                    Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (NoSuchMethodException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(dataComboBoxConvert.class.getName()).log(Level.SEVERE, null, ex);
        }
        return index;
    }

}
