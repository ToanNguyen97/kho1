/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FormApp.Adapter;

import java.util.List;
import javax.swing.table.DefaultTableModel;
import model.POJO.Bandoc;
import model.POJO.Loaisach;
import model.POJO.Sach;

/**
 *
 * @author TOAN NGUYEN
 */
public class DataConvert {

    public static void List_LoaiSach_TotalModel(List<Loaisach> list, DefaultTableModel model) {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
       // model.getDataVector().clear();
        for (int i = 0; i < rowNum; i++) {
            row[0] = list.get(i).getIdloaisach();
            row[1] = list.get(i).getTenloaisach();
            model.addRow(row);
        }
    }

    public static void List_Sach_TotalModel(List<Sach> list, DefaultTableModel model) {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
        model.getDataVector().clear();
        for (int i = 0; i < rowNum; i++) {
            row[0] = list.get(i).getIdsach();
            row[1] = list.get(i).getTensach();
            row[2] = list.get(i).getTacgia();
            row[3] = list.get(i).getNgonngu();
            row[4] = list.get(i).getNgaysanxuat();
            row[5] = list.get(i).getIdloaisach();
            model.addRow(row);
        }
    }
    public static void List_Bandoc_TotalModel(List<Bandoc> list,DefaultTableModel model)
    {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
        model.getDataVector().clear();
        for(int i = 0; i < rowNum;i++)
        {
            row[0] = list.get(i).getIdbandoc();
            row[1] = list.get(i).getTenbandoc();
            row[2] = list.get(i).getDiachi();
            row[3] = list.get(i).getSodienthoai();
            row[4] = list.get(i).getEmail();
            row[5] = list.get(i).getLop();
            model.addRow(row);
        }
    }
}
