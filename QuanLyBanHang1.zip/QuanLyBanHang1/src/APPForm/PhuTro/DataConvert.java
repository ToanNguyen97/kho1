/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APPForm.PhuTro;

import java.util.List;
import javax.swing.table.DefaultTableModel;
import model.POJO.Cthd;
import model.POJO.Hoadon;
import model.POJO.Khachhang;
import model.POJO.Sanpham;

/**
 *
 * @author TOAN NGUYEN
 */
public class DataConvert {
    public static void List_KhachHang_TotalModel(List<Khachhang> list, DefaultTableModel model)
    {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
        model.getDataVector().clear();
        for(int i = 0; i<rowNum;i++)
        {
            row[0] = list.get(i).getIdkhachhang();
            row[1] = list.get(i).getTenkhachhang();
            row[2] = list.get(i).getDiachi();
            row[3] = list.get(i).getSodienthoai();
            model.addRow(row);
        }
    }   
     public static void List_SanPam_TotalModel(List<Sanpham> list, DefaultTableModel model)
    {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
        model.getDataVector().clear();
        for(int i = 0; i<rowNum;i++)
        {
            row[0] = list.get(i).getSanphamid();
            row[1] = list.get(i).getTensp();
            row[2] = list.get(i).getGia();
            row[3] = list.get(i).getSl();
            row[4] = list.get(i).getDvt();
            model.addRow(row);
        }
    }   
      public static void List_Chitiethoadon_TotalModel(List<Cthd> list,List<Sanpham> listsp,DefaultTableModel model)
    {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
        model.setRowCount(0);
        int STT =1;
        for(int i = 0; i<rowNum;i++)
        {
            row[0] = STT;
            row[1] = list.get(i).getSanphamid();
            row[2] = list.get(i).getSoluong();
            row[3] = list.get(i).getGiaban();
            row[4]= list.get(i).getSoluong()*list.get(i).getGiaban();
            model.addRow(row);
            STT = STT +1;
        }
    } 
         public static void List_hoadon_TotalModel(List<Hoadon> list, DefaultTableModel model)
    {
        int colNum = model.getColumnCount();
        int rowNum = list.size();
        Object[] row = new Object[colNum];
        model.setRowCount(0);
        for(int i = 0; i<rowNum;i++)
        {
            row[0] = list.get(i).getHoadonid();
            row[1] = list.get(i).getIdkhachhang();
            row[2] = list.get(i).getNgayban();
            model.addRow(row);
        }
    } 
}
