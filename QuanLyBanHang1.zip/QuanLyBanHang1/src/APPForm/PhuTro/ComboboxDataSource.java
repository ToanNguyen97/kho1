/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package APPForm.PhuTro;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author TOAN NGUYEN
 */
public class ComboboxDataSource<T> {

    String getterDisplayMethod;
    String getterValueMethod;
    List<T> source;
    DefaultComboBoxModel<String> model;

    public void setSource(List<T> source, String getterDisplayMethod, String getterValueMethod) {
        this.source = source;
        this.getterDisplayMethod = getterDisplayMethod;
        this.getterValueMethod = getterValueMethod;

    }

    public void setModel(DefaultComboBoxModel<String> model1) {
        this.model = model1;
        addComboBoxItems();
    }

    private void addComboBoxItems() {
        if (source.size() > 0) {
            int length = source.size();
            T t = source.get(0);// lấy ra 1 đối tượng đầu danh sách để xem class cua no la doi tuong gi
            try {
                // từ đối tượng T lấy ra tên lớp tương ứng rồi lấy ra phương thức dựa theo tên để trả về đó thuộc phương thức gì
                // comment trên tương ứng với việc lấy ra phương thức tương ứng với getterdisplaymethod
                Method method = t.getClass().getMethod(getterDisplayMethod);
                for (int i = 0; i < length; i++) {
                    String s;
                    try {
                        // duyệt danh sách đối tượng để truyền vào đối tượng để method nó hoạt động
                        // method.invoke()hoạt động tương đương với phương thức doituong.getTenDoiTuong()
                        s = (String) method.invoke(source.get(i)).toString();// invoke : nghĩa là gọi
                        model.addElement((i + 1) + ". " + s);
                    } catch (IllegalAccessException ex) {
                        Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IllegalArgumentException ex) {
                        Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (InvocationTargetException ex) {
                        Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } catch (NoSuchMethodException ex) {
                Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SecurityException ex) {
                Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public Object getValueAt() {
        try {
            int index = model.getIndexOf(model.getSelectedItem());
            T t = source.get(0);
            Method method = t.getClass().getMethod(getterValueMethod);
            return method.invoke(source.get(index));
        } catch (NoSuchMethodException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalArgumentException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvocationTargetException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public int getIndexByID(Object Id) {
        int index = -1;
        try {

            int length = source.size();
            T t = source.get(0);
            Method method = t.getClass().getMethod(getterValueMethod);
            for (int i = 0; i < length; i++) {
                Object s;
                try {
                    s = method.invoke(source.get(i));
                    if (s.equals(Id)) {
                        return i;
                    }
                } catch (IllegalAccessException ex) {
                    Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
                } catch (IllegalArgumentException ex) {
                    Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InvocationTargetException ex) {
                    Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (NoSuchMethodException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SecurityException ex) {
            Logger.getLogger(ComboboxDataSource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return index;
    }

}
