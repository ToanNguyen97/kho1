/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import java.util.List;
import model.NewHibernateUtil;
import model.POJO.Cthd;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author TOAN NGUYEN
 */
public class PresenterChiTietHoaDon extends EntityPresenter<Cthd> {

  
    String HoadonID;

    public void SetHoadonID(String hoadonid) {
        this.HoadonID = hoadonid;
    }
      @Override
    // xem chi tiết theo hoa đơn id
    public List<Cthd> queryListEntities() {
        // return super.queryListEntities(); //To change body of generated methods, choose Tools | Templates.
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Query q = session.createQuery(getHql_List());
        q.setParameter("hoadonid", this.HoadonID);
        entities =q.list();
        session.close();
        return entities;
    }
    @Override
    protected Cthd getEntity(Cthd entity, Session session) {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Cthd cthd = (Cthd) session.get(entity.getClass(), entity.getId());
        return cthd;
    }

    @Override
    protected String getHql_List() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return "from Cthd where Hoadonid =:hoadonid";
    }

}
