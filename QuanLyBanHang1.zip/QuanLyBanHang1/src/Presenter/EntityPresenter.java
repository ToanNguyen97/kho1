/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import org.hibernate.Session;

/**
 *
 * @author TOAN NGUYEN
 */
public abstract class EntityPresenter<T> extends EntityListPrsenter<T> {

    abstract protected T getEntity(T entity, Session session);

    public T getEntity(T entity) {
        Session session = factory.openSession();
        session.beginTransaction();
        T kh = getEntity(entity, session);
        session.close();
        return kh;
    }

    // trả về đối tượng tại vị trí trong list
    public T getEntity(int index) {
        return entities.get(index);
    }

    public void them(T entity) {
        if (getEntity(entity) == null) {
            Session session = factory.openSession();
            session.beginTransaction();
            session.save(entity);
            session.getTransaction().commit();
            session.close();
        }
    }

    public void Sua(T entity) {
        if (getEntity(entity) != null) {
            Session session = factory.openSession();
            session.getTransaction().begin();
            session.update(entity);
            session.getTransaction().commit();// commit dùng để lưu thực sự dữ liệu mới vào dữ liệu cũ`
            session.close();
        }
    }

    public void Xoa(T entity) {
        if (getEntity(entity) != null) {
            Session session = factory.openSession();
            session.getTransaction().begin();
            session.delete(entity);
            session.getTransaction().commit();
            session.close();
        }
    }
}
