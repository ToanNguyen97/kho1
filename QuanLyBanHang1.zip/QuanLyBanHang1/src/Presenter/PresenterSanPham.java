/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import model.POJO.Khachhang;
import model.POJO.Sanpham;
import org.hibernate.Session;

/**
 *
 * @author TOAN NGUYEN
 */
public class PresenterSanPham extends EntityPresenter<Sanpham>{

    @Override
    protected String getHql_List() {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    return "from Sanpham";
    }

    @Override
    protected Sanpham getEntity(Sanpham entity,Session session) {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
       Sanpham sp  = (Sanpham) session.get(entity.getClass(), entity.getSanphamid());
       return sp;
    } 
}
