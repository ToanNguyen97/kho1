/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presenter;

import model.NewHibernateUtil;
import model.POJO.Hoadon;
import model.POJO.Khachhang;
import org.hibernate.Session;

/**
 *
 * @author TOAN NGUYEN
 */
public class PresenterHoadon extends EntityPresenter<Hoadon> {

    @Override
    protected Hoadon getEntity(Hoadon entity, Session session) {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        Hoadon hd = (Hoadon) session.get(entity.getClass(), entity.getHoadonid());
        return hd;
    }

    @Override
    protected String getHql_List() {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        return "from Hoadon";
    }

    public Hoadon getHoadonByID(String id) {
        Session session = NewHibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        Hoadon hd = (Hoadon) session.get(Hoadon.class, id);
        session.close();
        return hd;
    }

}
