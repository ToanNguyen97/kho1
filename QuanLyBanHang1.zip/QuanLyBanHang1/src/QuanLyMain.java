
import Presenter.PresenterKhachHang;
import java.util.List;
import model.POJO.Khachhang;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author TOAN NGUYEN
 */
public class QuanLyMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Presenter.PresenterKhachHang pr = new PresenterKhachHang();
        List<Khachhang> dskhachhang = pr.queryListEntities();
        System.out.println("kich thuoc: " + dskhachhang.size());
        for (int i = 0; i < dskhachhang.size(); i++) {
            System.out.println("-----------------------------");
            System.out.println("id : " + dskhachhang.get(i).getIdkhachhang());
            System.out.println("ho ten : " + dskhachhang.get(i).getTenkhachhang());
            System.out.println("dia chi : " + dskhachhang.get(i).getDiachi());
            System.out.println("so dien thoai : " + dskhachhang.get(i).getSodienthoai());
        }
    }
    
}
