﻿CREATE DATABASE QUANLYPHONGTRO_57130724
GO
USE QUANLYPHONGTRO_57130724
GO
CREATE TABLE LoaiKhach(
	MaLoaiKhach VARCHAR(10) PRIMARY KEY ,
	TenLoaiKhach NVARCHAR(30) NOT NULL
)
GO
CREATE TABLE KhachThue(
	MaKhachThue VARCHAR(10) PRIMARY KEY ,
	HoKhachThue NVARCHAR(30) NOT NULL,
	TenKhachThue NVARCHAR(20) NOT NULL,
	SoCMND VARCHAR(15) NOT NULL,
	NamSinh DATE NOT NULL,
	GioiTinh BIT DEFAULT(1) NOT NULL , --1 nam 0 nu
	DienThoai VARCHAR(15),
	HoTenNguoiThan NVARCHAR(50) ,
	DiaChi NVARCHAR(70) NOT NULL,
	MaLoaiKhach VARCHAR(10) FOREIGN KEY REFERENCES dbo.LoaiKhach(MaLoaiKhach)
	ON UPDATE CASCADE
	ON DELETE CASCADE
)
GO
CREATE TABLE NhanVien(
	MaNhanVien VARCHAR(10) PRIMARY KEY ,
	HoTenNhanVien NVARCHAR(30) NOT NULL,
	GioiTinh BIT DEFAULT(1) NOT NULL, 
	NamSinh DATE NOT NULL,
	DienThoai NVARCHAR(15) NOT NULL,
	DiaChi NVARCHAR(70) NOT NULL
)
GO
INSERT dbo.NhanVien
        ( MaNhanVien ,
          HoTenNhanVien ,
          GioiTinh ,
          NamSinh ,
          DienThoai ,
          DiaChi
        )
VALUES  ( 'NV01' , -- MaNhanVien - varchar(10)
          N'Nguyễn Văn Toàn' , -- HoTenNhanVien - nvarchar(30)
          1 , -- GioiTinh - bit
          '05/05/1997' , -- NamSinh - date
          N'01648096333' , -- DienThoai - nvarchar(15)
          N'Tuy Hòa , Phú Yên'  -- DiaChi - nvarchar(70)
        )
GO
CREATE PROC NhanVien_DS
AS
BEGIN
	SELECT * FROM dbo.NhanVien
END
GO
EXEC dbo.NhanVien_DS
GO
CREATE TABLE TaiKhoan(
	TenDangNhap NVARCHAR(30) PRIMARY KEY ,
	TenHienThi NVARCHAR(30) NOT NULL,
	MatKhau VARCHAR(30) NOT NULL,
	SoCMND VARCHAR(12) NOT NULL,
	MaNhanVien VARCHAR(10) FOREIGN KEY REFERENCES dbo.NhanVien(MaNhanVien)
	ON UPDATE CASCADE
	ON DELETE CASCADE
)
GO
INSERT dbo.TaiKhoan 
        ( TenDangNhap ,
          TenHienThi ,
          MatKhau ,
          SoCMND ,
          MaNhanVien
        )
VALUES  ( N'ToanNguyen' , -- TenDangNhap - nvarchar(30)
          N'Nguyễn Văn Toàn' , -- TenHienThi - nvarchar(30)
          '1' , -- MatKhau - varchar(30)
          '123456789' , -- SoCMND - varchar(12)
          'NV01'  -- MaNhanVien - varchar(10)
        )
GO
CREATE PROC TaiKhoan_DS
AS
BEGIN
	SELECT TenDangNhap AS N'Tên Đăng Nhập', TenHienThi AS N'Tên Hiển Thị' , MatKhau AS N'Mật Khẩu', SoCMND AS N'Số CMND' , MaNhanVien AS N'Mã Nhân Viên'
	 FROM dbo.TaiKhoan
END
GO
CREATE PROC NhanVien_Them
AS
BEGIN
	
END
go
EXEC dbo.TaiKhoan_DS
GO
CREATE PROC TaiKhoan_Them
@TenDangNhap NVARCHAR(30) ,
@TenHienThi NVARCHAR(30) ,
@MatKhau VARCHAR(30),
@SoCMND VARCHAR(12),
@MaNhanVien VARCHAR(10) 
AS
BEGIN
	INSERT dbo.TaiKhoan
	        ( TenDangNhap ,
	          TenHienThi ,
	          MatKhau ,
	          SoCMND ,
	          MaNhanVien
	        )
	VALUES  ( @TenDangNhap , -- TenDangNhap - nvarchar(30)
	          @TenHienThi , -- TenHienThi - nvarchar(30)
	          @MatKhau , -- MatKhau - varchar(30)
	          @SoCMND , -- SoCMND - varchar(12)
	          @MaNhanVien  -- MaNhanVien - varchar(10)
	        )
END
GO
CREATE PROC TaiKhoan_Sua
@TenDangNhap NVARCHAR(30) ,
@TenHienThi NVARCHAR(30) ,
@MatKhau VARCHAR(30),
@SoCMND VARCHAR(12),
@MaNhanVien VARCHAR(10) 
AS
BEGIN
	UPDATE dbo.TaiKhoan SET TenHienThi = @TenHienThi , MatKhau = @MatKhau , MaNhanVien = @MaNhanVien
	WHERE TenDangNhap = @TenDangNhap AND SoCMND = @SoCMND
END 
GO
CREATE PROC TaiKhoan_Xoa
@TenDangNhap NVARCHAR(30)
AS
BEGIN
	DELETE dbo.TaiKhoan WHERE TenDangNhap = @TenDangNhap
END
go
EXEC dbo.TaiKhoan_Them @TenDangNhap = N'Thao', -- nvarchar(30)
    @TenHienThi = N'Thảo', -- nvarchar(30)
    @MatKhau = '1', -- varchar(30)
    @SoCMND = '1', -- varchar(12)
    @MaNhanVien = 'NV01' -- varchar(10)
go
CREATE TABLE TinhTrangPhong(
	MaTinhTrang VARCHAR(10) PRIMARY KEY,
	TenTinhTrang NVARCHAR(30) NOT NULL -- gồm có các tình trang : Đã được thuê , chưa được thuê , đang sửa
)
GO
CREATE TABLE LoaiPhong(
	MaLoaiPhong VARCHAR(10) PRIMARY KEY ,
	TenLoaiPhong NVARCHAR(30) NOT NULL ,
	GiaPhong INTEGER NOT NULL
)
GO
CREATE TABLE KhuPhong(
	MaKhuPhong VARCHAR(10) PRIMARY KEY ,
	TenKhuPhong NVARCHAR(30) NOT NULL
)
GO
CREATE TABLE NoiQuy(
	MaNoiQuy VARCHAR(10) PRIMARY KEY,
	TenNoiQuy NVARCHAR(30) NOT NULL,
	NoiDung NVARCHAR(200) NOT NULL
)
GO
CREATE TABLE Phong(
	MaPhong VARCHAR(10) PRIMARY KEY,
	TenPhong NVARCHAR(30) NOT NULL,
	MaLoaiPhong VARCHAR(10) FOREIGN KEY REFERENCES dbo.LoaiPhong(MaLoaiPhong)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	MaKhuPhong VARCHAR(10) FOREIGN KEY REFERENCES dbo.KhuPhong(MaKhuPhong)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	MaTinhTrang VARCHAR(10) FOREIGN KEY REFERENCES dbo.TinhTrangPhong(MaTinhTrang)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	GhiChu NVARCHAR(100) NOT NULL	,
	MaNoiQuy VARCHAR(10) FOREIGN KEY REFERENCES  dbo.NoiQuy(MaNoiQuy)
	ON UPDATE CASCADE
	ON DELETE CASCADE
	
)
GO
CREATE TABLE HopDongThue(
	MaHopDong VARCHAR(10) PRIMARY KEY,
	MaKhachThue VARCHAR(10) FOREIGN KEY REFERENCES dbo.KhachThue(MaKhachThue)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	MaPhong VARCHAR(10) FOREIGN KEY REFERENCES dbo.Phong(MaPhong)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	NgayLap DATE NOT NULL,
	MaNhanVien VARCHAR(10) FOREIGN KEY REFERENCES dbo.NhanVien(MaNhanVien)
	ON UPDATE CASCADE
	ON DELETE CASCADE	
)
GO
CREATE TABLE CacKhoanThu(
	MaKhoanThu NVARCHAR(20) PRIMARY KEY,
	TenKhoanThu NVARCHAR(20) NOT NULL,
	GiaKhoanThu INTEGER NOT NULL
)
GO
CREATE TABLE TinhTrangPhieuThu(
	MaTinhTrangPhieu VARCHAR(10) PRIMARY KEY,
	TenTinhTrangPhieu NVARCHAR(20) NOT NULL
)
GO
CREATE TABLE PhieuThuTien(
	MaPhieu VARCHAR(10) PRIMARY KEY ,
	MaPhong VARCHAR(10) FOREIGN KEY REFERENCES dbo.Phong(MaPhong)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	NgayLap DATE NOT NULL,
	MaTinhTrangPhieu VARCHAR(10) FOREIGN KEY REFERENCES dbo.TinhTrangPhieuThu(MaTinhTrangPhieu)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	GhiChu NVARCHAR(100) NOT NULL
)
GO
CREATE TABLE CTPhieuThuTien(
	STT INTEGER NOT NULL,
	MaPhieu VARCHAR(10) FOREIGN KEY REFERENCES dbo.PhieuThuTien(MaPhieu)
	ON UPDATE CASCADE
	ON DELETE CASCADE,
	MaKhoanThu NVARCHAR(20) FOREIGN KEY REFERENCES dbo.CacKhoanThu(MaKhoanThu)
	ON UPDATE CASCADE
	ON DELETE CASCADE ,
	ChiSoCu INTEGER NOT NULL,
	ChiSoMoi INTEGER NOT NULL,
	TienPhatSinh INTEGER NOT NULL,
	CONSTRAINT PR_CTPhieuThu PRIMARY KEY(STT,MaPhieu)
)
