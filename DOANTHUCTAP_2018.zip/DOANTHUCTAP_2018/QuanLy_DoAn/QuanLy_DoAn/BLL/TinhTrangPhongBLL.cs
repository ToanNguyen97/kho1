﻿using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.BLL
{
    public class TinhTrangPhongBLL
    {
        private static TinhTrangPhongBLL instance;

        public static TinhTrangPhongBLL Instance
        {
            get {if( instance ==null) instance = new TinhTrangPhongBLL(); return TinhTrangPhongBLL.instance; }
           private set { TinhTrangPhongBLL.instance = value; }
        }
        private TinhTrangPhongBLL() { }
         public string GetMaByTen(string ten)
        {
            List<TinhTrangPhongDTO> listtr = TinhTrangPhongDAO.Instance.LoadTRList();
             for(int i = 0; i< listtr.Count;i++)
             {
                 if (listtr[i].TenTinhTrang.Equals(ten))
                     return listtr[i].MaTinhTrang;
             }
             return null;
        }
    }
}
