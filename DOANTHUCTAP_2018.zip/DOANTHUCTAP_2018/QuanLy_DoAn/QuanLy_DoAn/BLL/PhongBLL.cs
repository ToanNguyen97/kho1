﻿using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.BLL
{
   public class PhongBLL
    {
      
    }
}
