﻿using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.BLL
{
   public class LoaiPhongBLL
    {
        private static LoaiPhongBLL instance;

        public static LoaiPhongBLL Instance
        {
            get { if (instance == null) instance = new LoaiPhongBLL();
                return LoaiPhongBLL.instance; }
          private  set { LoaiPhongBLL.instance = value; }
        }
        private LoaiPhongBLL() { }
        public String getTenbyMa(String ma)
       {
           List<LoaiPhongDTO> tablelist = LoaiPhongDAO.Instance.LoadListDSTen();
           for(int i = 0; i< tablelist.Count;i++)
           {
               if (tablelist[i].MaLoaiPhong.Equals(ma))
                   return tablelist[i].TenLoaiPhong;
           }
           return null;
       }
        public int Gia(string ma)
        {
            List<LoaiPhongDTO> listgiadto = LoaiPhongDAO.Instance.LoadListDSTen();
            for (int i = 0; i < listgiadto.Count; i++)
            {
                if (listgiadto[i].MaLoaiPhong.Equals(ma))
                    return listgiadto[i].GiaLoaiPhong;
            }
            return 0;
        }
    }
}
