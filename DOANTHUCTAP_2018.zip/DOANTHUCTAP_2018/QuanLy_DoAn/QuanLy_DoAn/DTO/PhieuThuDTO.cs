﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class PhieuThuDTO
    {
        string maPhieu, maPhong, ngayLap, maTinhTrangPhieu, ghiChu;
       public PhieuThuDTO(string map, string maphong , string ngaylap, string matinhtrangphieu, string ghichu)
        {
            this.MaPhieu = map;
            this.MaPhong = maphong;
            this.NgayLap = ngaylap;
            this.MaTinhTrangPhieu = matinhtrangphieu;
            this.GhiChu = ghichu;
        }
       public PhieuThuDTO(DataRow row)
       {
           this.MaPhieu = row["MaPhieu"].ToString();
           this.MaPhong = row["MaPhong"].ToString();
           this.NgayLap = row["NgayLap"].ToString();
           this.MaTinhTrangPhieu = row["MaTinhTrangPhieu"].ToString();
           this.GhiChu = row["GhiChu"].ToString();
       }
        public string MaPhieu
        {
            get { return maPhieu; }
            set { maPhieu = value; }
        }

        public string MaPhong
        {
            get { return maPhong; }
            set { maPhong = value; }
        }

        public string NgayLap
        {
            get { return ngayLap; }
            set { ngayLap = value; }
        }

        public string MaTinhTrangPhieu
        {
            get { return maTinhTrangPhieu; }
            set { maTinhTrangPhieu = value; }
        }

        public string GhiChu
        {
            get { return ghiChu; }
            set { ghiChu = value; }
        }
    }
}
