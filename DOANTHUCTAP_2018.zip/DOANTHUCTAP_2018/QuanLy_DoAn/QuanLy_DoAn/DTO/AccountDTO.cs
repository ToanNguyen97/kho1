﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class AccountDTO
    {
       public AccountDTO() { }
       public AccountDTO(String tendangnhap) { this.TenDangNhap = tendangnhap; }
       public AccountDTO(String tendangnhap , String tenhienthi , String matkhau ,String socmnd ,String manhanvien)
       {
            this.TenDangNhap = tendangnhap;
            this.TenHienThi = tenhienthi;
            this.MatKhau = matkhau;
            this.SoCMND = socmnd;
            this.MaNhanVien = manhanvien;

       }
       public AccountDTO(DataRow row )
       {
           this.TenDangNhap = row["Tên Đăng Nhập"].ToString();
           this.TenHienThi = row["Tên Hiển Thị"].ToString();
           this.MatKhau = row["Mật Khẩu"].ToString();
           this.SoCMND = row["Số CMND"].ToString();
           this.MaNhanVien = row["Mã Nhân Viên"].ToString();
       }
        String tenDangNhap;

        public String TenDangNhap
        {
            get { return tenDangNhap; }
            set { tenDangNhap = value; }
        }
        String tenHienThi;

        public String TenHienThi
        {
            get { return tenHienThi; }
            set { tenHienThi = value; }
        }
        String matKhau;

        public String MatKhau
        {
            get { return matKhau; }
            set { matKhau = value; }
        }
        String soCMND;

        public String SoCMND
        {
            get { return soCMND; }
            set { soCMND = value; }
        }
        String maNhanVien;

        public String MaNhanVien
        {
            get { return maNhanVien; }
            set { maNhanVien = value; }
        }
    }
}
