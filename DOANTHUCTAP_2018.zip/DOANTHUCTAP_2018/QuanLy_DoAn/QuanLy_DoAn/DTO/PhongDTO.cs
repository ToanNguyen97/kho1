﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class PhongDTO
    {
      
        String maPhong, tenPhong, maLoaiPhong, maKhuPhong, maTinhTrang, ghiChu, maNoiQuy;
       public PhongDTO(string map,string tenp, string malp,string makhup,string matrp,string ghichu,string manoiquy)
        {
            this.MaPhong = map;
            this.TenPhong = tenp;
            this.MaLoaiPhong = malp;
            this.MaKhuPhong = makhup;
            this.MaTinhTrang = matrp;
            this.GhiChu = ghichu;
            this.MaNoiQuy = manoiquy;
        }
       public PhongDTO(){}
       public PhongDTO(String ma)
       {
           this.MaPhong = ma;
       }
         public PhongDTO(DataRow row )
       {
           this.MaPhong = row["MaPhong"].ToString();
           this.TenPhong = row["TenPhong"].ToString();
           this.MaLoaiPhong = row["MaLoaiPhong"].ToString();
           this.MaKhuPhong = row["MaKhuPhong"].ToString();
           this.MaTinhTrang = row["MaTinhTrang"].ToString();
           this.GhiChu = row["GhiChu"].ToString();
           this.MaNoiQuy = row["MaNoiQuy"].ToString();
       }
        public String MaPhong
        {
            get { return maPhong; }
            set { maPhong = value; }
        }

        public String TenPhong
        {
            get { return tenPhong; }
            set { tenPhong = value; }
        }

        public String MaLoaiPhong
        {
            get { return maLoaiPhong; }
            set { maLoaiPhong = value; }
        }

        public String MaKhuPhong
        {
            get { return maKhuPhong; }
            set { maKhuPhong = value; }
        }

        public String MaTinhTrang
        {
            get { return maTinhTrang; }
            set { maTinhTrang = value; }
        }

        public String GhiChu
        {
            get { return ghiChu; }
            set { ghiChu = value; }
        }

        public String MaNoiQuy
        {
            get { return maNoiQuy; }
            set { maNoiQuy = value; }
        }
    }
}
