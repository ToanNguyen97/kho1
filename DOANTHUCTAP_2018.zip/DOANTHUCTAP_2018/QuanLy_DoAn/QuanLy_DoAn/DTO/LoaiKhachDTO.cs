﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class LoaiKhachDTO
    {
        string maLoaiKhach, tenLoaiKhach;
        public LoaiKhachDTO(string ma, string ten)
        {
            this.MaLoaiKhach = ma;
            this.TenLoaiKhach = ten;
        }
        public LoaiKhachDTO(DataRow row)
        {
            this.MaLoaiKhach = row["MaLoaiKhach"].ToString();
            this.TenLoaiKhach = row["TenLoaiKhach"].ToString();
        }
        public string MaLoaiKhach
        {
            get { return maLoaiKhach; }
            set { maLoaiKhach = value; }
        }

        public string TenLoaiKhach
        {
            get { return tenLoaiKhach; }
            set { tenLoaiKhach = value; }
        }
    }
}
