﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class NoiQuyDTO
    {
        string maNoiQuy, tenNoiQuy, noiDung;
       public NoiQuyDTO(string ma , string ten , string noidung)
        {
            this.MaNoiQuy = ma;
            this.TenNoiQuy = ten;
            this.NoiDung = noidung;
        }
       public NoiQuyDTO(DataRow row)
        {
            this.MaNoiQuy = row["MaNoiQuy"].ToString();
            this.TenNoiQuy = row["TenNoiQuy"].ToString();
            this.NoiDung = row["NoiDung"].ToString();
        }

        public string MaNoiQuy
        {
            get { return maNoiQuy; }
            set { maNoiQuy = value; }
        }
        public string TenNoiQuy
        {
            get { return tenNoiQuy; }
            set { tenNoiQuy = value; }
        }

        public string NoiDung
        {
            get { return noiDung; }
            set { noiDung = value; }
        }
    }
}
