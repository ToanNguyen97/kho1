﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class TinhTrangPhieuThuDTO
    {
        string maTinhTrangPhieu, tenTinhTrangPhieu;
       public TinhTrangPhieuThuDTO(string ma, string ten)
        {
            this.MaTinhTrangPhieu = ma;
            this.TenTinhTrangPhieu = ten;
        }
       public TinhTrangPhieuThuDTO(DataRow row)
       {
           this.MaTinhTrangPhieu = row["MaTinhTrangPhieu"].ToString();
           this.TenTinhTrangPhieu = row["TenTinhTrangPhieu"].ToString();
       }
        public string MaTinhTrangPhieu
        {
            get { return maTinhTrangPhieu; }
            set { maTinhTrangPhieu = value; }
        }

        public string TenTinhTrangPhieu
        {
            get { return tenTinhTrangPhieu; }
            set { tenTinhTrangPhieu = value; }
        }
    }
}
