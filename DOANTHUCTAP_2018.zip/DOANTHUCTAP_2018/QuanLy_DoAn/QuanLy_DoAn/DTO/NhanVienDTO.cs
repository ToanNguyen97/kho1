﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
    public class NhanVienDTO
    {
        String maNhanVien, hoTenNhanVien, namSinh, dienThoai, diaChi;
        int gioiTinh;
        public NhanVienDTO(String manv ,String tennv, int gt, string namsinh ,String dienthoai , String diachi)
        {
            this.MaNhanVien = manv;
            this.HoTenNhanVien = tennv;
            this.GioiTinh = gt;
            this.NamSinh = namsinh;
            this.DienThoai = dienthoai;
            this.DiaChi = diachi;
        }
        public int GioiTinh
        {
            get { return gioiTinh; }
            set { gioiTinh = value; }
        }
        public String DiaChi
        {
            get { return diaChi; }
            set { diaChi = value; }
        }

        public String DienThoai
        {
            get { return dienThoai; }
            set { dienThoai = value; }
        }

        public String NamSinh
        {
            get { return namSinh; }
            set { namSinh = value; }
        }

        public String HoTenNhanVien
        {
            get { return hoTenNhanVien; }
            set { hoTenNhanVien = value; }
        }

        public String MaNhanVien
        {
            get { return maNhanVien; }
            set { maNhanVien = value; }
        }
    }
}
