﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class CacKhoanThuDTO
    {
        string maKhoanThu, tenKhoanThu;
        int giaKhoanThu;
       public CacKhoanThuDTO(string ma, string ten , int  gia)
        {
            this.MaKhoanThu = ma;
            this.TenKhoanThu = ten;
            this.GiaKhoanThu = gia;
        }
       public CacKhoanThuDTO(DataRow row)
       {
           this.MaKhoanThu = row["MaKhoanThu"].ToString() ;
           this.TenKhoanThu = row["TenKhoanThu"].ToString();
           this.GiaKhoanThu =(Int32)row["GiaKhoanThu"];
       }
        public string MaKhoanThu
        {
            get { return maKhoanThu; }
            set { maKhoanThu = value; }
        }

        public string TenKhoanThu
        {
            get { return tenKhoanThu; }
            set { tenKhoanThu = value; }
        }


       public int GiaKhoanThu
       {
           get { return giaKhoanThu; }
           set { giaKhoanThu = value; }
       }

    }
}
