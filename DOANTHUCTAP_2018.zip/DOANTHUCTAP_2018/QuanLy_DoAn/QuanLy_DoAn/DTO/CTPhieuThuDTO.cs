﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class CTPhieuThuDTO
    {
        int sTT, chiSoCu, chiSoMoi, tienPhatSinh;
        string maPhieu, maKhoanThu;
       public CTPhieuThuDTO(int stt, string map, string makhoanthu , int chisocu, int chisomoi, int tienps )
        {
            this.STT = stt;
            this.MaPhieu = map;
            this.MaKhoanThu = makhoanthu;
            this.ChiSoCu = chisocu;
            this.ChiSoMoi = chisomoi;
            this.TienPhatSinh = tienps;
        }
       public CTPhieuThuDTO(DataRow row)
       {
           this.STT = (Int32)row["STT"];
           this.MaPhieu = row["MaPhieu"].ToString();
           this.MaKhoanThu = row["MaKhoanThu"].ToString();
           this.ChiSoCu = (Int32)row["ChiSoCu"];
           this.ChiSoMoi = (Int32)row["ChiSoMoi"];
           this.TienPhatSinh = (Int32)row["TienPhatSinh"];
       }
        public int STT
        {
            get { return sTT; }
            set { sTT = value; }
        }

        public int ChiSoCu
        {
            get { return chiSoCu; }
            set { chiSoCu = value; }
        }

        public int ChiSoMoi
        {
            get { return chiSoMoi; }
            set { chiSoMoi = value; }
        }

        public int TienPhatSinh
        {
            get { return tienPhatSinh; }
            set { tienPhatSinh = value; }
        }
       

       public string MaPhieu
       {
           get { return maPhieu; }
           set { maPhieu = value; }
       }

       public string MaKhoanThu
       {
           get { return maKhoanThu; }
           set { maKhoanThu = value; }
       }
    }
}
