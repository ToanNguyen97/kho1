﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;
using QuanLy_DoAn.BLL;

namespace QuanLy_DoAn.FormAPP
{
    public partial class DangKyForm : DevExpress.XtraEditors.XtraForm
    {
        public DangKyForm()
        {
            InitializeComponent();
            Load();
        }
        private void Load()
        {
            comboNV.DataSource = NhanVienDAO.Instance.LoadNV();
            comboNV.DisplayMember = "HoTenNhanVien" ;
            comboNV.ValueMember = "MaNhanVien";
        }
        private void groupControl1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            try {
                AccountDTO accdto = new AccountDTO(txtendangnhap.Text , txttenhienthi.Text , txtmatkhau.Text , txtcmnd.Text , comboNV.SelectedValue.ToString());
                AccountBLL.Instance.ThemACC(accdto,txtxacnhan.Text);              
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }
           
        }
    }
}