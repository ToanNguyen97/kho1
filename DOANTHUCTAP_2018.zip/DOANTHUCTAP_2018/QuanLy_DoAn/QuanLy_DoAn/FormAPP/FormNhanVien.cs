﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class FormNhanVien : DevExpress.XtraEditors.XtraForm
    {
        public FormNhanVien()
        {
            InitializeComponent();
            Load();
        }
        private void Load()
        {
            GridNV.DataSource = NhanVienDAO.Instance.LoadNV();
        }
    }
}