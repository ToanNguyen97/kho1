﻿using DevExpress.XtraBars.Helpers;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.FormAPP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLy_DoAn
{
    public partial class Form1 : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public Form1()
        {
            InitializeComponent();
            txtngay.Caption = "Ngày : " + System.DateTime.Now.ToShortDateString() + Environment.NewLine + "Giờ: " + System.DateTime.Now.ToLongTimeString();
            // timer1_Tick( sender,  e);   
            Load();
           
        }
        public void Load()
        {
            Form frm = this.KiemTraTonTai(typeof(SoDoTroForm));
            if (frm != null)
                frm.Activate();
            else
            {
                SoDoTroForm frmkh = new SoDoTroForm();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }
        private Form KiemTraTonTai(Type fType)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f.GetType() == fType)    // Neu Form duoc truyen vao da duoc mo
                {
                    return f;
                }
            }
            return null;
        }
        private void btnlogin_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DangNhapForm frm = new DangNhapForm();
            this.Hide();      
            frm.ShowDialog();
              
        }

        private void hideContainerLeft_Click(object sender, EventArgs e)
        {

        }

        private void dockPanel1_Click(object sender, EventArgs e)
        {

        }

        private void btntaikhoan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
             Form frm = this.KiemTraTonTai(typeof(TaiKhoanForm));
            if (frm != null)
                frm.Activate();
            else
            {
                TaiKhoanForm f = new TaiKhoanForm();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void labelControl1_Click(object sender, EventArgs e)
        {
          
        }

        private void labledate_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            txtngaygio.Caption = "Ngày : " + System.DateTime.Now.ToShortDateString() + " " + "Giờ: " + System.DateTime.Now.ToLongTimeString();
        }

        private void btnkhach_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            
        }

        private void btnphong_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
           
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.KiemTraTonTai(typeof(HopDongThuePhong));
            if (frm != null)
                frm.Activate();
            else
            {
                HopDongThuePhong frmkh = new HopDongThuePhong();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            radialMenu1.ShowPopup(new Point(this.Width / 2, this.Height / 2));
        }

        private void barButtonItem6_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                string path;
                string Date = System.DateTime.Now.ToString();               
                FolderBrowserDialog folder = new FolderBrowserDialog();
                folder.Description = "Vui Lòng Chọn Vị Trí Bạn Muốn Sao Lưu";
                folder.ShowDialog();
                path = folder.SelectedPath;
                if (path == "")
                {
                    XtraMessageBox.Show("Bạn Chưa Sao Lưu!!");
                }
                else
                {
                    Date = Date.Replace("/", "-").Replace(" ", "_").Replace(":", "-");
                    path = path + @"\" + "Saoluu" + "--" + Date + ".bak";
                    SaoLuuandPhucHoiDAO.Instance.SaoLuu(path);
                    XtraMessageBox.Show("Sao lưu thành công!!");
                }
               
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Sao lưu thất bại!!");
            }
           
            
        }

        private void barButtonItem7_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
           
        }

        private void btnphuchoi_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            try
            {
                string path;
                OpenFileDialog openfile = new OpenFileDialog();
                openfile.ShowDialog();
                path = openfile.FileName;
                if (path == "")
                {
                    XtraMessageBox.Show("Bạn Chưa chọn file phục hồi!!");
                }
                else
                {
                    SaoLuuandPhucHoiDAO.Instance.PhucHoi(path);
                    XtraMessageBox.Show("Phục Hồi thành công!!");
                }
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Phục Hồi thất bại!!");
            }
         
        }

        private void btnThongKe_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.KiemTraTonTai(typeof(ThongKeForm));
            if (frm != null)
                frm.Activate();
            else
            {
                ThongKeForm frmkh = new ThongKeForm();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }

        private void btntienphong_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.KiemTraTonTai(typeof(TinhTienForm));
            if (frm != null)
                frm.Activate();
            else
            {
                TinhTienForm frmkh = new TinhTienForm();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }

       

        private void btnNhanVien_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

            Form frm = this.KiemTraTonTai(typeof(FormNhanVien));
            if (frm != null)
                frm.Activate();
            else
            {
                FormNhanVien frmkh = new FormNhanVien();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }

        private void barButtonItem9_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.KiemTraTonTai(typeof(KhachThueForm));
            if (frm != null)
                frm.Activate();
            else
            {
                KhachThueForm frmkh = new KhachThueForm();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }



        private void btnsodo_ItemClick_1(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Form frm = this.KiemTraTonTai(typeof(SoDoTroForm));
            if (frm != null)
                frm.Activate();
            else
            {
                SoDoTroForm frmkh = new SoDoTroForm();
                frmkh.MdiParent = this;
                frmkh.Show();
            }
        }

      
    }
}
