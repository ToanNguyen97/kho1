﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class TinhTienForm : DevExpress.XtraEditors.XtraForm
    {
        int STT = 0;
        public TinhTienForm()
        {
            InitializeComponent();
            Load();
          
        }
        private void Load()
        {
            GridPT.DataSource = PhieuThuTienDAO.Instance.LoadPhieuThu();
            btnxuatphieu.Enabled = false;
            nuoccu.Enabled = false;
            nuocmoi.Enabled = false;
            txtsocu.Enabled = false;
            txtsomoi.Enabled = false;
            comboTRPhieu.DataSource = TinhTrangPhieuDAO.Instance.LoadDS();
            comboTRPhieu.DisplayMember = "TenTinhTrangPhieu";
            comboTRPhieu.ValueMember = "MaTinhTrangPhieu";
            comboKV.DataSource = KhuPhongDAO.Instance.LoadKhuPhong();
            comboKV.DisplayMember = "TenKhuPhong";
            comboKV.ValueMember = "MaKhuPhong";
            comboPhong.DataSource = PhongDAO.Instance.LoadListbyMaPhong(comboKV.SelectedValue.ToString());
            comboPhong.DisplayMember = "TenPhong";
            comboPhong.ValueMember = "MaPhong";
        }
        private void setUp() //setup khi chuyen phong
        {
            checkdien.Checked = false;
            checknuoc.Checked = false;
            checkmang.Checked = false;
            txttiendien.Text = "0";
            txttiennuoc.Text = "0";
            txttienmang.Text = "0";
        }
        private void comboKV_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboPhong.DataSource = PhongDAO.Instance.LoadListbyMaPhong(comboKV.SelectedValue.ToString());
            comboPhong.DisplayMember = "TenPhong";
            comboPhong.ValueMember = "MaPhong";
        }

        private void comboPhong_SelectedIndexChanged(object sender, EventArgs e)
        {
            setUp();
            txtmaphong.Text = comboPhong.SelectedValue.ToString();
            txtloaiphong.Text = LoaiPhongDAO.Instance.geTenDByID(PhongDAO.Instance.LoadLoaiPhongByMa(comboPhong.SelectedValue.ToString()));
            txttiennha.Text = LoaiPhongDAO.Instance.getGiaByID(PhongDAO.Instance.LoadLoaiPhongByMa(comboPhong.SelectedValue.ToString()));
            txtmakhach.Text = HopDongThueDAO.Instance.getTenKhachByMaPhong(comboPhong.SelectedValue.ToString());
        
        }

        private void txtmakhach_EditValueChanged(object sender, EventArgs e)
        {
            if(txtmakhach.Text == "")
            {
                txthotenkhach.Text = "";
                txtsdt.Text = "";
                txtdiachi.Text = "";
                txtnghenghiep.Text = "";
            }
            else
            {
                string gt = "";
                KhachThueDTO khachdto = new KhachThueDTO(txtmakhach.Text, txthotenkhach.Text, gt, txtsdt.Text, txtdiachi.Text, txtnghenghiep.Text);
                KhachThueDAO.Instance.GetInfoByMaPhongOfHD(khachdto, txtmakhach.Text);
                txthotenkhach.Text = khachdto.HoKhachThue;
                if (khachdto.Gt == "Nam")
                    RNam.Checked = true;
                else
                    Rnu.Checked = true;
                txtsdt.Text = khachdto.DienThoai;
                txtdiachi.Text = khachdto.DiaChi;
                txtnghenghiep.Text = LoaiKhachDAO.Instance.getTenByID(khachdto.MaLoaiKhach);
            }
           
        }

        private void txtmaphong_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void txttiennha_EditValueChanged(object sender, EventArgs e)
        {         
        }
        private string chiso(string cu, string moi)
        {
            string ketqua = "";
            if (cu == "")
                cu = "0";
            if (moi == "")
                moi = "0";
            Int32 tong = Convert.ToInt32(moi) - Convert.ToInt32(cu);
            ketqua = tong.ToString();
            return ketqua;
        }
        private void txttiendien_EditValueChanged(object sender, EventArgs e)
        {
         
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            Int64 tongtien = Convert.ToInt64(txttiendien.Text) + Convert.ToInt64(txttiennuoc.Text) + Convert.ToInt64(txttienmang.Text);
            txttongtien.Text =  tongtien.ToString();
        }

        private void checkdien_CheckedChanged(object sender, EventArgs e)
        {
            if (checkdien.Checked == true)
            {
                txtsocu.Enabled = true;
                txtsomoi.Enabled = true;
            }
            else {
                txtsocu.Enabled = false;
                txtsomoi.Enabled = false;
                txtsocu.Text = "0";
                txtsomoi.Text = "0";
            }
        }

        private void checknuoc_CheckedChanged(object sender, EventArgs e)
        {
            if (checknuoc.Checked == true)
            {
                nuoccu.Enabled = true;
                nuocmoi.Enabled = true;
            }
            else
            {
                nuoccu.Enabled = false;
                nuocmoi.Enabled = false;
                nuoccu.Text = "0";
                nuocmoi.Text = "0";
            }
        }

        private void checkmang_CheckedChanged(object sender, EventArgs e)
        {
            if(checkmang.Checked == true)
            {
                int mang = 55000;
                txttienmang.Text = mang.ToString();
            }else
            {
                txttienmang.Text = "0";
            }
        }

        private void txtsomoi_EditValueChanged(object sender, EventArgs e)
        {

            txttiendien.Text = "0";
            double tiendien =  Convert.ToDouble(chiso(txtsocu.Text, txtsomoi.Text)) * 4000;
            txttiendien.Text = tiendien.ToString();
        }

        private void nuocmoi_EditValueChanged(object sender, EventArgs e)
        {
            txttiennuoc.Text = "0";
            double tiennuoc = Convert.ToDouble(chiso(nuoccu.Text, nuocmoi.Text)) * 17000;
            txttiennuoc.Text = tiennuoc.ToString() ;
        }

        private void txtsocu_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void nuoccu_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            try
            {
                PhieuThuDTO dtopt = new PhieuThuDTO(txtmaphieu.Text,txtmaphong.Text, txtngaylap.Text, comboTRPhieu.SelectedValue.ToString(), txtghichu.Text);
                PhieuThuTienDAO.Instance.PhieuThu_Them(dtopt);
                GridPT.DataSource = PhieuThuTienDAO.Instance.LoadPhieuThu();
                XtraMessageBox.Show("Lập thành công!!");
                STT = 1;
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Lập thành công!!");
            }
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
          try{
                    string thudien, thunuoc , thumang;
                    if (GridCTPT.RowCount == 3)
                    {
                        XtraMessageBox.Show("Đã thêm đủ thông tin!!");
                        btnthem.Enabled = false;
                        btnxuatphieu.Enabled = true;
                    }
                    else
                    {
                        if (checkdien.Checked == true)
                        {
                            STT = 1;
                            thudien = "KT01";
                            CTPhieuThuDTO ctdto = new CTPhieuThuDTO(STT, txtmaphieu.Text, thudien, Convert.ToInt32(txtsocu.Text), Convert.ToInt32(txtsomoi.Text), 0);
                            CTPhieuThuDAO.Instance.CTPhieuThu_Them(ctdto);
                            STT += 1;
                            checkdien.Enabled = false;
                        }
                        if (checknuoc.Checked == true)
                        {
                            thunuoc = "KT02";
                            CTPhieuThuDTO ctdto = new CTPhieuThuDTO(STT, txtmaphieu.Text, thunuoc, Convert.ToInt32(nuoccu.Text), Convert.ToInt32(nuocmoi.Text), 0);
                            CTPhieuThuDAO.Instance.CTPhieuThu_Them(ctdto);
                            STT += 1;
                            checknuoc.Enabled = false;
                        }
                        if (checkmang.Checked == true)
                        {
                            thumang = "KT03";
                            CTPhieuThuDTO ctdto = new CTPhieuThuDTO(STT, txtmaphieu.Text, thumang, 0, 0, 0);
                            CTPhieuThuDAO.Instance.CTPhieuThu_Them(ctdto);
                            checkmang.Enabled = false;
                        }
                        GridCTPT.DataSource = CTPhieuThuDAO.Instance.LoadCT_DSBYID(txtmaphieu.Text);
                        btnxuatphieu.Enabled = true;
                        XtraMessageBox.Show("Thành Công!!");
                    }
                    
            }catch(Exception ex)
          {
              XtraMessageBox.Show("Lỗi!!");
          }
        }

        private void GridPT_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
            txtmaphieu.Text = GridPT.CurrentRow.Cells[0].Value.ToString();
            txtmaphong.Text = GridPT.CurrentRow.Cells[1].Value.ToString();
            txtngaylap.Text = GridPT.CurrentRow.Cells[2].Value.ToString();
            comboTRPhieu.SelectedValue = GridPT.CurrentRow.Cells[3].Value.ToString();
            txtghichu.Text = GridPT.CurrentRow.Cells[4].Value.ToString();
            
        }

        private void btnxemPhieu_Click(object sender, EventArgs e)
        {
            
            GridCTPT.DataSource = CTPhieuThuDAO.Instance.LoadCT_DSBYID(txtmaphieu.Text);
            if(comboTRPhieu.SelectedValue.ToString() =="TRP02")
            {
                XtraMessageBox.Show("Đã Thu Tiền !!");
                btnthanhtoan.Enabled = false;
                btnthem.Enabled = false;
            }
            else
            {
                btnthanhtoan.Enabled = true;
                if (GridCTPT.RowCount > 3)
                {
                    btnthem.Enabled = false;
                    XtraMessageBox.Show("Đã đủ thông tin , liên hệ thanh toán");
                    btnxuatphieu.Enabled = true;
                }
                else
                    btnthem.Enabled = true;
                STT = GridCTPT.RowCount;
            }
           
          
        }

        private void simpleButton4_Click(object sender, EventArgs e)
        {
            XuatPhieuTienForm frm = new XuatPhieuTienForm();
            frm.lbmap.Text = txtmaphieu.Text;
            frm.ShowDialog();
        }

        private void GridCTPT_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //if (GridCTPT.CurrentRow.Cells[1].Value.ToString().Equals("Tiền điện"))
            //    checkdien.Checked = true;
            //if (GridCTPT.CurrentRow.Cells[1].Value.ToString().Equals("Tiền nước"))
            //    checknuoc.Checked = true;
            //if (GridCTPT.CurrentRow.Cells[1].Value.ToString().Equals("Tiền mạng"))
            //    checkmang.Checked = true;
            //txtsocu.Text = GridCTPT.CurrentRow.Cells[3].Value.ToString();
            //txtsomoi.Text = GridCTPT.CurrentRow.Cells[4].Value.ToString();
            //nuoccu.Text  = GridCTPT.CurrentRow.Cells[3].Value.ToString();
            //nuocmoi.Text = GridCTPT.CurrentRow.Cells[3].Value.ToString();
        }

        private void simpleButton5_Click(object sender, EventArgs e)
        {
           if(XtraMessageBox.Show("Xác Nhận thu tiền", "Thông Báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.OK)
           {
               PhieuThuDTO dtopt = new PhieuThuDTO(txtmaphieu.Text, txtmaphong.Text, txtngaylap.Text,"TRP02", txtghichu.Text);
               PhieuThuTienDAO.Instance.PhieuThu_Sua(dtopt);                       
               GridPT.DataSource = PhieuThuTienDAO.Instance.LoadPhieuThu();
               XtraMessageBox.Show("Đã Thu Tiền !!!");
               btnthanhtoan.Enabled = false;
           }
        }
    }
}