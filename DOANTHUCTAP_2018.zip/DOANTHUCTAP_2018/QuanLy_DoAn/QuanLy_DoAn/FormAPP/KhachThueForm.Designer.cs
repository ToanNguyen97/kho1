﻿namespace QuanLy_DoAn.FormAPP
{
    partial class KhachThueForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.comboLoaikhach = new System.Windows.Forms.ComboBox();
            this.btnTimKiem = new DevExpress.XtraEditors.SimpleButton();
            this.btnxoa = new DevExpress.XtraEditors.SimpleButton();
            this.btnsua = new DevExpress.XtraEditors.SimpleButton();
            this.btnthem = new DevExpress.XtraEditors.SimpleButton();
            this.txtdiachi = new DevExpress.XtraEditors.TextEdit();
            this.txttennguoithan = new DevExpress.XtraEditors.TextEdit();
            this.txtsdt = new DevExpress.XtraEditors.TextEdit();
            this.txtnamsinh = new DevExpress.XtraEditors.TextEdit();
            this.txtcmnd = new DevExpress.XtraEditors.TextEdit();
            this.txttenkhach = new DevExpress.XtraEditors.TextEdit();
            this.txthokhach = new DevExpress.XtraEditors.TextEdit();
            this.txtmakhach = new DevExpress.XtraEditors.TextEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.Rnu = new System.Windows.Forms.RadioButton();
            this.RNam = new System.Windows.Forms.RadioButton();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.lb1 = new DevExpress.XtraEditors.LabelControl();
            this.lb = new DevExpress.XtraEditors.LabelControl();
            this.lnsdt = new DevExpress.XtraEditors.LabelControl();
            this.lbnamsinh = new DevExpress.XtraEditors.LabelControl();
            this.lbcmnd = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.GridKH = new System.Windows.Forms.DataGridView();
            this.GridKhach = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtdiachi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttennguoithan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsdt.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamsinh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenkhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthokhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmakhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridKH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridKhach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.GridKhach);
            this.panelControl1.Controls.Add(this.panelControl3);
            this.panelControl1.Controls.Add(this.panelControl2);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1775, 753);
            this.panelControl1.TabIndex = 0;
            // 
            // panelControl3
            // 
            this.panelControl3.AutoSize = true;
            this.panelControl3.Controls.Add(this.labelControl10);
            this.panelControl3.Controls.Add(this.comboLoaikhach);
            this.panelControl3.Controls.Add(this.btnTimKiem);
            this.panelControl3.Controls.Add(this.btnxoa);
            this.panelControl3.Controls.Add(this.btnsua);
            this.panelControl3.Controls.Add(this.btnthem);
            this.panelControl3.Controls.Add(this.txtdiachi);
            this.panelControl3.Controls.Add(this.txttennguoithan);
            this.panelControl3.Controls.Add(this.txtsdt);
            this.panelControl3.Controls.Add(this.txtnamsinh);
            this.panelControl3.Controls.Add(this.txtcmnd);
            this.panelControl3.Controls.Add(this.txttenkhach);
            this.panelControl3.Controls.Add(this.txthokhach);
            this.panelControl3.Controls.Add(this.txtmakhach);
            this.panelControl3.Controls.Add(this.groupControl1);
            this.panelControl3.Controls.Add(this.labelControl9);
            this.panelControl3.Controls.Add(this.lb1);
            this.panelControl3.Controls.Add(this.lb);
            this.panelControl3.Controls.Add(this.lnsdt);
            this.panelControl3.Controls.Add(this.lbnamsinh);
            this.panelControl3.Controls.Add(this.lbcmnd);
            this.panelControl3.Controls.Add(this.labelControl3);
            this.panelControl3.Controls.Add(this.labelControl2);
            this.panelControl3.Controls.Add(this.labelControl1);
            this.panelControl3.Location = new System.Drawing.Point(0, 287);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(1260, 233);
            this.panelControl3.TabIndex = 1;
            this.panelControl3.Paint += new System.Windows.Forms.PaintEventHandler(this.panelControl3_Paint);
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(8, 184);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(102, 16);
            this.labelControl10.TabIndex = 23;
            this.labelControl10.Text = "Tên Khách Thuê :";
            // 
            // comboLoaikhach
            // 
            this.comboLoaikhach.FormattingEnabled = true;
            this.comboLoaikhach.Location = new System.Drawing.Point(701, 175);
            this.comboLoaikhach.Name = "comboLoaikhach";
            this.comboLoaikhach.Size = new System.Drawing.Size(133, 24);
            this.comboLoaikhach.TabIndex = 22;
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.Location = new System.Drawing.Point(925, 181);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(138, 45);
            this.btnTimKiem.TabIndex = 21;
            this.btnTimKiem.Text = "Tìm Kiếm";
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(1110, 181);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(138, 45);
            this.btnxoa.TabIndex = 20;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(1110, 101);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(138, 45);
            this.btnsua.TabIndex = 19;
            this.btnsua.Text = "Sửa";
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(1110, 20);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(138, 45);
            this.btnthem.TabIndex = 18;
            this.btnthem.Text = "Thêm";
            this.btnthem.Click += new System.EventHandler(this.btnthem_Click);
            // 
            // txtdiachi
            // 
            this.txtdiachi.Location = new System.Drawing.Point(701, 98);
            this.txtdiachi.Name = "txtdiachi";
            this.txtdiachi.Size = new System.Drawing.Size(133, 22);
            this.txtdiachi.TabIndex = 17;
            // 
            // txttennguoithan
            // 
            this.txttennguoithan.Location = new System.Drawing.Point(701, 22);
            this.txttennguoithan.Name = "txttennguoithan";
            this.txttennguoithan.Size = new System.Drawing.Size(133, 22);
            this.txttennguoithan.TabIndex = 16;
            // 
            // txtsdt
            // 
            this.txtsdt.Location = new System.Drawing.Point(413, 178);
            this.txtsdt.Name = "txtsdt";
            this.txtsdt.Size = new System.Drawing.Size(133, 22);
            this.txtsdt.TabIndex = 15;
            this.txtsdt.EditValueChanged += new System.EventHandler(this.txtsdt_EditValueChanged);
            // 
            // txtnamsinh
            // 
            this.txtnamsinh.Location = new System.Drawing.Point(413, 98);
            this.txtnamsinh.Name = "txtnamsinh";
            this.txtnamsinh.Size = new System.Drawing.Size(133, 22);
            this.txtnamsinh.TabIndex = 14;
            // 
            // txtcmnd
            // 
            this.txtcmnd.Location = new System.Drawing.Point(413, 25);
            this.txtcmnd.Name = "txtcmnd";
            this.txtcmnd.Size = new System.Drawing.Size(133, 22);
            this.txtcmnd.TabIndex = 13;
            // 
            // txttenkhach
            // 
            this.txttenkhach.Location = new System.Drawing.Point(121, 175);
            this.txttenkhach.Name = "txttenkhach";
            this.txttenkhach.Size = new System.Drawing.Size(133, 22);
            this.txttenkhach.TabIndex = 12;
            // 
            // txthokhach
            // 
            this.txthokhach.Location = new System.Drawing.Point(120, 98);
            this.txthokhach.Name = "txthokhach";
            this.txthokhach.Size = new System.Drawing.Size(133, 22);
            this.txthokhach.TabIndex = 11;
            // 
            // txtmakhach
            // 
            this.txtmakhach.Location = new System.Drawing.Point(120, 25);
            this.txtmakhach.Name = "txtmakhach";
            this.txtmakhach.Size = new System.Drawing.Size(133, 22);
            this.txtmakhach.TabIndex = 10;
            this.txtmakhach.EditValueChanged += new System.EventHandler(this.txtmakhach_EditValueChanged_1);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.Rnu);
            this.groupControl1.Controls.Add(this.RNam);
            this.groupControl1.Location = new System.Drawing.Point(893, 17);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(170, 100);
            this.groupControl1.TabIndex = 9;
            this.groupControl1.Text = "Giới Tính";
            // 
            // Rnu
            // 
            this.Rnu.AutoSize = true;
            this.Rnu.Location = new System.Drawing.Point(100, 56);
            this.Rnu.Name = "Rnu";
            this.Rnu.Size = new System.Drawing.Size(47, 21);
            this.Rnu.TabIndex = 1;
            this.Rnu.Text = "Nữ";
            this.Rnu.UseVisualStyleBackColor = true;
            // 
            // RNam
            // 
            this.RNam.AutoSize = true;
            this.RNam.Checked = true;
            this.RNam.Location = new System.Drawing.Point(6, 56);
            this.RNam.Name = "RNam";
            this.RNam.Size = new System.Drawing.Size(57, 21);
            this.RNam.TabIndex = 0;
            this.RNam.TabStop = true;
            this.RNam.Text = "Nam";
            this.RNam.UseVisualStyleBackColor = true;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(567, 181);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(96, 17);
            this.labelControl9.TabIndex = 8;
            this.labelControl9.Text = "Mã Loại Khách :";
            // 
            // lb1
            // 
            this.lb1.Location = new System.Drawing.Point(567, 104);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(51, 17);
            this.lb1.TabIndex = 7;
            this.lb1.Text = "Địa Chỉ :";
            // 
            // lb
            // 
            this.lb.Location = new System.Drawing.Point(567, 27);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(128, 17);
            this.lb.TabIndex = 6;
            this.lb.Text = "Họ Tên Người Thân :";
            // 
            // lnsdt
            // 
            this.lnsdt.Location = new System.Drawing.Point(303, 183);
            this.lnsdt.Name = "lnsdt";
            this.lnsdt.Size = new System.Drawing.Size(93, 17);
            this.lnsdt.TabIndex = 5;
            this.lnsdt.Text = "Số Điện Thoại :";
            this.lnsdt.Click += new System.EventHandler(this.lnsdt_Click);
            // 
            // lbnamsinh
            // 
            this.lbnamsinh.Location = new System.Drawing.Point(303, 101);
            this.lbnamsinh.Name = "lbnamsinh";
            this.lbnamsinh.Size = new System.Drawing.Size(64, 16);
            this.lbnamsinh.TabIndex = 4;
            this.lbnamsinh.Text = "Năm Sinh :";
            this.lbnamsinh.Click += new System.EventHandler(this.lbnamsinh_Click);
            // 
            // lbcmnd
            // 
            this.lbcmnd.Location = new System.Drawing.Point(303, 25);
            this.lbcmnd.Name = "lbcmnd";
            this.lbcmnd.Size = new System.Drawing.Size(67, 17);
            this.lbcmnd.TabIndex = 3;
            this.lbcmnd.Text = "Số CMND :";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(13, 175);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(4, 16);
            this.labelControl3.TabIndex = 2;
            this.labelControl3.Text = " ";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(13, 101);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(103, 17);
            this.labelControl2.TabIndex = 1;
            this.labelControl2.Text = "Họ Khách Thuê :";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(13, 25);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(97, 16);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Mã Khách Thuê :";
            // 
            // panelControl2
            // 
            this.panelControl2.AutoSize = true;
            this.panelControl2.Controls.Add(this.GridKH);
            this.panelControl2.Location = new System.Drawing.Point(0, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(1260, 288);
            this.panelControl2.TabIndex = 0;
            // 
            // GridKH
            // 
            this.GridKH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridKH.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridKH.Location = new System.Drawing.Point(2, 2);
            this.GridKH.Name = "GridKH";
            this.GridKH.RowTemplate.Height = 24;
            this.GridKH.Size = new System.Drawing.Size(1256, 284);
            this.GridKH.TabIndex = 0;
            this.GridKH.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridKH_CellClick);
            // 
            // GridKhach
            // 
            this.GridKhach.Location = new System.Drawing.Point(2, 553);
            this.GridKhach.MainView = this.gridView1;
            this.GridKhach.Name = "GridKhach";
            this.GridKhach.Size = new System.Drawing.Size(1775, 200);
            this.GridKhach.TabIndex = 2;
            this.GridKhach.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.GridKhach;
            this.gridView1.Name = "gridView1";
            // 
            // KhachThueForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1775, 753);
            this.Controls.Add(this.panelControl1);
            this.Name = "KhachThueForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Thông Tin Khách Thuê";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtdiachi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttennguoithan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsdt.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamsinh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenkhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthokhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmakhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridKH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridKhach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private System.Windows.Forms.DataGridView GridKH;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private System.Windows.Forms.ComboBox comboLoaikhach;
        private DevExpress.XtraEditors.SimpleButton btnTimKiem;
        private DevExpress.XtraEditors.SimpleButton btnxoa;
        private DevExpress.XtraEditors.SimpleButton btnsua;
        private DevExpress.XtraEditors.SimpleButton btnthem;
        private DevExpress.XtraEditors.TextEdit txtdiachi;
        private DevExpress.XtraEditors.TextEdit txttennguoithan;
        private DevExpress.XtraEditors.TextEdit txtsdt;
        private DevExpress.XtraEditors.TextEdit txtnamsinh;
        private DevExpress.XtraEditors.TextEdit txtcmnd;
        private DevExpress.XtraEditors.TextEdit txttenkhach;
        private DevExpress.XtraEditors.TextEdit txthokhach;
        private DevExpress.XtraEditors.TextEdit txtmakhach;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.RadioButton Rnu;
        private System.Windows.Forms.RadioButton RNam;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl lb1;
        private DevExpress.XtraEditors.LabelControl lb;
        private DevExpress.XtraEditors.LabelControl lnsdt;
        private DevExpress.XtraEditors.LabelControl lbnamsinh;
        private DevExpress.XtraEditors.LabelControl lbcmnd;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.GridControl GridKhach;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}