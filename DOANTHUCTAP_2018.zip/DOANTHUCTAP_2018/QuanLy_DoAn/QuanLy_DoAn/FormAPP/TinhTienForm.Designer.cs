﻿namespace QuanLy_DoAn.FormAPP
{
    partial class TinhTienForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnxemPhieu = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.txtngaylap = new DevExpress.XtraEditors.DateEdit();
            this.comboTRPhieu = new System.Windows.Forms.ComboBox();
            this.txtghichu = new System.Windows.Forms.TextBox();
            this.txtmaphieu = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnthanhtoan = new DevExpress.XtraEditors.SimpleButton();
            this.btnxuatphieu = new DevExpress.XtraEditors.SimpleButton();
            this.btnthem = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.txttongtien = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.label4 = new System.Windows.Forms.Label();
            this.txttienmang = new DevExpress.XtraEditors.TextEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.txttiennuoc = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txttiendien = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.nuocmoi = new DevExpress.XtraEditors.TextEdit();
            this.nuoccu = new DevExpress.XtraEditors.TextEdit();
            this.txtsomoi = new DevExpress.XtraEditors.TextEdit();
            this.txtsocu = new DevExpress.XtraEditors.TextEdit();
            this.checkmang = new System.Windows.Forms.CheckBox();
            this.checknuoc = new System.Windows.Forms.CheckBox();
            this.checkdien = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtmakhach = new DevExpress.XtraEditors.TextEdit();
            this.txthotenkhach = new DevExpress.XtraEditors.TextEdit();
            this.txtnghenghiep = new DevExpress.XtraEditors.TextEdit();
            this.txtdiachi = new DevExpress.XtraEditors.TextEdit();
            this.lb1 = new DevExpress.XtraEditors.LabelControl();
            this.txtsdt = new DevExpress.XtraEditors.TextEdit();
            this.lnsdt = new DevExpress.XtraEditors.LabelControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.Rnu = new System.Windows.Forms.RadioButton();
            this.RNam = new System.Windows.Forms.RadioButton();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtloaiphong = new DevExpress.XtraEditors.TextEdit();
            this.txtmaphong = new DevExpress.XtraEditors.TextEdit();
            this.comboPhong = new System.Windows.Forms.ComboBox();
            this.comboKV = new System.Windows.Forms.ComboBox();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txttiennha = new DevExpress.XtraEditors.TextEdit();
            this.panel1 = new System.Windows.Forms.Panel();
            this.GridCTPT = new System.Windows.Forms.DataGridView();
            this.GridPT = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtngaylap.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtngaylap.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphieu.Properties)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttongtien.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttienmang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttiennuoc.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttiendien.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuocmoi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuoccu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsomoi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsocu.Properties)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmakhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthotenkhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnghenghiep.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdiachi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsdt.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtloaiphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttiennha.Properties)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridCTPT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPT)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnxemPhieu);
            this.groupBox1.Controls.Add(this.simpleButton1);
            this.groupBox1.Controls.Add(this.txtngaylap);
            this.groupBox1.Controls.Add(this.comboTRPhieu);
            this.groupBox1.Controls.Add(this.txtghichu);
            this.groupBox1.Controls.Add(this.txtmaphieu);
            this.groupBox1.Controls.Add(this.labelControl5);
            this.groupBox1.Controls.Add(this.labelControl4);
            this.groupBox1.Controls.Add(this.labelControl3);
            this.groupBox1.Controls.Add(this.labelControl2);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Red;
            this.groupBox1.Location = new System.Drawing.Point(1, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1354, 680);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PHIẾU THU TIỀN TRỌ ";
            // 
            // btnxemPhieu
            // 
            this.btnxemPhieu.Location = new System.Drawing.Point(1078, 72);
            this.btnxemPhieu.Name = "btnxemPhieu";
            this.btnxemPhieu.Size = new System.Drawing.Size(105, 45);
            this.btnxemPhieu.TabIndex = 12;
            this.btnxemPhieu.Text = "Xem Phiếu Thu";
            this.btnxemPhieu.Click += new System.EventHandler(this.btnxemPhieu_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(1078, 21);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(105, 45);
            this.simpleButton1.TabIndex = 11;
            this.simpleButton1.Text = "Lập Phiếu Thu";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // txtngaylap
            // 
            this.txtngaylap.EditValue = null;
            this.txtngaylap.Location = new System.Drawing.Point(327, 62);
            this.txtngaylap.Name = "txtngaylap";
            this.txtngaylap.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtngaylap.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtngaylap.Size = new System.Drawing.Size(180, 25);
            this.txtngaylap.TabIndex = 10;
            // 
            // comboTRPhieu
            // 
            this.comboTRPhieu.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboTRPhieu.FormattingEnabled = true;
            this.comboTRPhieu.Location = new System.Drawing.Point(618, 63);
            this.comboTRPhieu.Name = "comboTRPhieu";
            this.comboTRPhieu.Size = new System.Drawing.Size(121, 24);
            this.comboTRPhieu.TabIndex = 9;
            // 
            // txtghichu
            // 
            this.txtghichu.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtghichu.Location = new System.Drawing.Point(816, 63);
            this.txtghichu.Multiline = true;
            this.txtghichu.Name = "txtghichu";
            this.txtghichu.Size = new System.Drawing.Size(218, 44);
            this.txtghichu.TabIndex = 8;
            // 
            // txtmaphieu
            // 
            this.txtmaphieu.Location = new System.Drawing.Point(84, 66);
            this.txtmaphieu.Name = "txtmaphieu";
            this.txtmaphieu.Size = new System.Drawing.Size(120, 22);
            this.txtmaphieu.TabIndex = 7;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(757, 68);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(53, 16);
            this.labelControl5.TabIndex = 6;
            this.labelControl5.Text = "Ghi Chú :";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(522, 69);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(75, 17);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "Tình Trạng :";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(245, 66);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(67, 17);
            this.labelControl3.TabIndex = 4;
            this.labelControl3.Text = "Ngày Lập :";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(15, 67);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(63, 17);
            this.labelControl2.TabIndex = 3;
            this.labelControl2.Text = "Mã Phiếu :";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnthanhtoan);
            this.groupBox4.Controls.Add(this.btnxuatphieu);
            this.groupBox4.Controls.Add(this.btnthem);
            this.groupBox4.Controls.Add(this.simpleButton2);
            this.groupBox4.Controls.Add(this.labelControl18);
            this.groupBox4.Controls.Add(this.labelControl17);
            this.groupBox4.Controls.Add(this.txttongtien);
            this.groupBox4.Controls.Add(this.labelControl16);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txttienmang);
            this.groupBox4.Controls.Add(this.labelControl15);
            this.groupBox4.Controls.Add(this.txttiennuoc);
            this.groupBox4.Controls.Add(this.labelControl14);
            this.groupBox4.Controls.Add(this.txttiendien);
            this.groupBox4.Controls.Add(this.labelControl13);
            this.groupBox4.Controls.Add(this.groupControl1);
            this.groupBox4.Controls.Add(this.nuocmoi);
            this.groupBox4.Controls.Add(this.nuoccu);
            this.groupBox4.Controls.Add(this.txtsomoi);
            this.groupBox4.Controls.Add(this.txtsocu);
            this.groupBox4.Controls.Add(this.checkmang);
            this.groupBox4.Controls.Add(this.checknuoc);
            this.groupBox4.Controls.Add(this.checkdien);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Red;
            this.groupBox4.Location = new System.Drawing.Point(766, 123);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(588, 400);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông tin dịch vụ ";
            // 
            // btnthanhtoan
            // 
            this.btnthanhtoan.Location = new System.Drawing.Point(264, 334);
            this.btnthanhtoan.Name = "btnthanhtoan";
            this.btnthanhtoan.Size = new System.Drawing.Size(121, 45);
            this.btnthanhtoan.TabIndex = 33;
            this.btnthanhtoan.Text = "Thanh Toán";
            this.btnthanhtoan.Click += new System.EventHandler(this.simpleButton5_Click);
            // 
            // btnxuatphieu
            // 
            this.btnxuatphieu.Location = new System.Drawing.Point(427, 334);
            this.btnxuatphieu.Name = "btnxuatphieu";
            this.btnxuatphieu.Size = new System.Drawing.Size(129, 45);
            this.btnxuatphieu.TabIndex = 32;
            this.btnxuatphieu.Text = "Xuất Phiếu Tiền ";
            this.btnxuatphieu.Click += new System.EventHandler(this.simpleButton4_Click);
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(264, 264);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(121, 45);
            this.btnthem.TabIndex = 31;
            this.btnthem.Text = "Thêm khoản thu";
            this.btnthem.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Location = new System.Drawing.Point(427, 264);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(129, 45);
            this.simpleButton2.TabIndex = 30;
            this.simpleButton2.Text = "Tính Tiền";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(241, 40);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(63, 17);
            this.labelControl18.TabIndex = 29;
            this.labelControl18.Text = "Chỉ số mới";
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(116, 40);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(56, 17);
            this.labelControl17.TabIndex = 28;
            this.labelControl17.Text = "Chỉ số cũ";
            // 
            // txttongtien
            // 
            this.txttongtien.EditValue = "0";
            this.txttongtien.Location = new System.Drawing.Point(391, 230);
            this.txttongtien.Name = "txttongtien";
            this.txttongtien.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttongtien.Properties.Appearance.Options.UseFont = true;
            this.txttongtien.Size = new System.Drawing.Size(165, 22);
            this.txttongtien.TabIndex = 27;
            // 
            // labelControl16
            // 
            this.labelControl16.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl16.Location = new System.Drawing.Point(253, 233);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(132, 17);
            this.labelControl16.TabIndex = 26;
            this.labelControl16.Text = "Tổng tiền phải trả :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(281, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(315, 34);
            this.label4.TabIndex = 25;
            this.label4.Text = "-------------------------";
            // 
            // txttienmang
            // 
            this.txttienmang.Location = new System.Drawing.Point(431, 165);
            this.txttienmang.Name = "txttienmang";
            this.txttienmang.Size = new System.Drawing.Size(105, 22);
            this.txttienmang.TabIndex = 24;
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(345, 170);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(73, 17);
            this.labelControl15.TabIndex = 23;
            this.labelControl15.Text = "Tiền mạng :";
            // 
            // txttiennuoc
            // 
            this.txttiennuoc.EditValue = "0";
            this.txttiennuoc.Location = new System.Drawing.Point(431, 124);
            this.txttiennuoc.Name = "txttiennuoc";
            this.txttiennuoc.Size = new System.Drawing.Size(105, 22);
            this.txttiennuoc.TabIndex = 22;
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(345, 127);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(70, 17);
            this.labelControl14.TabIndex = 21;
            this.labelControl14.Text = "Tiền nước :";
            // 
            // txttiendien
            // 
            this.txttiendien.EditValue = "0";
            this.txttiendien.Location = new System.Drawing.Point(431, 75);
            this.txttiendien.Name = "txttiendien";
            this.txttiendien.Size = new System.Drawing.Size(105, 22);
            this.txttiendien.TabIndex = 20;
            this.txttiendien.EditValueChanged += new System.EventHandler(this.txttiendien_EditValueChanged);
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(345, 80);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(59, 17);
            this.labelControl13.TabIndex = 19;
            this.labelControl13.Text = "Tiền điện:";
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.label3);
            this.groupControl1.Controls.Add(this.label2);
            this.groupControl1.Controls.Add(this.label1);
            this.groupControl1.Location = new System.Drawing.Point(6, 233);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(219, 161);
            this.groupControl1.TabIndex = 16;
            this.groupControl1.Text = "Thôn tin khoản thu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(14, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(207, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tiền Mạng : 55.000/ 1 tháng";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(194, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tiền Nước : 17.000/ 1 khối";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tiền Điện : 4.000/ 1 ký";
            // 
            // nuocmoi
            // 
            this.nuocmoi.Location = new System.Drawing.Point(224, 126);
            this.nuocmoi.Name = "nuocmoi";
            this.nuocmoi.Size = new System.Drawing.Size(105, 22);
            this.nuocmoi.TabIndex = 15;
            this.nuocmoi.EditValueChanged += new System.EventHandler(this.nuocmoi_EditValueChanged);
            // 
            // nuoccu
            // 
            this.nuoccu.Location = new System.Drawing.Point(95, 126);
            this.nuoccu.Name = "nuoccu";
            this.nuoccu.Size = new System.Drawing.Size(105, 22);
            this.nuoccu.TabIndex = 14;
            this.nuoccu.EditValueChanged += new System.EventHandler(this.nuoccu_EditValueChanged);
            // 
            // txtsomoi
            // 
            this.txtsomoi.Location = new System.Drawing.Point(224, 63);
            this.txtsomoi.Name = "txtsomoi";
            this.txtsomoi.Size = new System.Drawing.Size(105, 22);
            this.txtsomoi.TabIndex = 13;
            this.txtsomoi.EditValueChanged += new System.EventHandler(this.txtsomoi_EditValueChanged);
            // 
            // txtsocu
            // 
            this.txtsocu.Location = new System.Drawing.Point(95, 63);
            this.txtsocu.Name = "txtsocu";
            this.txtsocu.Size = new System.Drawing.Size(105, 22);
            this.txtsocu.TabIndex = 12;
            this.txtsocu.EditValueChanged += new System.EventHandler(this.txtsocu_EditValueChanged);
            // 
            // checkmang
            // 
            this.checkmang.AutoSize = true;
            this.checkmang.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkmang.Location = new System.Drawing.Point(21, 181);
            this.checkmang.Name = "checkmang";
            this.checkmang.Size = new System.Drawing.Size(137, 21);
            this.checkmang.TabIndex = 2;
            this.checkmang.Text = "mạng internet :";
            this.checkmang.UseVisualStyleBackColor = true;
            this.checkmang.CheckedChanged += new System.EventHandler(this.checkmang_CheckedChanged);
            // 
            // checknuoc
            // 
            this.checknuoc.AutoSize = true;
            this.checknuoc.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checknuoc.Location = new System.Drawing.Point(21, 127);
            this.checknuoc.Name = "checknuoc";
            this.checknuoc.Size = new System.Drawing.Size(74, 21);
            this.checknuoc.TabIndex = 1;
            this.checknuoc.Text = "nước :";
            this.checknuoc.UseVisualStyleBackColor = true;
            this.checknuoc.CheckedChanged += new System.EventHandler(this.checknuoc_CheckedChanged);
            // 
            // checkdien
            // 
            this.checkdien.AutoSize = true;
            this.checkdien.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkdien.Location = new System.Drawing.Point(21, 66);
            this.checkdien.Name = "checkdien";
            this.checkdien.Size = new System.Drawing.Size(68, 21);
            this.checkdien.TabIndex = 0;
            this.checkdien.Text = "điện :";
            this.checkdien.UseVisualStyleBackColor = true;
            this.checkdien.CheckedChanged += new System.EventHandler(this.checkdien_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtmakhach);
            this.groupBox3.Controls.Add(this.txthotenkhach);
            this.groupBox3.Controls.Add(this.txtnghenghiep);
            this.groupBox3.Controls.Add(this.txtdiachi);
            this.groupBox3.Controls.Add(this.lb1);
            this.groupBox3.Controls.Add(this.txtsdt);
            this.groupBox3.Controls.Add(this.lnsdt);
            this.groupBox3.Controls.Add(this.groupControl2);
            this.groupBox3.Controls.Add(this.labelControl11);
            this.groupBox3.Controls.Add(this.labelControl10);
            this.groupBox3.Controls.Add(this.labelControl9);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Red;
            this.groupBox3.Location = new System.Drawing.Point(396, 123);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(325, 400);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Thông tin khách";
            // 
            // txtmakhach
            // 
            this.txtmakhach.Location = new System.Drawing.Point(81, 38);
            this.txtmakhach.Name = "txtmakhach";
            this.txtmakhach.Size = new System.Drawing.Size(133, 22);
            this.txtmakhach.TabIndex = 54;
            this.txtmakhach.EditValueChanged += new System.EventHandler(this.txtmakhach_EditValueChanged);
            // 
            // txthotenkhach
            // 
            this.txthotenkhach.Location = new System.Drawing.Point(81, 90);
            this.txthotenkhach.Name = "txthotenkhach";
            this.txthotenkhach.Size = new System.Drawing.Size(133, 22);
            this.txthotenkhach.TabIndex = 53;
            // 
            // txtnghenghiep
            // 
            this.txtnghenghiep.Location = new System.Drawing.Point(103, 138);
            this.txtnghenghiep.Name = "txtnghenghiep";
            this.txtnghenghiep.Size = new System.Drawing.Size(133, 22);
            this.txtnghenghiep.TabIndex = 52;
            // 
            // txtdiachi
            // 
            this.txtdiachi.Location = new System.Drawing.Point(79, 234);
            this.txtdiachi.Name = "txtdiachi";
            this.txtdiachi.Size = new System.Drawing.Size(133, 22);
            this.txtdiachi.TabIndex = 51;
            // 
            // lb1
            // 
            this.lb1.Location = new System.Drawing.Point(6, 239);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(51, 17);
            this.lb1.TabIndex = 50;
            this.lb1.Text = "Địa Chỉ :";
            // 
            // txtsdt
            // 
            this.txtsdt.Location = new System.Drawing.Point(103, 187);
            this.txtsdt.Name = "txtsdt";
            this.txtsdt.Size = new System.Drawing.Size(133, 22);
            this.txtsdt.TabIndex = 49;
            // 
            // lnsdt
            // 
            this.lnsdt.Location = new System.Drawing.Point(6, 190);
            this.lnsdt.Name = "lnsdt";
            this.lnsdt.Size = new System.Drawing.Size(93, 17);
            this.lnsdt.TabIndex = 48;
            this.lnsdt.Text = "Số Điện Thoại :";
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.Rnu);
            this.groupControl2.Controls.Add(this.RNam);
            this.groupControl2.Location = new System.Drawing.Point(6, 284);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(170, 57);
            this.groupControl2.TabIndex = 47;
            this.groupControl2.Text = "Giới Tính";
            // 
            // Rnu
            // 
            this.Rnu.AutoSize = true;
            this.Rnu.Location = new System.Drawing.Point(97, 30);
            this.Rnu.Name = "Rnu";
            this.Rnu.Size = new System.Drawing.Size(47, 21);
            this.Rnu.TabIndex = 1;
            this.Rnu.Text = "Nữ";
            this.Rnu.UseVisualStyleBackColor = true;
            // 
            // RNam
            // 
            this.RNam.AutoSize = true;
            this.RNam.Checked = true;
            this.RNam.Location = new System.Drawing.Point(5, 30);
            this.RNam.Name = "RNam";
            this.RNam.Size = new System.Drawing.Size(57, 21);
            this.RNam.TabIndex = 0;
            this.RNam.TabStop = true;
            this.RNam.Text = "Nam";
            this.RNam.UseVisualStyleBackColor = true;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(6, 141);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(86, 17);
            this.labelControl11.TabIndex = 15;
            this.labelControl11.Text = "Nghề nghiệp :";
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(6, 90);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(69, 16);
            this.labelControl10.TabIndex = 14;
            this.labelControl10.Text = "Tên Khách :";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(6, 41);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(64, 16);
            this.labelControl9.TabIndex = 13;
            this.labelControl9.Text = "Mã Khách :";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtloaiphong);
            this.groupBox2.Controls.Add(this.txtmaphong);
            this.groupBox2.Controls.Add(this.comboPhong);
            this.groupBox2.Controls.Add(this.comboKV);
            this.groupBox2.Controls.Add(this.labelControl8);
            this.groupBox2.Controls.Add(this.labelControl7);
            this.groupBox2.Controls.Add(this.labelControl6);
            this.groupBox2.Controls.Add(this.labelControl1);
            this.groupBox2.Controls.Add(this.labelControl12);
            this.groupBox2.Controls.Add(this.txttiennha);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(3, 115);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(325, 400);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Thông tin phòng ";
            // 
            // txtloaiphong
            // 
            this.txtloaiphong.Location = new System.Drawing.Point(117, 193);
            this.txtloaiphong.Name = "txtloaiphong";
            this.txtloaiphong.Size = new System.Drawing.Size(143, 22);
            this.txtloaiphong.TabIndex = 12;
            // 
            // txtmaphong
            // 
            this.txtmaphong.Location = new System.Drawing.Point(117, 139);
            this.txtmaphong.Name = "txtmaphong";
            this.txtmaphong.Size = new System.Drawing.Size(143, 22);
            this.txtmaphong.TabIndex = 11;
            this.txtmaphong.EditValueChanged += new System.EventHandler(this.txtmaphong_EditValueChanged);
            // 
            // comboPhong
            // 
            this.comboPhong.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboPhong.FormattingEnabled = true;
            this.comboPhong.Location = new System.Drawing.Point(117, 90);
            this.comboPhong.Name = "comboPhong";
            this.comboPhong.Size = new System.Drawing.Size(143, 24);
            this.comboPhong.TabIndex = 5;
            this.comboPhong.SelectedIndexChanged += new System.EventHandler(this.comboPhong_SelectedIndexChanged);
            // 
            // comboKV
            // 
            this.comboKV.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboKV.FormattingEnabled = true;
            this.comboKV.Location = new System.Drawing.Point(117, 41);
            this.comboKV.Name = "comboKV";
            this.comboKV.Size = new System.Drawing.Size(143, 24);
            this.comboKV.TabIndex = 4;
            this.comboKV.SelectedIndexChanged += new System.EventHandler(this.comboKV_SelectedIndexChanged);
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(12, 198);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(77, 17);
            this.labelControl8.TabIndex = 3;
            this.labelControl8.Text = "Loại Phòng :";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(12, 41);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(98, 17);
            this.labelControl7.TabIndex = 2;
            this.labelControl7.Text = "Chọn Khu Vực :";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(12, 142);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(65, 16);
            this.labelControl6.TabIndex = 1;
            this.labelControl6.Text = "Mã Phòng :";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(12, 90);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(86, 17);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Chọn Phòng :";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(12, 247);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(61, 17);
            this.labelControl12.TabIndex = 17;
            this.labelControl12.Text = "Tiền nhà :";
            // 
            // txttiennha
            // 
            this.txttiennha.Location = new System.Drawing.Point(117, 244);
            this.txttiennha.Name = "txttiennha";
            this.txttiennha.Size = new System.Drawing.Size(143, 22);
            this.txttiennha.TabIndex = 18;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.GridCTPT);
            this.panel1.Controls.Add(this.GridPT);
            this.panel1.Location = new System.Drawing.Point(1, 534);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1354, 159);
            this.panel1.TabIndex = 3;
            // 
            // GridCTPT
            // 
            this.GridCTPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridCTPT.Location = new System.Drawing.Point(608, 0);
            this.GridCTPT.Name = "GridCTPT";
            this.GridCTPT.RowTemplate.Height = 24;
            this.GridCTPT.Size = new System.Drawing.Size(746, 159);
            this.GridCTPT.TabIndex = 1;
            this.GridCTPT.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridCTPT_CellClick);
            // 
            // GridPT
            // 
            this.GridPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridPT.Location = new System.Drawing.Point(0, 0);
            this.GridPT.Name = "GridPT";
            this.GridPT.RowTemplate.Height = 24;
            this.GridPT.Size = new System.Drawing.Size(610, 159);
            this.GridPT.TabIndex = 0;
            this.GridPT.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridPT_CellClick);
            // 
            // TinhTienForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1360, 691);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox1);
            this.Name = "TinhTienForm";
            this.Text = "Tính Tiền Điện Nước";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtngaylap.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtngaylap.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphieu.Properties)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txttongtien.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttienmang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttiennuoc.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttiendien.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nuocmoi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nuoccu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsomoi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsocu.Properties)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmakhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthotenkhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnghenghiep.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdiachi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsdt.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtloaiphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttiennha.Properties)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridCTPT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridPT)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView GridPT;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtghichu;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.DateEdit txtngaylap;
        private System.Windows.Forms.ComboBox comboTRPhieu;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit txtloaiphong;
        private DevExpress.XtraEditors.TextEdit txtmaphong;
        private System.Windows.Forms.ComboBox comboPhong;
        private System.Windows.Forms.ComboBox comboKV;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.RadioButton Rnu;
        private System.Windows.Forms.RadioButton RNam;
        private DevExpress.XtraEditors.TextEdit txtsdt;
        private DevExpress.XtraEditors.LabelControl lnsdt;
        private DevExpress.XtraEditors.TextEdit txtmakhach;
        private DevExpress.XtraEditors.TextEdit txthotenkhach;
        private DevExpress.XtraEditors.TextEdit txtnghenghiep;
        private DevExpress.XtraEditors.TextEdit txtdiachi;
        private DevExpress.XtraEditors.LabelControl lb1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit nuocmoi;
        private DevExpress.XtraEditors.TextEdit nuoccu;
        private DevExpress.XtraEditors.TextEdit txtsomoi;
        private DevExpress.XtraEditors.TextEdit txtsocu;
        private System.Windows.Forms.CheckBox checkmang;
        private System.Windows.Forms.CheckBox checknuoc;
        private System.Windows.Forms.CheckBox checkdien;
        private System.Windows.Forms.Label label4;
        private DevExpress.XtraEditors.TextEdit txttienmang;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.TextEdit txttiennuoc;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txttiendien;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txttiennha;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txttongtien;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private System.Windows.Forms.DataGridView GridCTPT;
        private DevExpress.XtraEditors.SimpleButton btnthem;
        private DevExpress.XtraEditors.SimpleButton btnxemPhieu;
        private DevExpress.XtraEditors.SimpleButton btnxuatphieu;
        private DevExpress.XtraEditors.SimpleButton btnthanhtoan;
        public DevExpress.XtraEditors.TextEdit txtmaphieu;

    }
}