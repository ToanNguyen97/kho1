﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DTO;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.BLL;

namespace QuanLy_DoAn.FormAPP
{
    public partial class SoDoTroForm : DevExpress.XtraEditors.XtraForm
    {
        public SoDoTroForm()
        {
            InitializeComponent();
            Load();
            probarcooldow.Visible = false;
            btndatphong.Visible = false ;
            
        }      
            private Form KiemTraTonTai(Type fType)
        {
            foreach (Form f in this.MdiParent.MdiChildren)
            {
                if (f.GetType() == fType)    // Neu Form duoc truyen vao da duoc mo
                {
                    return f;
                }
            }
            return null;
        }

        private void Load()
        {
            comboNoiQuy.DataSource = NoiQuyDAO.Instance.LoadNoiQuy();
            comboNoiQuy.DisplayMember = "TenNoiQuy";
            comboNoiQuy.ValueMember = "MaNoiQuy";
            comboLoaiPhong.DataSource = LoaiPhongDAO.Instance.LoadCBLoaiPhong();
            comboLoaiPhong.DisplayMember = "TenLoaiPhong";
            comboLoaiPhong.ValueMember = "MaLoaiPhong";
            comboGia.DataSource = LoaiPhongDAO.Instance.LoadCBLoaiPhong();
            comboGia.ValueMember = "MaLoaiPhong";
            comboGia.DisplayMember = "GiaPhong";
            comboTR.DataSource = TinhTrangPhongDAO.Instance.LoadCBTRINHTRANG();
            comboTR.DisplayMember = "TenTinhTrang";
            comboTR.ValueMember = "MaTinhTrang";
            combokhuphong.DataSource = KhuPhongDAO.Instance.LoadListKP();
            combokhuphong.DisplayMember = "TenKhuPhong";
            combokhuphong.ValueMember = "MaKhuPhong";
            //combokhuphong.DataSource = KhuPhongDAO.Instance.LoadKhuPhong();
            //combokhuphong.DisplayMember = "TenKhuPhong";
            //combokhuphong.ValueMember = "MaKhuPhong";
            comLoaip.DataSource = LoaiPhongDAO.Instance.LoadCBLoaiPhong();
            comLoaip.DisplayMember = "TenLoaiPhong";
            comLoaip.ValueMember = "MaLoaiPhong";
            combotinhtrang.DataSource = TinhTrangPhongDAO.Instance.LoadCBTRINHTRANG();
            combotinhtrang.DisplayMember = "TenTinhTrang";
            combotinhtrang.ValueMember = "MaTinhTrang";
            comboGia.DataSource = LoaiPhongDAO.Instance.LoadCBLoaiPhong();
            comboGia.DisplayMember = "GiaPhong";
            comboGia.ValueMember = "MaLoaiPhong";
            comboGiaPhong.DataSource = LoaiPhongDAO.Instance.LoadCBLoaiPhong();
            comboGiaPhong.DisplayMember = "GiaPhong";
            comboGiaPhong.ValueMember = "MaLoaiPhong";
            txtnoidung.Text = NoiQuyDAO.Instance.getNoiDungByID(comboNoiQuy.SelectedValue.ToString());
        }
        private void btnkhuvuc1_Click(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaPhong("KV01");
            foreach(PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch(item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;                       
                        break;
                }
            }
            btnkhuvuc1.Enabled = false;
            btnkhuvuc2.Enabled = true;
            btnkhuvuc3.Enabled = true;
            btnkhuvuc4.Enabled = true;
        }

        public  void btn_Click(object sender, EventArgs e)
        {
           // throw new NotImplementedException();
            if (TinhTrangPhongBLL.Instance.GetMaByTen(((sender as Button).Tag as PhongDTO).MaTinhTrang) != "TR01")
                btndatphong.Visible = false;
            else
                btndatphong.Visible = true;
            txtmaphong.Text = ((sender as Button).Tag as PhongDTO).MaPhong;
            txttenphong.Text = ((sender as Button).Tag as PhongDTO).TenPhong;
            comLoaip.SelectedValue = ((sender as Button).Tag as PhongDTO).MaLoaiPhong;
            combokhuphong.SelectedValue = ((sender as Button).Tag as PhongDTO).MaKhuPhong;
            combotinhtrang.SelectedValue = TinhTrangPhongBLL.Instance.GetMaByTen(((sender as Button).Tag as PhongDTO).MaTinhTrang);
            comboGiaPhong.SelectedValue = ((sender as Button).Tag as PhongDTO).MaLoaiPhong;
            txtghichu.Text = ((sender as Button).Tag as PhongDTO).GhiChu;
            txtmanoiquy.Text = ((sender as Button).Tag as PhongDTO).MaNoiQuy;
            if(combotinhtrang.SelectedValue.ToString().Equals("TR04"))
            {
                probarcooldow.Visible = true;
                DemNguoc();
            }else
            {
                probarcooldow.Visible = false;
            }
        } 
      

        private void btnkhuvuc2_Click(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaPhong("KV02");
            foreach (PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                        break;
                }
            }
            btnkhuvuc1.Enabled = true;
            btnkhuvuc2.Enabled = false;
            btnkhuvuc3.Enabled = true;
            btnkhuvuc4.Enabled = true;
        }

        private void btnkhuvuc3_Click(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaPhong("KV03");
            foreach (PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                        break;
                }
            }
            btnkhuvuc1.Enabled = true;
            btnkhuvuc2.Enabled = true;
            btnkhuvuc3.Enabled = false;
            btnkhuvuc4.Enabled = true;
        }

        private void btnkhuvuc4_Click(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaPhong("KV04");
            foreach (PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                        break;
                }
            }
            btnkhuvuc1.Enabled = true;
            btnkhuvuc2.Enabled = true;
            btnkhuvuc3.Enabled = true;
            btnkhuvuc4.Enabled = false;
        }

        private void comboLoaiPhong_SelectedIndexChanged(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();           
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaLoaiPhong(comboLoaiPhong.SelectedValue.ToString());
            foreach (PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.MaKhuPhong + Environment.NewLine + item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                        break;
                }
            }
        }

        private void comboTR_SelectedIndexChanged(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaTinhTrang(comboTR.SelectedValue.ToString());
            foreach (PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.MaKhuPhong + Environment.NewLine + item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                    
                        break;
                }
            }
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            try {
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text, txttenphong.Text, comLoaip.SelectedValue.ToString(), combokhuphong.SelectedValue.ToString(), "TR01", txtghichu.Text, txtmanoiquy.Text);
                PhongDAO.Instance.Phong_Them(phongdto);
                // dùng để load lại danh sách sau khi thêm sửa xóa
                if (btnkhuvuc1.Enabled == false)
                    btnkhuvuc1_Click(sender, e);
                if(btnkhuvuc2.Enabled == false)
                    btnkhuvuc2_Click(sender,e);
                if (btnkhuvuc3.Enabled == false)
                    btnkhuvuc3_Click(sender, e);
                if (btnkhuvuc4.Enabled == false) 
                    btnkhuvuc4_Click(sender, e);
                XtraMessageBox.Show("Thành công!!");
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }
            
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            try
            {
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text, txttenphong.Text, comLoaip.SelectedValue.ToString(), combokhuphong.SelectedValue.ToString(), combotinhtrang.SelectedValue.ToString(), txtghichu.Text, txtmanoiquy.Text);
                PhongDAO.Instance.Phong_Sua(phongdto);
                if (btnkhuvuc1.Enabled == false)
                    btnkhuvuc1_Click(sender, e);
                if (btnkhuvuc2.Enabled == false)
                    btnkhuvuc2_Click(sender, e);
                if (btnkhuvuc3.Enabled == false)
                    btnkhuvuc3_Click(sender, e);
                if (btnkhuvuc4.Enabled == false)
                    btnkhuvuc4_Click(sender, e);
                XtraMessageBox.Show("Thành công!!");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            try
            {
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text);
                PhongDAO.Instance.Phong_Xoa(phongdto);
                if (btnkhuvuc1.Enabled == false)
                    btnkhuvuc1_Click(sender, e);
                if (btnkhuvuc2.Enabled == false)
                    btnkhuvuc2_Click(sender, e);
                if (btnkhuvuc3.Enabled == false)
                    btnkhuvuc3_Click(sender, e);
                if (btnkhuvuc4.Enabled == false)
                    btnkhuvuc4_Click(sender, e);
                XtraMessageBox.Show("Thành công!!");
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }
        }
        private void setFormHopDong()
        {
            HopDongThuePhong f = new HopDongThuePhong();
            f.txtmaphong.Text = txtmaphong.Text;
            f.txttenphong.Text = txttenphong.Text;
            f.txtoaiphong.Text = LoaiPhongDAO.Instance.geTenDByID(comLoaip.SelectedValue.ToString());
            f.txtghichu.Text = txtghichu.Text;
            f.txtmanoiquy.Text = txtmanoiquy.Text;
            f.comboGiaPhong.Text = LoaiPhongDAO.Instance.getGiaByID(comboGiaPhong.SelectedValue.ToString());
            f.combokhuphong.Text = KhuPhongDAO.Instance.getTenByID(combokhuphong.SelectedValue.ToString());
            f.combotinhtrang.Text = TinhTrangPhongDAO.Instance.getTenByID(combotinhtrang.SelectedValue.ToString());
            f.MdiParent = this.MdiParent;
            f.Show();
        }
        private void btndatphong_Click(object sender, EventArgs e)
        {
            /*try
            {
                probarcooldow.Visible = true;
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text, txttenphong.Text, comboLoaiPhong.SelectedValue.ToString(), combokhuphong.SelectedValue.ToString(),"TR04", txtghichu.Text, txtmanoiquy.Text);
                PhongDAO.Instance.Phong_Sua(phongdto);               
                XtraMessageBox.Show("Thành công!!");
              
               
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }*/
            combotinhtrang.SelectedValue = "TR04";
            Form frm = this.KiemTraTonTai(typeof(HopDongThuePhong));
            if (frm != null)
            {

                frm.Close();
                setFormHopDong();
            }
            else
            {
                setFormHopDong();
            }

        }

        private void comboGia_SelectedIndexChanged(object sender, EventArgs e)
        {
            panelLoadSodo.Controls.Clear();
            List<PhongDTO> tablelist = PhongDAO.Instance.LoadListbyMaLoaiPhong(comboGia.SelectedValue.ToString());
            foreach (PhongDTO item in tablelist)
            {
                Button btn = new Button() { Width = PhongDAO.PhongWith, Height = PhongDAO.PhongHeight };
                panelLoadSodo.Controls.Add(btn);
                btn.Text = item.MaKhuPhong + Environment.NewLine + item.TenPhong + Environment.NewLine + item.MaTinhTrang;
                btn.Click += btn_Click;
                btn.Tag = item;
                switch (item.MaTinhTrang)
                {
                    case "Còn Trống":
                        btn.BackColor = Color.Aqua;
                        break;
                    case "Đã Thuê":
                        btn.BackColor = Color.Yellow;
                        break;
                    case "Đang Sửa":
                        btn.BackColor = Color.LightGreen;
                        break;
                    default:
                        btn.BackColor = Color.LightPink;
                        break;
                }
            }
        }
        private void DemNguoc()
        {
            probarcooldow.Step = PhongDAO.timestep;
            probarcooldow.Maximum = PhongDAO.timeend;
            probarcooldow.Value = 0;
            timercooldown.Interval = PhongDAO.timeinterval;
            timercooldown.Start();
        }
        private void timercooldown_Tick(object sender, EventArgs e)
        {
            probarcooldow.PerformStep();
            if (probarcooldow.Value == probarcooldow.Maximum)
            {
                timercooldown.Stop();
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text, txttenphong.Text, comboLoaiPhong.SelectedValue.ToString(), combokhuphong.SelectedValue.ToString(), "TR01", txtghichu.Text, txtmanoiquy.Text);
                PhongDAO.Instance.Phong_Sua(phongdto); 
                
            }
        }

        private void comboNoiQuy_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtnoidung.Text = NoiQuyDAO.Instance.getNoiDungByID(comboNoiQuy.SelectedValue.ToString());
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/quanlynhatro/");
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.google.com/");
        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://mail.google.com/mail/u/0/");
        }

        private void simpleButton4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/messages/t/");
        }
    }
}