﻿namespace QuanLy_DoAn.FormAPP
{
    partial class QuenMKForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuenMKForm));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.Panelmk = new DevExpress.XtraEditors.PanelControl();
            this.txtxacnhan = new DevExpress.XtraEditors.TextEdit();
            this.txtmatkhau = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.comboNV = new System.Windows.Forms.ComboBox();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.btnKiemtra = new DevExpress.XtraEditors.SimpleButton();
            this.txtcmnd = new DevExpress.XtraEditors.TextEdit();
            this.txttenhienthi = new DevExpress.XtraEditors.TextEdit();
            this.txtendangnhap = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnXacNhan = new DevExpress.XtraEditors.SimpleButton();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Panelmk)).BeginInit();
            this.Panelmk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtxacnhan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmatkhau.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenhienthi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtendangnhap.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControl1
            // 
            this.groupControl1.CaptionImage = ((System.Drawing.Image)(resources.GetObject("groupControl1.CaptionImage")));
            this.groupControl1.Controls.Add(this.Panelmk);
            this.groupControl1.Controls.Add(this.btnKiemtra);
            this.groupControl1.Controls.Add(this.txtcmnd);
            this.groupControl1.Controls.Add(this.txttenhienthi);
            this.groupControl1.Controls.Add(this.txtendangnhap);
            this.groupControl1.Controls.Add(this.labelControl5);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Location = new System.Drawing.Point(1, 0);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(420, 450);
            this.groupControl1.TabIndex = 1;
            this.groupControl1.Text = "Thông Tin Tài Khoản";
            // 
            // Panelmk
            // 
            this.Panelmk.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Panelmk.Controls.Add(this.txtxacnhan);
            this.Panelmk.Controls.Add(this.txtmatkhau);
            this.Panelmk.Controls.Add(this.labelControl4);
            this.Panelmk.Controls.Add(this.labelControl3);
            this.Panelmk.Controls.Add(this.comboNV);
            this.Panelmk.Controls.Add(this.labelControl6);
            this.Panelmk.Location = new System.Drawing.Point(0, 239);
            this.Panelmk.Name = "Panelmk";
            this.Panelmk.Size = new System.Drawing.Size(420, 211);
            this.Panelmk.TabIndex = 13;
            // 
            // txtxacnhan
            // 
            this.txtxacnhan.Location = new System.Drawing.Point(132, 77);
            this.txtxacnhan.Name = "txtxacnhan";
            this.txtxacnhan.Properties.UseSystemPasswordChar = true;
            this.txtxacnhan.Size = new System.Drawing.Size(184, 22);
            this.txtxacnhan.TabIndex = 10;
            // 
            // txtmatkhau
            // 
            this.txtmatkhau.Location = new System.Drawing.Point(132, 15);
            this.txtmatkhau.Name = "txtmatkhau";
            this.txtmatkhau.Properties.UseSystemPasswordChar = true;
            this.txtmatkhau.Size = new System.Drawing.Size(184, 22);
            this.txtmatkhau.TabIndex = 9;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(7, 82);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(67, 17);
            this.labelControl4.TabIndex = 3;
            this.labelControl4.Text = "Xác Nhận :";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(6, 20);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(66, 17);
            this.labelControl3.TabIndex = 2;
            this.labelControl3.Text = "Mật Khẩu :";
            // 
            // comboNV
            // 
            this.comboNV.FormattingEnabled = true;
            this.comboNV.Location = new System.Drawing.Point(132, 133);
            this.comboNV.Name = "comboNV";
            this.comboNV.Size = new System.Drawing.Size(184, 24);
            this.comboNV.TabIndex = 6;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(7, 141);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(67, 16);
            this.labelControl6.TabIndex = 5;
            this.labelControl6.Text = "Nhân Viên :";
            // 
            // btnKiemtra
            // 
            this.btnKiemtra.Location = new System.Drawing.Point(335, 189);
            this.btnKiemtra.Name = "btnKiemtra";
            this.btnKiemtra.Size = new System.Drawing.Size(75, 23);
            this.btnKiemtra.TabIndex = 12;
            this.btnKiemtra.Text = "Kiểm Tra";
            this.btnKiemtra.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // txtcmnd
            // 
            this.txtcmnd.Location = new System.Drawing.Point(137, 188);
            this.txtcmnd.Name = "txtcmnd";
            this.txtcmnd.Size = new System.Drawing.Size(184, 22);
            this.txtcmnd.TabIndex = 11;
            // 
            // txttenhienthi
            // 
            this.txttenhienthi.Location = new System.Drawing.Point(137, 121);
            this.txttenhienthi.Name = "txttenhienthi";
            this.txttenhienthi.Size = new System.Drawing.Size(184, 22);
            this.txttenhienthi.TabIndex = 8;
            // 
            // txtendangnhap
            // 
            this.txtendangnhap.Location = new System.Drawing.Point(137, 60);
            this.txtendangnhap.Name = "txtendangnhap";
            this.txtendangnhap.Size = new System.Drawing.Size(184, 22);
            this.txtendangnhap.TabIndex = 7;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(11, 193);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(67, 17);
            this.labelControl5.TabIndex = 4;
            this.labelControl5.Text = "Số CMND :";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(12, 124);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(84, 17);
            this.labelControl2.TabIndex = 1;
            this.labelControl2.Text = "Tên Hiển Thị :";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(12, 60);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(105, 17);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Tên Đăng Nhập :";
            // 
            // btnXacNhan
            // 
            this.btnXacNhan.Location = new System.Drawing.Point(31, 457);
            this.btnXacNhan.Name = "btnXacNhan";
            this.btnXacNhan.Size = new System.Drawing.Size(122, 39);
            this.btnXacNhan.TabIndex = 2;
            this.btnXacNhan.Text = "Xác Nhận";
            this.btnXacNhan.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(253, 457);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(122, 39);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // QuenMKForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(423, 508);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnXacNhan);
            this.Controls.Add(this.groupControl1);
            this.Name = "QuenMKForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quên Mật Khẩu";
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Panelmk)).EndInit();
            this.Panelmk.ResumeLayout(false);
            this.Panelmk.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtxacnhan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmatkhau.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenhienthi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtendangnhap.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.TextEdit txtcmnd;
        private DevExpress.XtraEditors.TextEdit txtxacnhan;
        private DevExpress.XtraEditors.TextEdit txtmatkhau;
        private DevExpress.XtraEditors.TextEdit txttenhienthi;
        private DevExpress.XtraEditors.TextEdit txtendangnhap;
        private System.Windows.Forms.ComboBox comboNV;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.PanelControl Panelmk;
        private DevExpress.XtraEditors.SimpleButton btnKiemtra;
        private DevExpress.XtraEditors.SimpleButton btnXacNhan;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
    }
}