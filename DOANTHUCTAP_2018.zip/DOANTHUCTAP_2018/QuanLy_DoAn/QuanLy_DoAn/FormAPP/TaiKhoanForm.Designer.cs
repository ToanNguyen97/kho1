﻿namespace QuanLy_DoAn.FormAPP
{
    partial class TaiKhoanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.GridTK = new System.Windows.Forms.DataGridView();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lookNV = new System.Windows.Forms.ComboBox();
            this.txtcmnd = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.txtxacnhan = new DevExpress.XtraEditors.TextEdit();
            this.txtpass = new DevExpress.XtraEditors.TextEdit();
            this.txttenhienthi = new DevExpress.XtraEditors.TextEdit();
            this.txtenlogin = new DevExpress.XtraEditors.TextEdit();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridTK)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtxacnhan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpass.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenhienthi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenlogin.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.GridTK);
            this.panelControl1.Location = new System.Drawing.Point(0, 2);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(683, 301);
            this.panelControl1.TabIndex = 0;
            // 
            // GridTK
            // 
            this.GridTK.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridTK.Location = new System.Drawing.Point(2, 2);
            this.GridTK.Name = "GridTK";
            this.GridTK.RowTemplate.Height = 24;
            this.GridTK.Size = new System.Drawing.Size(676, 296);
            this.GridTK.TabIndex = 0;
            this.GridTK.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridTK_CellClick);
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(750, 28);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(117, 38);
            this.simpleButton1.TabIndex = 1;
            this.simpleButton1.Text = "Thêm";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Location = new System.Drawing.Point(750, 102);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(117, 38);
            this.simpleButton2.TabIndex = 2;
            this.simpleButton2.Text = "Sửa";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // simpleButton3
            // 
            this.simpleButton3.Location = new System.Drawing.Point(750, 182);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(117, 38);
            this.simpleButton3.TabIndex = 3;
            this.simpleButton3.Text = "Xóa";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // simpleButton4
            // 
            this.simpleButton4.Location = new System.Drawing.Point(750, 262);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(117, 38);
            this.simpleButton4.TabIndex = 4;
            this.simpleButton4.Text = "Cancel";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lookNV);
            this.panel1.Controls.Add(this.txtcmnd);
            this.panel1.Controls.Add(this.labelControl6);
            this.panel1.Controls.Add(this.txtxacnhan);
            this.panel1.Controls.Add(this.txtpass);
            this.panel1.Controls.Add(this.txttenhienthi);
            this.panel1.Controls.Add(this.txtenlogin);
            this.panel1.Controls.Add(this.labelControl5);
            this.panel1.Controls.Add(this.labelControl4);
            this.panel1.Controls.Add(this.labelControl3);
            this.panel1.Controls.Add(this.labelControl2);
            this.panel1.Controls.Add(this.labelControl1);
            this.panel1.Location = new System.Drawing.Point(2, 310);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(916, 183);
            this.panel1.TabIndex = 5;
            // 
            // lookNV
            // 
            this.lookNV.FormattingEnabled = true;
            this.lookNV.Location = new System.Drawing.Point(733, 106);
            this.lookNV.Name = "lookNV";
            this.lookNV.Size = new System.Drawing.Size(158, 24);
            this.lookNV.TabIndex = 19;
            this.lookNV.SelectedIndexChanged += new System.EventHandler(this.lookNV_SelectedIndexChanged);
            // 
            // txtcmnd
            // 
            this.txtcmnd.Location = new System.Drawing.Point(433, 113);
            this.txtcmnd.Name = "txtcmnd";
            this.txtcmnd.Size = new System.Drawing.Size(158, 22);
            this.txtcmnd.TabIndex = 17;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(326, 116);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(67, 17);
            this.labelControl6.TabIndex = 16;
            this.labelControl6.Text = "Số CMND :";
            // 
            // txtxacnhan
            // 
            this.txtxacnhan.Location = new System.Drawing.Point(733, 27);
            this.txtxacnhan.Name = "txtxacnhan";
            this.txtxacnhan.Size = new System.Drawing.Size(158, 22);
            this.txtxacnhan.TabIndex = 14;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(433, 24);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(158, 22);
            this.txtpass.TabIndex = 13;
            // 
            // txttenhienthi
            // 
            this.txttenhienthi.Location = new System.Drawing.Point(127, 111);
            this.txttenhienthi.Name = "txttenhienthi";
            this.txttenhienthi.Size = new System.Drawing.Size(158, 22);
            this.txttenhienthi.TabIndex = 12;
            // 
            // txtenlogin
            // 
            this.txtenlogin.Location = new System.Drawing.Point(127, 30);
            this.txtenlogin.Name = "txtenlogin";
            this.txtenlogin.Size = new System.Drawing.Size(158, 22);
            this.txtenlogin.TabIndex = 11;
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(628, 30);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(67, 17);
            this.labelControl5.TabIndex = 10;
            this.labelControl5.Text = "Xác Nhận :";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(628, 117);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(67, 16);
            this.labelControl4.TabIndex = 9;
            this.labelControl4.Text = "Nhân Viên :";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(327, 30);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(66, 17);
            this.labelControl3.TabIndex = 8;
            this.labelControl3.Text = "Mật Khẩu :";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(26, 113);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(84, 17);
            this.labelControl2.TabIndex = 7;
            this.labelControl2.Text = "Tên Hiển Thị :";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(26, 30);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(105, 17);
            this.labelControl1.TabIndex = 6;
            this.labelControl1.Text = "Tên Đăng Nhập :";
            // 
            // TaiKhoanForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 495);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.simpleButton4);
            this.Controls.Add(this.simpleButton3);
            this.Controls.Add(this.simpleButton2);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.panelControl1);
            this.Name = "TaiKhoanForm";
            this.Text = "Thông Tin Tài Khoản";
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridTK)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtxacnhan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtpass.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenhienthi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtenlogin.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private System.Windows.Forms.DataGridView GridTK;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.TextEdit txtxacnhan;
        private DevExpress.XtraEditors.TextEdit txtpass;
        private DevExpress.XtraEditors.TextEdit txttenhienthi;
        private DevExpress.XtraEditors.TextEdit txtenlogin;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txtcmnd;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private System.Windows.Forms.ComboBox lookNV;
    }
}