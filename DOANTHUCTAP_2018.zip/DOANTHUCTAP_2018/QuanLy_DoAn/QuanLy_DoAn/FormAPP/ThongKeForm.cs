﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class ThongKeForm : DevExpress.XtraEditors.XtraForm
    {
        public ThongKeForm()
        {
            InitializeComponent();
            GridHopDong.DataSource = HopDongThueDAO.Instance.LoadHD();
        }

        private void btnthongke_Click(object sender, EventArgs e)
        {
            try
            {
                GridHopDong.DataSource = HopDongThueDAO.Instance.HopDongThongKe(Convert.ToInt32(txtthang.Text));
            }
            catch(Exception ex)
            {

            }
        }
    }
}