﻿namespace QuanLy_DoAn.FormAPP
{
    partial class ThongKeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnthongke = new DevExpress.XtraEditors.SimpleButton();
            this.txtthang = new DevExpress.XtraEditors.TextEdit();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.GridHopDong = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtthang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridHopDong)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnthongke);
            this.panel1.Controls.Add(this.txtthang);
            this.panel1.Controls.Add(this.labelControl1);
            this.panel1.Controls.Add(this.GridHopDong);
            this.panel1.Location = new System.Drawing.Point(-2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1058, 547);
            this.panel1.TabIndex = 0;
            // 
            // btnthongke
            // 
            this.btnthongke.Location = new System.Drawing.Point(364, 11);
            this.btnthongke.Name = "btnthongke";
            this.btnthongke.Size = new System.Drawing.Size(148, 49);
            this.btnthongke.TabIndex = 3;
            this.btnthongke.Text = "Thống Kê";
            this.btnthongke.Click += new System.EventHandler(this.btnthongke_Click);
            // 
            // txtthang
            // 
            this.txtthang.Location = new System.Drawing.Point(163, 25);
            this.txtthang.Name = "txtthang";
            this.txtthang.Size = new System.Drawing.Size(154, 22);
            this.txtthang.TabIndex = 2;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(4, 27);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(141, 17);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Vui Lòng Nhập Tháng :";
            // 
            // GridHopDong
            // 
            this.GridHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridHopDong.Location = new System.Drawing.Point(0, 178);
            this.GridHopDong.Name = "GridHopDong";
            this.GridHopDong.RowTemplate.Height = 24;
            this.GridHopDong.Size = new System.Drawing.Size(1058, 369);
            this.GridHopDong.TabIndex = 0;
            // 
            // ThongKeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1055, 553);
            this.Controls.Add(this.panel1);
            this.Name = "ThongKeForm";
            this.Text = "Thống Kê Hợp Đồng";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtthang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridHopDong)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private DevExpress.XtraEditors.SimpleButton btnthongke;
        private DevExpress.XtraEditors.TextEdit txtthang;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.DataGridView GridHopDong;

    }
}