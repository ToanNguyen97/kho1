﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class HopDongThuePhong : DevExpress.XtraEditors.XtraForm
    {
        public HopDongThuePhong()
        {
            InitializeComponent();
            Load();
            Form1 frm = new Form1();
            datengay.Text = System.DateTime.Now.ToShortDateString();
        }
        
        private void Load()
        {
            GridHD.DataSource = HopDongThueDAO.Instance.LoadHD();
            combomaLKhach.DataSource = KhachThueDAO.Instance.LoaiKhachThue_DS();
            combomaLKhach.DisplayMember = "TenLoaiKhach";
            combomaLKhach.ValueMember = "MaLoaiKhach";
            comboNV.DataSource = NhanVienDAO.Instance.LoadNV();
            comboNV.DisplayMember = "HoTenNhanVien";
            comboNV.ValueMember = "MaNhanVien";
            txtmaHD.Text = HopDongThueDAO.Instance.getIDHopDonh_Auto();
        }

        private void txtmakhach_EditValueChanged(object sender, EventArgs e)
        {


        }

        private void comboKH_SelectedIndexChanged(object sender, EventArgs e)
        {
        

        }

        private void button1_Click(object sender, EventArgs e) // Thêm Khách Hàng
        {
            try
            {
                int gt;
                if (RNam.Checked)
                    gt = 1;
                else
                    gt = 0;
                KhachThueDTO khachdto = new KhachThueDTO(txtmakhachThue.Text, txthokhach.Text, txttenkhach.Text, txtcmnd.Text, txtnamsinh.Text, gt, txtsdt.Text, txttennguoithan.Text, txtdiachi.Text, combomaLKhach.SelectedValue.ToString());
                KhachThueDAO.Instance.KhachThue_Them(khachdto);               
                XtraMessageBox.Show("Thành Công!!!");
            }
            catch (Exception ex)
            { }
        }

        private void simpleButton2_Click(object sender, EventArgs e) //Lập Hợp Đồng
        {
            try {
                HopDongThueDTO hd = new HopDongThueDTO(txtmaHD.Text, txtmakhachThue.Text, txtmaphong.Text, datengay.Text,dateKT.Text, comboNV.SelectedValue.ToString());
                HopDongThueDAO.Instance.HopDongThem(hd);
                GridHD.DataSource = HopDongThueDAO.Instance.LoadHD();
                XtraMessageBox.Show("Thành Công!! Hợp tác vui vẻ !!");
                combotinhtrang.Text = "Đã Thuê";
                SoDoTroForm frm = new SoDoTroForm();
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text, txttenphong.Text, LoaiPhongDAO.Instance.getIDByTen(txtoaiphong.Text), KhuPhongDAO.Instance.getIDByTen(combokhuphong.Text), "TR02", txtghichu.Text,txtmanoiquy.Text);
                PhongDAO.Instance.Phong_Sua(phongdto);    
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }
        }

        private void GridHD_CellClick(object sender, DataGridViewCellEventArgs e) // hiển thị lên txtbox
        {
            txtmaHD.Text = GridHD.CurrentRow.Cells[0].Value.ToString();
            txtmaphong.Text = GridHD.CurrentRow.Cells[2].Value.ToString();
            txtmakhachThue.Text = GridHD.CurrentRow.Cells[1].Value.ToString();
            comboNV.SelectedValue = GridHD.CurrentRow.Cells[4].Value.ToString();
            datengay.Text =  GridHD.CurrentRow.Cells[3].Value.ToString();

        }

        private void simpleButton4_Click(object sender, EventArgs e) // Xem Chi Tiết
        {
            try {
                string gt="";
                KhachThueDTO khachdto = new KhachThueDTO(txtmakhachThue.Text,txthokhach.Text,txttenkhach.Text,txtcmnd.Text,txtnamsinh.Text,gt,txtsdt.Text,txttennguoithan.Text,txtdiachi.Text,combomaLKhach.SelectedValue.ToString());
                KhachThueDAO.Instance.GetInfoByMa(khachdto, txtmakhachThue.Text);
                txtmakhachThue.Text = khachdto.MaKhachThue;
                txthokhach.Text = khachdto.HoKhachThue;
                txttenkhach.Text = khachdto.TenKhachThue;
                txtcmnd.Text = khachdto.SoCMND;
                txtnamsinh.Text = khachdto.NamSinh;
                if (khachdto.Gt == "Nam")
                    RNam.Checked =true;
                else
                    Rnu.Checked = true;
                txtsdt.Text = khachdto.DienThoai;
                txttennguoithan.Text = khachdto.HoTenNguoiThan;
                txtdiachi.Text = khachdto.DiaChi;
                combomaLKhach.SelectedValue = khachdto.MaLoaiKhach;
                // Load chi tiết phòng bằng mã phòng
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text,txttenphong.Text,txtoaiphong.Text,combokhuphong.Text,combotinhtrang.Text,txtghichu.Text,txtmanoiquy.Text);
                PhongDAO.Instance.LoadInfoByMaPhong(phongdto, txtmaphong.Text);
                txtmaphong.Text = phongdto.MaPhong;
                txttenphong.Text = phongdto.TenPhong;
                txtoaiphong.Text = LoaiPhongDAO.Instance.geTenDByID(phongdto.MaLoaiPhong);
                combokhuphong.Text = KhuPhongDAO.Instance.getTenByID(phongdto.MaKhuPhong);
                combotinhtrang.Text = TinhTrangPhongDAO.Instance.getTenByID(phongdto.MaTinhTrang);
                txtghichu.Text = phongdto.GhiChu;
                txtmanoiquy.Text = phongdto.MaNoiQuy;
                comboGiaPhong.Text = LoaiPhongDAO.Instance.getGiaByID(phongdto.MaLoaiPhong);
            }catch(Exception ex)
            {

            }
            
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            try
            {
                HopDongThueDTO hd = new HopDongThueDTO(txtmaHD.Text, txtmakhachThue.Text, txtmaphong.Text, datengay.Text,dateKT.Text,comboNV.SelectedValue.ToString());
                HopDongThueDAO.Instance.HopDongSua(hd);
                GridHD.DataSource = HopDongThueDAO.Instance.LoadHD();
                XtraMessageBox.Show("Thành Công!! Hợp tác vui vẻ !!");
                combotinhtrang.Text = "Đã Thuê";
                SoDoTroForm frm = new SoDoTroForm();
                PhongDTO phongdto = new PhongDTO(txtmaphong.Text, txttenphong.Text, LoaiPhongDAO.Instance.getIDByTen(txtoaiphong.Text), KhuPhongDAO.Instance.getIDByTen(combokhuphong.Text), "TR02", txtghichu.Text, txtmanoiquy.Text);
                PhongDAO.Instance.Phong_Sua(phongdto);
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Thất Bại");
            }
        } // Sửa Hợp Đồng

        private void simpleButton3_Click(object sender, EventArgs e)
        {

            InHopDongForm frm = new InHopDongForm();
            frm.txtmahd.Text = txtmaHD.Text;
            frm.ShowDialog();
        } // In Hợp Đồng
    }
}