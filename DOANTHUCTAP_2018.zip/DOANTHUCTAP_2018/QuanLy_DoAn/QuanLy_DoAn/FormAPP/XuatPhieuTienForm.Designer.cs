﻿namespace QuanLy_DoAn.FormAPP
{
    partial class XuatPhieuTienForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.PhieuThuTienRPBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.XuatPhieuTien = new QuanLy_DoAn.FormAPP.XuatPhieuTien();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.PhieuThuTienRPTableAdapter = new QuanLy_DoAn.FormAPP.XuatPhieuTienTableAdapters.PhieuThuTienRPTableAdapter();
            this.lbmap = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.PhieuThuTienRPBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XuatPhieuTien)).BeginInit();
            this.SuspendLayout();
            // 
            // PhieuThuTienRPBindingSource
            // 
            this.PhieuThuTienRPBindingSource.DataMember = "PhieuThuTienRP";
            this.PhieuThuTienRPBindingSource.DataSource = this.XuatPhieuTien;
            // 
            // XuatPhieuTien
            // 
            this.XuatPhieuTien.DataSetName = "XuatPhieuTien";
            this.XuatPhieuTien.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "InPhieuThuTien";
            reportDataSource1.Value = this.PhieuThuTienRPBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "QuanLy_DoAn.FormAPP.RPPhieuTienIn.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(898, 540);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load);
            // 
            // PhieuThuTienRPTableAdapter
            // 
            this.PhieuThuTienRPTableAdapter.ClearBeforeFill = true;
            // 
            // lbmap
            // 
            this.lbmap.Location = new System.Drawing.Point(0, 11);
            this.lbmap.Name = "lbmap";
            this.lbmap.Size = new System.Drawing.Size(0, 16);
            this.lbmap.TabIndex = 1;
            // 
            // XuatPhieuTienForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 540);
            this.Controls.Add(this.lbmap);
            this.Controls.Add(this.reportViewer1);
            this.Name = "XuatPhieuTienForm";
            this.Text = "Xuất Phiếu Tiền Thu";
            this.Load += new System.EventHandler(this.XuatPhieuTienForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PhieuThuTienRPBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XuatPhieuTien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource PhieuThuTienRPBindingSource;
        private XuatPhieuTien XuatPhieuTien;
        private XuatPhieuTienTableAdapters.PhieuThuTienRPTableAdapter PhieuThuTienRPTableAdapter;
        public DevExpress.XtraEditors.LabelControl lbmap;
    }
}