﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace QuanLy_DoAn.FormAPP
{
    public partial class XuatPhieuTienForm : DevExpress.XtraEditors.XtraForm
    {
        public XuatPhieuTienForm()
        {
            InitializeComponent();
            lbmap.Visible = false;
        }

        private void XuatPhieuTienForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'XuatPhieuTien.PhieuThuTienRP' table. You can move, or remove it, as needed.
            this.PhieuThuTienRPTableAdapter.Fill(this.XuatPhieuTien.PhieuThuTienRP,lbmap.Text);

            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}