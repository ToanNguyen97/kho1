﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class TinhTrangPhieuDAO
    {
        private static TinhTrangPhieuDAO instance;

        public static TinhTrangPhieuDAO Instance
        {
            get { if (instance == null) instance = new TinhTrangPhieuDAO(); return TinhTrangPhieuDAO.instance; }
          private  set { TinhTrangPhieuDAO.instance = value; }
        }
        private TinhTrangPhieuDAO() { }
        public DataTable LoadDS()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM TinhTrangPhieuThu");
        }
        public List<TinhTrangPhieuThuDTO> LoadList()
        {
            List<TinhTrangPhieuThuDTO> tablelist = new List<TinhTrangPhieuThuDTO>();
            DataTable data = LoadDS();
            foreach(DataRow item in data.Rows)
            {
                TinhTrangPhieuThuDTO dtopt = new TinhTrangPhieuThuDTO(item);
                tablelist.Add(dtopt);
            }
            return tablelist;
        }
      
    }
}
