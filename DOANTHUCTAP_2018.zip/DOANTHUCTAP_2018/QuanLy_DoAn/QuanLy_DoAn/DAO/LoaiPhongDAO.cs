﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
    public class LoaiPhongDAO
    {
        private static LoaiPhongDAO instance;

        public static LoaiPhongDAO Instance
        {
            get { if (instance == null) instance = new LoaiPhongDAO();
                return LoaiPhongDAO.instance; }
          private  set { LoaiPhongDAO.instance = value; }
        }
        private LoaiPhongDAO() { }

        public List<LoaiPhongDTO> LoadListDSTen()
        {
            List<LoaiPhongDTO> tablelist = new List<LoaiPhongDTO>();
            DataTable data = DataProvider.Instance.ExcuteQuery("SELECT * FROM LoaiPhong");
            foreach (DataRow item in data.Rows)
            {
                LoaiPhongDTO acc = new LoaiPhongDTO(item);
                tablelist.Add(acc);
            }
            return tablelist;

        }
        public String geTenDByID(String id)
        {
            List<LoaiPhongDTO> list = LoadListDSTen();
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].MaLoaiPhong.Equals(id))
                    return list[i].TenLoaiPhong;
            }
            return "";
        }
        public String getIDByTen(String ten)
        {
            List<LoaiPhongDTO> list = LoadListDSTen();
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].TenLoaiPhong.Equals(ten))
                    return list[i].MaLoaiPhong;
            }
            return "";
        }
        public string getGiaByID(string ma)
        {
            List<LoaiPhongDTO> list = LoadListDSTen();
            for(int i = 0; i<list.Count;i++)
            {
                if (list[i].MaLoaiPhong.Equals(ma))
                    return list[i].GiaLoaiPhong.ToString();
            }
            return "";
        }
        public DataTable LoadCBLoaiPhong()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM LoaiPhong");
        }
      
    }
}
