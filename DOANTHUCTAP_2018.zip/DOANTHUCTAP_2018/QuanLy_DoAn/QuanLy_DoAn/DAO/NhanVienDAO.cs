﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class NhanVienDAO
    {
        private static NhanVienDAO instance;

        public static NhanVienDAO Instance
        {
            get { if (instance == null) instance = new NhanVienDAO();
                return NhanVienDAO.instance; }
           private set { NhanVienDAO.instance = value; }
        }
        private NhanVienDAO() { }
       public DataTable LoadNV()
        {
          return DataProvider.Instance.ExcuteQuery("EXEC dbo.NhanVien_DS");
        }
    }
}
