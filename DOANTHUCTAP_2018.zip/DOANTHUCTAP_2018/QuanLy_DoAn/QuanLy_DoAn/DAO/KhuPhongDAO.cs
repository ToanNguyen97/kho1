﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class KhuPhongDAO
    {
        private static KhuPhongDAO instance;

        public static KhuPhongDAO Instance
        {
            get { if (instance == null) instance = new KhuPhongDAO();
                return KhuPhongDAO.instance; }
          private  set { KhuPhongDAO.instance = value; }
        }
        private KhuPhongDAO() { }
        public DataTable LoadKhuPhong()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM KhuPhong");
        }
       public List<KhuPhongDTO> LoadListKP()
        {
            List<KhuPhongDTO> tablelist = new List<KhuPhongDTO>();
            DataTable data = DataProvider.Instance.ExcuteQuery("SELECT * FROM KhuPhong");
           foreach(DataRow item in data.Rows)
           {
               KhuPhongDTO dto = new KhuPhongDTO(item);
               tablelist.Add(dto);

           }
           return tablelist;
        }
       public String getTenByID(string ma)
       {
           List<KhuPhongDTO> list = LoadListKP();
           for(int i = 0; i< list.Count;i++)
           {
               if(list[i].MaKhuPhong.Equals(ma))
                   return list[i].TenKhuPhong;
           }
           return "";
       }
       public String getIDByTen(string ten)
       {
           List<KhuPhongDTO> list = LoadListKP();
           for (int i = 0; i < list.Count; i++)
           {
               if (list[i].TenKhuPhong.Equals(ten))
                   return list[i].MaKhuPhong;
           }
           return "";
       }
    }
}
