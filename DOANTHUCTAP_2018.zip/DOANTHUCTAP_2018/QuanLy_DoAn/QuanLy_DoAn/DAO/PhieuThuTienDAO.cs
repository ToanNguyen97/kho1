﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class PhieuThuTienDAO
    {
        private static PhieuThuTienDAO instance;

        public static PhieuThuTienDAO Instance
        {
            get { if (instance == null) instance = new PhieuThuTienDAO();
                return PhieuThuTienDAO.instance; }
           private set { PhieuThuTienDAO.instance = value; }
        }
        private PhieuThuTienDAO() { }
        public DataTable LoadPhieuThu()
        {
            return DataProvider.Instance.ExcuteQuery("EXEC dbo.PhieuThuTien_DS");
        }
       public void PhieuThu_Them(PhieuThuDTO dtoPT)
       {
           string query = "PhieuThuTien_Them @MaPhieu , @MaPhong , @NgayLap , @MaTinhTrangPhieu , @GhiChu ";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { dtoPT.MaPhieu, dtoPT.MaPhong, dtoPT.NgayLap, dtoPT.MaTinhTrangPhieu, dtoPT.GhiChu });
       }
       public void PhieuThu_Sua(PhieuThuDTO dtoPT)
       {
           string query = "PhieuThuTien_Sua @MaPhieu , @MaPhong , @NgayLap , @MaTinhTrangPhieu , @GhiChu ";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { dtoPT.MaPhieu, dtoPT.MaPhong, dtoPT.NgayLap, dtoPT.MaTinhTrangPhieu, dtoPT.GhiChu });
       }

    }
}
