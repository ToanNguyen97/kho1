﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class DataProvider
    {
        private static DataProvider instance;

        public static DataProvider Instance
        {
            get { if (instance == null)instance = new DataProvider();
                    return DataProvider.instance; }
         private  set { DataProvider.instance = value; }
        }
        private DataProvider() { }
          public String CONSTR = @"Data Source=DESKTOP-Q161EUF;Initial Catalog=QUANLYPHONGTRO_57130724;Integrated Security=True";
          public DataTable ExcuteQuery(String query, object[] paramater = null )
       {
           DataTable data = new DataTable();
           using(SqlConnection connection = new SqlConnection(CONSTR)) // khi kết thúc khối lệnh bên trong thì sẽ giải phóng
           {
               connection.Open();
               SqlCommand command = new SqlCommand(query, connection);
               if(paramater!=null)
               {
                   string[] listPara = query.Split(' ');
                   int i = 0;
                   foreach(string item in listPara)
                   {
                      if(item.Contains('@'))
                      {
                          command.Parameters.AddWithValue(item, paramater[i]);
                          i++;
                      }
                   }
               }
               SqlDataAdapter adapter = new SqlDataAdapter(command);
               adapter.Fill(data);
               connection.Close();
           }
           return data;
       }
          public DataSet ExcuteQuerySet(String query, object[] paramater = null)
          {
              DataSet data = new DataSet();
              using (SqlConnection connection = new SqlConnection(CONSTR)) // khi kết thúc khối lệnh bên trong thì sẽ giải phóng
              {
                  connection.Open();
                  SqlCommand command = new SqlCommand(query, connection);
                  if (paramater != null)
                  {
                      string[] listPara = query.Split(' ');
                      int i = 0;
                      foreach (string item in listPara)
                      {
                          if (item.Contains('@'))
                          {
                              command.Parameters.AddWithValue(item, paramater[i]);
                              i++;
                          }
                      }
                  }
                  SqlDataAdapter adapter = new SqlDataAdapter(command);
                  adapter.Fill(data);
                  connection.Close();
              }
              return data;
          }
         public void ExcuteNonQuery(String query, object[] paramater = null)
       {
           
           using (SqlConnection connection = new SqlConnection(CONSTR)) // khi kết thúc khối lệnh bên trong thì sẽ giải phóng
           {
               connection.Open();
               SqlCommand command = new SqlCommand(query, connection);
           //    command.CommandType = CommandType.StoredProcedure;
               if (paramater != null)
               {
                   string[] listPara = query.Split(' ');
                   int i = 0;
                   foreach (string item in listPara)
                   {
                       if (item.Contains('@'))
                       {
                           command.Parameters.AddWithValue(item, paramater[i]);
                           i++;
                       }
                   }
               }
                command.ExecuteNonQuery();
               connection.Close();
           }

       }
         public object ExcuteScalarQuery(String query, object[] paramater = null)
       {
           object data = 0;
           using (SqlConnection connection = new SqlConnection(CONSTR)) // khi kết thúc khối lệnh bên trong thì sẽ giải phóng
           {
               connection.Open();
               SqlCommand command = new SqlCommand(query, connection);
               if (paramater != null)
               {
                   string[] listPara = query.Split(' ');
                   int i = 0;
                   foreach (string item in listPara)
                   {
                       if (item.Contains('@'))
                       {
                           command.Parameters.AddWithValue(item, paramater[i]);
                           i++;
                       }
                   }
               }
               data = command.ExecuteScalar();
               connection.Close();
           }
           return data;
       }
    }
}
