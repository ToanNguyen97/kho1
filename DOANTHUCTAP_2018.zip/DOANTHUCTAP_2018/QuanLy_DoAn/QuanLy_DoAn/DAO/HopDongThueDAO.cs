﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class HopDongThueDAO
    {
        private static HopDongThueDAO instance;

        public static HopDongThueDAO Instance
        {
            get { if (instance == null) instance = new HopDongThueDAO(); return HopDongThueDAO.instance; }
           private set { HopDongThueDAO.instance = value; }
        }
        private HopDongThueDAO() { }
        public DataTable LoadHD()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM HopDongThue");
        }
        public List<HopDongThueDTO> LoadListHD()
        {
            List<HopDongThueDTO> tablelist = new List<HopDongThueDTO>();
            DataTable data = LoadHD();
            foreach(DataRow item in data.Rows)
            {
                HopDongThueDTO dtohd = new HopDongThueDTO(item);
                tablelist.Add(dtohd);
            }
            return tablelist;

        }
        public string getIDHopDonh_Auto()
        {
            String ma = "";
            List<HopDongThueDTO> listHD = LoadListHD();
            ma = listHD[listHD.Count - 1].MaHopDong;
            string test = ma.Substring(0, 2);
            string so = ma.Substring(2);
            int sotiep = Convert.ToInt32(so) + 1;
            if (sotiep < 10)
            {
                string somoi = "0" + sotiep.ToString();
                ma = test + somoi;
            }
            else
            {
                string somoi = sotiep.ToString();
                ma = test + somoi;
            }

            return ma;
        }
       public string getTenKhachByMaPhong(string map)
        {
            List<HopDongThueDTO> list = LoadListHD();
           for(int i = 0; i< list.Count;i++)
           {
               if (list[i].MaPhong.Equals(map))
                   return list[i].MaKhachThue;
           }
           return "";
        }
        public void HopDongThem(HopDongThueDTO dtoHD)
        {
            string query = "HopDong_Them @MaHopDong , @MaKhachThue , @MaPhong , @NgayLap, @NgayKT , @MaNhanVien";
            DataProvider.Instance.ExcuteNonQuery(query, new object[] { dtoHD.MaHopDong, dtoHD.MaKhachThue, dtoHD.MaPhong, dtoHD.NgayLap,dtoHD.Ngaykt, dtoHD.MaNhanVien });
        }
         public void HopDongSua(HopDongThueDTO dtoHD)
        {
            string query = "HopDong_Sua @MaHopDong , @MaKhachThue , @MaPhong , @NgayLap , @NgayKT , @MaNhanVien";
            DataProvider.Instance.ExcuteNonQuery(query, new object[] { dtoHD.MaHopDong, dtoHD.MaKhachThue, dtoHD.MaPhong, dtoHD.NgayLap, dtoHD.Ngaykt, dtoHD.MaNhanVien });
        }
         public DataTable HopDongThongKe(int thang)
         {
             string query = "ThongKeHopDong @Thang ";
            return DataProvider.Instance.ExcuteQuery(query, new object[] { thang});
         }
    }
}
