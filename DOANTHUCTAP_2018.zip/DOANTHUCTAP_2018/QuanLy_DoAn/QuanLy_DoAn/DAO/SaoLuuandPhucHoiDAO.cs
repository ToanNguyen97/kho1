﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class SaoLuuandPhucHoiDAO
    {
        private static SaoLuuandPhucHoiDAO instance;

        public static SaoLuuandPhucHoiDAO Instance
        {
            get { if (instance == null) instance = new SaoLuuandPhucHoiDAO();
                return SaoLuuandPhucHoiDAO.instance; }
           private set { SaoLuuandPhucHoiDAO.instance = value; }
        }
        private SaoLuuandPhucHoiDAO() { }
       public void SaoLuu(string path)
        {
            DataProvider.Instance.ExcuteNonQuery("SAOLUU @Path ",new object[]{path});
        }
       public void PhucHoi(string path)
       {
           SqlConnection Conn = new SqlConnection(DataProvider.Instance.CONSTR);
           Conn.Open();
           string query = "USE MASTER ALTER DATABASE QUANLYPHONGTRO_57130724 SET SINGLE_USER WITH ROLLBACK IMMEDIATE RESTORE DATABASE QUANLYPHONGTRO_57130724 "
                          + "FROM DISK = '" + path + "' "
                          + "WITH REPLACE ALTER DATABASE QUANLYPHONGTRO_57130724 SET MULTI_USER";
           SqlCommand cmd = new SqlCommand(query, Conn);
           cmd.ExecuteNonQuery();
           Conn.Close();
       }
    }
}
