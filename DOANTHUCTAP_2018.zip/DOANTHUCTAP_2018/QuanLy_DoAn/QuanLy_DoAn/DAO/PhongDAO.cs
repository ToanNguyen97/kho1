﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class PhongDAO
    {
        private static PhongDAO instance;

        public static PhongDAO Instance
        {
            get { if (instance == null) instance = new PhongDAO();
                return PhongDAO.instance; }
             private  set { PhongDAO.instance = value; }
        }
        private PhongDAO() { }
        public static int PhongWith = 95;
        public static int PhongHeight = 95;
        public static int timestep = 100; // thơi gian tăng một lần tick
        public static int timeend = 10000; // thời gian để ngừng đếm ngược
        public static int timeinterval = 100;
       public DataTable LoadPhong()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM Phong");
        }
      
       public void Phong_Them(PhongDTO phongdto)
       {
           string query = "Phong_Them @MaPhong , @TenPhong , @MaLoaiPhong , @MaKhuPhong , @MaTinhTrang , @GhiChu , @MaNoiQuy ";
          DataProvider.Instance.ExcuteNonQuery(query,new object[]{phongdto.MaPhong,phongdto.TenPhong,phongdto.MaLoaiPhong,phongdto.MaKhuPhong,phongdto.MaTinhTrang,phongdto.GhiChu,phongdto.MaNoiQuy});
       }
       
       public void Phong_Sua(PhongDTO phongdto)
       {
           string query = "Phong_Sua @MaPhong , @TenPhong , @MaLoaiPhong , @MaKhuPhong , @MaTinhTrang , @GhiChu , @MaNoiQuy ";
          DataProvider.Instance.ExcuteNonQuery(query,new object[]{phongdto.MaPhong,phongdto.TenPhong,phongdto.MaLoaiPhong,phongdto.MaKhuPhong,phongdto.MaTinhTrang,phongdto.GhiChu,phongdto.MaNoiQuy});
       }
       public void Phong_Xoa(PhongDTO phongdto)
       {
           string query = "Phong_Xoa @MaPhong ";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { phongdto.MaPhong  });
       }
       public List<PhongDTO> LoadListPhong()
       {
           return DataConvert.DataTabletoList<PhongDTO>(LoadPhong());
           //List<PhongDTO> tablelist = new List<PhongDTO>();
           //DataTable data = LoadPhong();
           //foreach (DataRow item in data.Rows)
           //{
           //    PhongDTO acc = new PhongDTO(item);
           //    tablelist.Add(acc);
           //}
           //return tablelist;
       }
       public void LoadInfoByMaPhong(PhongDTO pdto , string maP)
       {
           List<PhongDTO> listp = LoadListPhong();
           for(int i=0;i< listp.Count;i++)
           {
               if(listp[i].MaPhong.Equals(maP))
               {
                   pdto.MaPhong = listp[i].MaPhong;
                   pdto.TenPhong = listp[i].TenPhong;
                   pdto.MaLoaiPhong = listp[i].MaLoaiPhong;
                   pdto.MaKhuPhong = listp[i].MaKhuPhong;
                   pdto.MaTinhTrang = listp[i].MaTinhTrang;
                   pdto.MaNoiQuy = listp[i].MaNoiQuy;
                   pdto.GhiChu = listp[i].GhiChu;
                   break;
               }
           }
       }
       public string getIDPhong_Auto(string makhu)
       {
           String ma = "";
           List<PhongDTO> listphong = LoadListbyMaPhong(makhu);
           ma = listphong[listphong.Count - 1].MaPhong;
           string test = ma.Substring(0, 2);
           string so = ma.Substring(2);
           int sotiep = Convert.ToInt32(so) + 1;
           if (sotiep < 10)
           {
               string somoi = "0" + sotiep.ToString();
               ma = test + somoi;
           }
           else
           {
               string somoi = sotiep.ToString();
               ma = test + somoi;
           }

           return ma;
       }
       public List<PhongDTO> LoadListbyMaPhong(String makhuphong)
        {
            List<PhongDTO> tablelist = new List<PhongDTO>();
            DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaKhuPhong @MaKhuPhong ",new object[]{makhuphong});
            foreach (DataRow item in data.Rows)
            {
                PhongDTO acc = new PhongDTO(item);
                tablelist.Add(acc);
            }
            return tablelist;
        } // tìm phòng theo mã phòng
        public string LoadLoaiPhongByMa(string map)
       {
           List<PhongDTO> listp = LoadListPhong();
            for(int i = 0 ;i < listp.Count;i++)
            {
                if (listp[i].MaPhong.Equals(map))
                    return listp[i].MaLoaiPhong;
            }
            return "";
       }
       public List<PhongDTO> LoadListbyGiaPhong(String giaphong)
       {
           List<PhongDTO> tablelist = new List<PhongDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaLoaiPhong @MaLoaiPhong ", new object[] { giaphong });
           foreach (DataRow item in data.Rows)
           {
               PhongDTO acc = new PhongDTO(item);
               tablelist.Add(acc);
           }
           return tablelist;
       } // tìm phòng theo gia phong
        public List<PhongDTO> LoadListbyMaLoaiPhong(String maloaiphong)
       {
           List<PhongDTO> tablelist = new List<PhongDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaLoaiPhong @MaLoaiPhong ", new object[] { maloaiphong});
           foreach (DataRow item in data.Rows)
           {
               PhongDTO acc = new PhongDTO(item);
               tablelist.Add(acc);
           }
           return tablelist;
       } //tìm phòng theo mã loại
       public List<PhongDTO> LoadListbyMaTinhTrang(String matinhtrang)
       {
           List<PhongDTO> tablelist = new List<PhongDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaTinhTrangPhong @MaTinhTrang ", new object[] {matinhtrang});
           foreach (DataRow item in data.Rows)
           {
               PhongDTO acc = new PhongDTO(item);
               tablelist.Add(acc);
           }
           return tablelist;
       } // tìm phòng theo tình trạng
    }
}
