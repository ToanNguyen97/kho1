﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
    public class NoiQuyDAO
    {
        private static NoiQuyDAO instance;

        public static NoiQuyDAO Instance
        {
            get { if (instance == null) instance = new NoiQuyDAO();
                return NoiQuyDAO.instance; }
          private  set { NoiQuyDAO.instance = value; }
        }
        private NoiQuyDAO() { }
        public DataTable LoadNoiQuy()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM NoiQuy");
        }
        public List<NoiQuyDTO> ListNoiQuy()
        {
            List<NoiQuyDTO> tablelist = new List<NoiQuyDTO>();
            DataTable data = DataProvider.Instance.ExcuteQuery("SELECT * FROM NoiQuy");
            foreach(DataRow item in data.Rows)
            {
                NoiQuyDTO noiquydto = new NoiQuyDTO(item);
                tablelist.Add(noiquydto);
            }
            return tablelist;
        }
        public String getNoiDungByID(string ma)
        {
            List<NoiQuyDTO> listnq = ListNoiQuy();
            for(int i = 0 ; i< listnq.Count; i++)
            {
                if (listnq[i].MaNoiQuy.Equals(ma))
                    return listnq[i].NoiDung;
            }
            return "";
        }
    }
}
