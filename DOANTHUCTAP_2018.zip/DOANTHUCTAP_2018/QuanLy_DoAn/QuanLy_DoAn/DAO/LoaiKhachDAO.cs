﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class LoaiKhachDAO
    {
        private static LoaiKhachDAO instance;

        public static LoaiKhachDAO Instance
        {
            get { if (instance == null) instance = new LoaiKhachDAO(); return LoaiKhachDAO.instance; }
           private set { LoaiKhachDAO.instance = value; }
        }
        private LoaiKhachDAO() { }
        public DataTable LoaiKhachThue_DS()
        {
            return DataProvider.Instance.ExcuteQuery("LoaiKhach_DS");

        }
       public List<LoaiKhachDTO> LoadList()
        {
            List<LoaiKhachDTO> tablelist =new List<LoaiKhachDTO>();
            DataTable data = LoaiKhachThue_DS();
           foreach(DataRow item in data.Rows)
           {
               LoaiKhachDTO dtolk = new LoaiKhachDTO(item);
               tablelist.Add(dtolk);
           }
           return tablelist;
        }
       public string getTenByID(string ma)
       {
           List<LoaiKhachDTO> tablelist = LoadList();
           for(int i = 0;i< tablelist.Count;i++)
           {
               if(tablelist[i].MaLoaiKhach.Equals(ma));
                    return tablelist[i].TenLoaiKhach;
           }
           return "";
       }
    }
}
