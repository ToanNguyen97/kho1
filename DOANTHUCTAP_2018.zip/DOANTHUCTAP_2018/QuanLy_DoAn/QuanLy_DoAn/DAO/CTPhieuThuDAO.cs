﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class CTPhieuThuDAO
    {
        private static CTPhieuThuDAO instance;

        public static CTPhieuThuDAO Instance
        {
            get { if (instance == null) instance = new CTPhieuThuDAO();
                return CTPhieuThuDAO.instance; }
           private set { CTPhieuThuDAO.instance = value; }
        }
        private CTPhieuThuDAO() { }
        public DataTable LoadCT_DS()
        {
            return DataProvider.Instance.ExcuteQuery("EXEC dbo.CTPhieuThu_DS");

        }
         public DataTable LoadCT_DSBYID(string map)
        {
            return DataProvider.Instance.ExcuteQuery("CTPhieu_DSBYMAPhieuKT @MaPhieu ",new object[]{map});
            
        }
       public void CTPhieuThu_Them(CTPhieuThuDTO ctdto)
        {
            string query = " CTPhieuThu_Them @STT , @MaPhieu , @MaKhoanThu , @ChiSoCu , @ChiSoMoi , @TienPhatSinh ";
            DataProvider.Instance.ExcuteNonQuery(query, new object[] { ctdto.STT, ctdto.MaPhieu, ctdto.MaKhoanThu, ctdto.ChiSoCu, ctdto.ChiSoMoi, ctdto.TienPhatSinh });
        }
    }
}
