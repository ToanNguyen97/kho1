﻿using System;
using System.Reflection;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace QuanLy_DoAn.DAO
{
     public class DataConvert
    {
        public static List<T> DataTabletoList<T>(DataTable table) where T : new ()
        {
            List<T> list = new List<T>();
            // Lấy tất cả tên cột trong datatabe (CSDL)
            string[] columnNames = (from dc in table.Columns.Cast<DataColumn>() select dc.ColumnName).ToArray();
            // Khai báo đối tượng T
            T t;
            foreach (DataRow dr in table.Rows)
            {
                t = new T();
                // Duyệt qua tất cả columns name
                foreach (string columnName in columnNames)
                {
                    // Khai báo thuộc tính
                    PropertyInfo p = t.GetType().GetProperty(columnName);
                    p.SetValue(t, dr[columnName]);
                }
                list.Add(t);
            }
            return list;
        }
    }
}
