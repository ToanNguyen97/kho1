﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class TinhTrangPhongDTO
    {
        string maTinhTrang, tenTinhTrang;
       public TinhTrangPhongDTO(string ma, string ten)
        {
            this.MaTinhTrang = ma;
            this.TenTinhTrang = ten;
        }
       public TinhTrangPhongDTO(DataRow row)
       {
           this.MaTinhTrang = row["MaTinhTrang"].ToString();
           this.TenTinhTrang = row["TenTinhTrang"].ToString();
       }
        public string MaTinhTrang
        {
            get { return maTinhTrang; }
            set { maTinhTrang = value; }
        }

        public string TenTinhTrang
        {
            get { return tenTinhTrang; }
            set { tenTinhTrang = value; }
        }
    }
}
