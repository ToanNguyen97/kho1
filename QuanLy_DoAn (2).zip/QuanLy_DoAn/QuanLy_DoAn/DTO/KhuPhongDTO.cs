﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class KhuPhongDTO
    {
        string maKhuPhong, tenKhuPhong;
       public KhuPhongDTO(string ma, string ten)
        {
            this.MaKhuPhong = ma;
            this.TenKhuPhong = ten;
        }
       public KhuPhongDTO(DataRow row)
       {
           this.MaKhuPhong = row["MaKhuPhong"].ToString();
           this.TenKhuPhong = row["TenKhuPhong"].ToString();
       }
        public string MaKhuPhong
        {
            get { return maKhuPhong; }
            set { maKhuPhong = value; }
        }

        public string TenKhuPhong
        {
            get { return tenKhuPhong; }
            set { tenKhuPhong = value; }
        }
    }
}
