﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class KhachThueDTO
    {
        String maKhachThue, hoKhachThue, tenKhachThue, soCMND, namSinh, dienThoai, hoTenNguoiThan, diaChi, maLoaiKhach;
        int gioiTinh;
        String gt;

        public String Gt
        {
            get { return gt; }
            set { gt = value; }
        }

        public int GioiTinh
        {
            get { return gioiTinh; }
            set { gioiTinh = value; }
        }

       
       public KhachThueDTO(String makhachthue)
        {
            this.MaKhachThue = makhachthue;
        }
       public KhachThueDTO(DataRow row)
       {
           this.MaKhachThue = row["MaKhachThue"].ToString();
           this.HoKhachThue = row["HoKhachThue"].ToString();
           this.TenKhachThue = row["TenKhachThue"].ToString();
           this.SoCMND = row["SoCMND"].ToString();
           this.NamSinh = row["NamSinh"].ToString();
           this.Gt = row["GioiTinh"].ToString();
           this.DienThoai = row["DienThoai"].ToString();
           this.HoTenNguoiThan = row["HoTenNguoiThan"].ToString();
           this.DiaChi = row["DiaChi"].ToString();
           this.MaLoaiKhach = row["MaLoaiKhach"].ToString();
       }
       public KhachThueDTO(String makhachthue, String hokhachthue, string tenkhachthue , string socmnd,string namsinh, int gt, string sdt , string tennguoithan , string diachi , string maloaikhach)
        {
            this.MaKhachThue = makhachthue;
            this.HoKhachThue = hokhachthue;
            this.TenKhachThue = tenkhachthue;
            this.SoCMND = socmnd;
            this.NamSinh = namsinh;
            this.GioiTinh = gt;
            this.DienThoai = sdt;
            this.HoTenNguoiThan = tennguoithan ;
            this.DiaChi = diachi;
            this.MaLoaiKhach = maloaikhach;
        }
       public KhachThueDTO(String makhachthue, String hokhachthue, string tenkhachthue, string socmnd, string namsinh, String gt, string sdt, string tennguoithan, string diachi, string maloaikhach)
       {
           this.MaKhachThue = makhachthue;
           this.HoKhachThue = hokhachthue;
           this.TenKhachThue = tenkhachthue;
           this.SoCMND = socmnd;
           this.NamSinh = namsinh;
           this.Gt = gt;
           this.DienThoai = sdt;
           this.HoTenNguoiThan = tennguoithan;
           this.DiaChi = diachi;
           this.MaLoaiKhach = maloaikhach;
       }

      
        public String MaLoaiKhach
        {
            get { return maLoaiKhach; }
            set { maLoaiKhach = value; }
        }

        public String DiaChi
        {
            get { return diaChi; }
            set { diaChi = value; }
        }

        public String HoTenNguoiThan
        {
            get { return hoTenNguoiThan; }
            set { hoTenNguoiThan = value; }
        }

        public String DienThoai
        {
            get { return dienThoai; }
            set { dienThoai = value; }
        }

        public String NamSinh
        {
            get { return namSinh; }
            set { namSinh = value; }
        }

        public String SoCMND
        {
            get { return soCMND; }
            set { soCMND = value; }
        }

        public String TenKhachThue
        {
            get { return tenKhachThue; }
            set { tenKhachThue = value; }
        }

        public String HoKhachThue
        {
            get { return hoKhachThue; }
            set { hoKhachThue = value; }
        }

        public String MaKhachThue
        {
            get { return maKhachThue; }
            set { maKhachThue = value; }
        }
       
    }
}
