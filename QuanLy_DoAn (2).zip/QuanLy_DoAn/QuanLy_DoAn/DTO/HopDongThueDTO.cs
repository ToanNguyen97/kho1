﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class HopDongThueDTO
    {
        string maHopDong, maKhachThue, maPhong, ngayLap, maNhanVien;
       public HopDongThueDTO(String mahd, string makhach, string map,string ngaylap,string manv)
        {
            this.MaHopDong = mahd;
            this.MaKhachThue = makhach;
            this.MaPhong = map;
            this.NgayLap = ngaylap;
            this.MaNhanVien = manv;
        }
       public HopDongThueDTO(DataRow row)
       {
           this.MaHopDong = row["MaHopDong"].ToString();
           this.MaKhachThue = row["MaKhachThue"].ToString(); ;
           this.MaPhong = row["MaPhong"].ToString();
           this.NgayLap = row["NgayLap"].ToString();
           this.MaNhanVien = row["MaNhanVien"].ToString();
       }
        public string MaHopDong
        {
            get { return maHopDong; }
            set { maHopDong = value; }
        }

        public string MaKhachThue
        {
            get { return maKhachThue; }
            set { maKhachThue = value; }
        }

        public string MaPhong
        {
            get { return maPhong; }
            set { maPhong = value; }
        }

        public string NgayLap
        {
            get { return ngayLap; }
            set { ngayLap = value; }
        }

        public string MaNhanVien
        {
            get { return maNhanVien; }
            set { maNhanVien = value; }
        }
    }
}
