﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class KhachThueDAO
    {
        private static KhachThueDAO instance;

        public static KhachThueDAO Instance
        {
            get { if (instance == null) instance = new KhachThueDAO();
                return KhachThueDAO.instance; }
          private  set { KhachThueDAO.instance = value; }
        }
        private KhachThueDAO() { }
       public DataTable KhachThue_DS()
        {
            return DataProvider.Instance.ExcuteQuery("KhachThue_DS");
         
        }
       public DataTable LoaiKhachThue_DS()
        {
            return DataProvider.Instance.ExcuteQuery("LoaiKhach_DS");
      
        }
       public List<KhachThueDTO> LoadList()
       {
           List<KhachThueDTO> tablelist = new List<KhachThueDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("SELECT MaKhachThue ,HoKhachThue ,TenKhachThue ,SoCMND ,NamSinh , CASE WHEN GioiTinh = 1 THEN N'Nam' ELSE N'Nữ' END AS N'GioiTinh', DienThoai , HoTenNguoiThan,DiaChi,MaLoaiKhach FROM dbo.KhachThue");
           foreach(DataRow item in data.Rows)
           {
               KhachThueDTO khachdto = new KhachThueDTO(item);
               tablelist.Add(khachdto);
           }
           return tablelist;
       }
       public void GetInfoByMa(KhachThueDTO dto , string ma)
       {
           List<KhachThueDTO> listkhach = LoadList();
           for(int i = 0; i< listkhach.Count ;i++ )
           {
               if(listkhach[i].MaKhachThue.Equals(ma))
               {
                   dto.MaKhachThue = listkhach[i].MaKhachThue;
                   dto.HoKhachThue = listkhach[i].HoKhachThue;
                   dto.TenKhachThue = listkhach[i].TenKhachThue;
                   dto.SoCMND = listkhach[i].SoCMND;
                   dto.NamSinh = listkhach[i].NamSinh;
                 //  if (listkhach[i].GioiTinh == 1)
                   dto.Gt = listkhach[i].Gt;
                   dto.DienThoai = listkhach[i].DienThoai;
                   dto.HoTenNguoiThan = listkhach[i].HoTenNguoiThan;
                   dto.DiaChi = listkhach[i].DiaChi;
                   dto.MaLoaiKhach = listkhach[i].MaLoaiKhach;
               }
           }
       }
       public void LoadByMaKhach(KhachThueDTO khachdto,string ma)
       {
           List<KhachThueDTO> listdto = LoadList();
           for(int i = 0; i< listdto.Count;i++)
           {
               if(listdto[i].MaKhachThue.Equals(ma))
               {
                   khachdto.MaKhachThue = listdto[i].MaKhachThue;
                   khachdto.HoKhachThue = listdto[i].HoKhachThue;
                   khachdto.TenKhachThue = listdto[i].TenKhachThue;
                   khachdto.SoCMND = listdto[i].SoCMND;
                   khachdto.NamSinh = listdto[i].NamSinh;
                   khachdto.GioiTinh = listdto[i].GioiTinh;
                   khachdto.DienThoai = listdto[i].DienThoai;
                   khachdto.HoTenNguoiThan = listdto[i].HoTenNguoiThan;
                   khachdto.DiaChi = listdto[i].DiaChi;
                   khachdto.MaLoaiKhach = listdto[i].MaLoaiKhach;

               }
           }
       }
       public void KhachThue_Them(KhachThueDTO khdto)
       {
           string query = "KhachThue_Them @MaKhachThue , @HoKhachThue , @TenKhachThue , @SoCMND , @NamSinh , @GioiTinh , @DienThoai , @HoTenNguoiThan , @DiaChi , @MaLoaiKhach";
           DataProvider.Instance.ExcuteNonQuery(query,new object[]{khdto.MaKhachThue,khdto.HoKhachThue,khdto.TenKhachThue,khdto.SoCMND,khdto.NamSinh,khdto.GioiTinh,khdto.DienThoai,khdto.HoTenNguoiThan,khdto.DiaChi,khdto.MaLoaiKhach});
       }

       public void KhachThue_Sưa(KhachThueDTO khdto)
       {
           string query = "KhachThue_Sua @MaKhachThue , @HoKhachThue , @TenKhachThue , @SoCMND , @NamSinh , @GioiTinh , @DienThoai , @HoTenNguoiThan , @DiaChi , @MaLoaiKhach";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { khdto.MaKhachThue, khdto.HoKhachThue, khdto.TenKhachThue, khdto.SoCMND, khdto.NamSinh, khdto.GioiTinh, khdto.DienThoai, khdto.HoTenNguoiThan, khdto.DiaChi, khdto.MaLoaiKhach });
       }
       public void KhachThue_Xoa(KhachThueDTO khdto)
       {
           string query = "KhachThue_Xoa @MaKhachThue";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { khdto.MaKhachThue});
       }
    }
}
