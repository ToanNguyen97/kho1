﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class PhongDAO
    {
        private static PhongDAO instance;

        public static PhongDAO Instance
        {
            get { if (instance == null) instance = new PhongDAO();
                return PhongDAO.instance; }
             private  set { PhongDAO.instance = value; }
        }
        private PhongDAO() { }
        public static int PhongWith = 90;
        public static int PhongHeight = 90;
        public static int timestep = 100; // thơi gian tăng một lần tick
        public static int timeend = 10000; // thời gian để ngừng đếm ngược
        public static int timeinterval = 100;
       public DataTable LoadPhong()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM Phong");
        }
      
       public void Phong_Them(PhongDTO phongdto)
       {
           string query = "Phong_Them @MaPhong , @TenPhong , @MaLoaiPhong , @MaKhuPhong , @MaTinhTrang , @GhiChu , @MaNoiQuy ";
          DataProvider.Instance.ExcuteNonQuery(query,new object[]{phongdto.MaPhong,phongdto.TenPhong,phongdto.MaLoaiPhong,phongdto.MaKhuPhong,phongdto.MaTinhTrang,phongdto.GhiChu,phongdto.MaNoiQuy});
       }
       
       public void Phong_Sua(PhongDTO phongdto)
       {
           string query = "Phong_Sua @MaPhong , @TenPhong , @MaLoaiPhong , @MaKhuPhong , @MaTinhTrang , @GhiChu , @MaNoiQuy ";
          DataProvider.Instance.ExcuteNonQuery(query,new object[]{phongdto.MaPhong,phongdto.TenPhong,phongdto.MaLoaiPhong,phongdto.MaKhuPhong,phongdto.MaTinhTrang,phongdto.GhiChu,phongdto.MaNoiQuy});
       }
       public void Phong_Xoa(PhongDTO phongdto)
       {
           string query = "Phong_Xoa @MaPhong ";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { phongdto.MaPhong  });
       }
       public List<PhongDTO> LoadListbyMaPhong(String makhuphong)
        {
            List<PhongDTO> tablelist = new List<PhongDTO>();
            DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaKhuPhong @MaKhuPhong ",new object[]{makhuphong});
            foreach (DataRow item in data.Rows)
            {
                PhongDTO acc = new PhongDTO(item);
                tablelist.Add(acc);
            }
            return tablelist;
        } // tìm phòng theo mã phòng
       public List<PhongDTO> LoadListbyGiaPhong(String giaphong)
       {
           List<PhongDTO> tablelist = new List<PhongDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaLoaiPhong @MaLoaiPhong ", new object[] { giaphong });
           foreach (DataRow item in data.Rows)
           {
               PhongDTO acc = new PhongDTO(item);
               tablelist.Add(acc);
           }
           return tablelist;
       } // tìm phòng theo gia phong
        public List<PhongDTO> LoadListbyMaLoaiPhong(String maloaiphong)
       {
           List<PhongDTO> tablelist = new List<PhongDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaLoaiPhong @MaLoaiPhong ", new object[] { maloaiphong});
           foreach (DataRow item in data.Rows)
           {
               PhongDTO acc = new PhongDTO(item);
               tablelist.Add(acc);
           }
           return tablelist;
       } //tìm phòng theo mã loại
       public List<PhongDTO> LoadListbyMaTinhTrang(String matinhtrang)
       {
           List<PhongDTO> tablelist = new List<PhongDTO>();
           DataTable data = DataProvider.Instance.ExcuteQuery("getPhongByMaTinhTrangPhong @MaTinhTrang ", new object[] {matinhtrang});
           foreach (DataRow item in data.Rows)
           {
               PhongDTO acc = new PhongDTO(item);
               tablelist.Add(acc);
           }
           return tablelist;
       } // tìm phòng theo tình trạng
    }
}
