﻿namespace QuanLy_DoAn.FormAPP
{
    partial class InHopDongForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SuperToolTip superToolTip50 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem50 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem50 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip51 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem51 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem51 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip52 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem52 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem52 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip53 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem53 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem53 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip54 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem54 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem54 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip55 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem55 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem55 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip56 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem56 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem56 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip57 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem57 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem57 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip58 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem58 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem58 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip59 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem59 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem59 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip60 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem60 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem60 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip61 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem61 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem61 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip62 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem62 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem62 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip63 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem63 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem63 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip64 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem64 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem64 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip65 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem65 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem65 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip66 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem66 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem66 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip67 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem67 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem67 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip68 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem68 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem68 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip69 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem69 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem69 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip70 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem70 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem70 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip71 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem71 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem71 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip72 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem72 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem72 = new DevExpress.Utils.ToolTipItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InHopDongForm));
            DevExpress.Utils.SuperToolTip superToolTip73 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem73 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem73 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip74 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem74 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem74 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip75 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem75 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem75 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip76 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem76 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem76 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip77 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem77 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem77 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip78 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem78 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem78 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip79 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem79 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem79 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip80 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem80 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem80 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip81 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem81 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem81 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip82 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem82 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem82 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip83 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem83 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem83 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip84 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem84 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem84 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip85 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem85 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem85 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip86 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem86 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem86 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip87 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem87 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem87 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip88 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem88 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem88 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip89 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem89 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem89 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip90 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem90 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem90 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip91 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem91 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem91 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip92 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem92 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem92 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip93 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem93 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem93 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip94 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem94 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem94 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip95 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem95 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem95 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip96 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem96 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem96 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip97 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem97 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem97 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip98 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem98 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem98 = new DevExpress.Utils.ToolTipItem();
            this.documentViewer1 = new DevExpress.XtraPrinting.Preview.DocumentViewer();
            this.documentViewerRibbonController1 = new DevExpress.XtraPrinting.Preview.DocumentViewerRibbonController(this.components);
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.printPreviewBarItem1 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem2 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem3 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem4 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem5 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem6 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem7 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem8 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem9 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem10 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem11 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem12 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem13 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem14 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem15 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem16 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem17 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem18 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem19 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem20 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem21 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem22 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem23 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem24 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem25 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem26 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem27 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem28 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem29 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem30 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem31 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem32 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem33 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem34 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem35 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem36 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem37 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem38 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem39 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem40 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem41 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem42 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem43 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem44 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem45 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem46 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem47 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem48 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewStaticItem1 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.progressBarEditItem1 = new DevExpress.XtraPrinting.Preview.ProgressBarEditItem();
            this.repositoryItemProgressBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
            this.printPreviewBarItem49 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.printPreviewStaticItem2 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.zoomTrackBarEditItem1 = new DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem();
            this.repositoryItemZoomTrackBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar();
            this.ribbonPage1 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage();
            this.printPreviewRibbonPageGroup1 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup2 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup3 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup4 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup5 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup6 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup7 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup8 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.ribbonStatusBar1 = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.txtmahd = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.documentViewerRibbonController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemZoomTrackBar1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // documentViewer1
            // 
            this.documentViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.documentViewer1.IsMetric = false;
            this.documentViewer1.Location = new System.Drawing.Point(0, 167);
            this.documentViewer1.Name = "documentViewer1";
            this.documentViewer1.Size = new System.Drawing.Size(1175, 565);
            this.documentViewer1.TabIndex = 0;
            // 
            // documentViewerRibbonController1
            // 
            this.documentViewerRibbonController1.DocumentViewer = this.documentViewer1;
            this.documentViewerRibbonController1.RibbonControl = this.ribbonControl1;
            this.documentViewerRibbonController1.RibbonStatusBar = this.ribbonStatusBar1;
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.AutoHideEmptyItems = true;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.printPreviewBarItem1,
            this.printPreviewBarItem2,
            this.printPreviewBarItem3,
            this.printPreviewBarItem4,
            this.printPreviewBarItem5,
            this.printPreviewBarItem6,
            this.printPreviewBarItem7,
            this.printPreviewBarItem8,
            this.printPreviewBarItem9,
            this.printPreviewBarItem10,
            this.printPreviewBarItem11,
            this.printPreviewBarItem12,
            this.printPreviewBarItem13,
            this.printPreviewBarItem14,
            this.printPreviewBarItem15,
            this.printPreviewBarItem16,
            this.printPreviewBarItem17,
            this.printPreviewBarItem18,
            this.printPreviewBarItem19,
            this.printPreviewBarItem20,
            this.printPreviewBarItem21,
            this.printPreviewBarItem22,
            this.printPreviewBarItem23,
            this.printPreviewBarItem24,
            this.printPreviewBarItem25,
            this.printPreviewBarItem26,
            this.printPreviewBarItem27,
            this.printPreviewBarItem28,
            this.printPreviewBarItem29,
            this.printPreviewBarItem30,
            this.printPreviewBarItem31,
            this.printPreviewBarItem32,
            this.printPreviewBarItem33,
            this.printPreviewBarItem34,
            this.printPreviewBarItem35,
            this.printPreviewBarItem36,
            this.printPreviewBarItem37,
            this.printPreviewBarItem38,
            this.printPreviewBarItem39,
            this.printPreviewBarItem40,
            this.printPreviewBarItem41,
            this.printPreviewBarItem42,
            this.printPreviewBarItem43,
            this.printPreviewBarItem44,
            this.printPreviewBarItem45,
            this.printPreviewBarItem46,
            this.printPreviewBarItem47,
            this.printPreviewBarItem48,
            this.printPreviewStaticItem1,
            this.barStaticItem1,
            this.progressBarEditItem1,
            this.printPreviewBarItem49,
            this.barButtonItem1,
            this.printPreviewStaticItem2,
            this.zoomTrackBarEditItem1,
            this.barEditItem1});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 57;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemProgressBar1,
            this.repositoryItemZoomTrackBar1,
            this.repositoryItemTextEdit1});
            this.ribbonControl1.Size = new System.Drawing.Size(1175, 167);
            this.ribbonControl1.StatusBar = this.ribbonStatusBar1;
            this.ribbonControl1.TransparentEditors = true;
            // 
            // printPreviewBarItem1
            // 
            this.printPreviewBarItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem1.Caption = "Bookmarks";
            this.printPreviewBarItem1.Command = DevExpress.XtraPrinting.PrintingSystemCommand.DocumentMap;
            this.printPreviewBarItem1.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem1.Enabled = false;
            this.printPreviewBarItem1.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_DocumentMap;
            this.printPreviewBarItem1.Id = 1;
            this.printPreviewBarItem1.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_DocumentMapLarge;
            this.printPreviewBarItem1.Name = "printPreviewBarItem1";
            superToolTip50.FixedTooltipWidth = true;
            toolTipTitleItem50.Text = "Document Map";
            toolTipItem50.LeftIndent = 6;
            toolTipItem50.Text = "Open the Document Map, which allows you to navigate through a structural view of " +
    "the document.";
            superToolTip50.Items.Add(toolTipTitleItem50);
            superToolTip50.Items.Add(toolTipItem50);
            superToolTip50.MaxWidth = 210;
            this.printPreviewBarItem1.SuperTip = superToolTip50;
            // 
            // printPreviewBarItem2
            // 
            this.printPreviewBarItem2.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem2.Caption = "Parameters";
            this.printPreviewBarItem2.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Parameters;
            this.printPreviewBarItem2.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem2.Enabled = false;
            this.printPreviewBarItem2.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Parameters;
            this.printPreviewBarItem2.Id = 2;
            this.printPreviewBarItem2.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ParametersLarge;
            this.printPreviewBarItem2.Name = "printPreviewBarItem2";
            superToolTip51.FixedTooltipWidth = true;
            toolTipTitleItem51.Text = "Parameters";
            toolTipItem51.LeftIndent = 6;
            toolTipItem51.Text = "Open the Parameters pane, which allows you to enter values for report parameters." +
    "";
            superToolTip51.Items.Add(toolTipTitleItem51);
            superToolTip51.Items.Add(toolTipItem51);
            superToolTip51.MaxWidth = 210;
            this.printPreviewBarItem2.SuperTip = superToolTip51;
            // 
            // printPreviewBarItem3
            // 
            this.printPreviewBarItem3.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem3.Caption = "Find";
            this.printPreviewBarItem3.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Find;
            this.printPreviewBarItem3.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem3.Enabled = false;
            this.printPreviewBarItem3.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Find;
            this.printPreviewBarItem3.Id = 3;
            this.printPreviewBarItem3.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_FindLarge;
            this.printPreviewBarItem3.Name = "printPreviewBarItem3";
            superToolTip52.FixedTooltipWidth = true;
            toolTipTitleItem52.Text = "Find";
            toolTipItem52.LeftIndent = 6;
            toolTipItem52.Text = "Show the Find dialog to find text in the document.";
            superToolTip52.Items.Add(toolTipTitleItem52);
            superToolTip52.Items.Add(toolTipItem52);
            superToolTip52.MaxWidth = 210;
            this.printPreviewBarItem3.SuperTip = superToolTip52;
            // 
            // printPreviewBarItem4
            // 
            this.printPreviewBarItem4.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem4.Caption = "Thumbnails";
            this.printPreviewBarItem4.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Thumbnails;
            this.printPreviewBarItem4.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem4.Enabled = false;
            this.printPreviewBarItem4.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Thumbnails;
            this.printPreviewBarItem4.Id = 4;
            this.printPreviewBarItem4.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ThumbnailsLarge;
            this.printPreviewBarItem4.Name = "printPreviewBarItem4";
            superToolTip53.FixedTooltipWidth = true;
            toolTipTitleItem53.Text = "Thumbnails";
            toolTipItem53.LeftIndent = 6;
            toolTipItem53.Text = "Open the Thumbnails, which allows you to navigate through the document.";
            superToolTip53.Items.Add(toolTipTitleItem53);
            superToolTip53.Items.Add(toolTipItem53);
            superToolTip53.MaxWidth = 210;
            this.printPreviewBarItem4.SuperTip = superToolTip53;
            // 
            // printPreviewBarItem5
            // 
            this.printPreviewBarItem5.Caption = "Options";
            this.printPreviewBarItem5.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Customize;
            this.printPreviewBarItem5.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem5.Enabled = false;
            this.printPreviewBarItem5.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Customize;
            this.printPreviewBarItem5.Id = 5;
            this.printPreviewBarItem5.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_CustomizeLarge;
            this.printPreviewBarItem5.Name = "printPreviewBarItem5";
            superToolTip54.FixedTooltipWidth = true;
            toolTipTitleItem54.Text = "Options";
            toolTipItem54.LeftIndent = 6;
            toolTipItem54.Text = "Open the Print Options dialog, in which you can change printing options.";
            superToolTip54.Items.Add(toolTipTitleItem54);
            superToolTip54.Items.Add(toolTipItem54);
            superToolTip54.MaxWidth = 210;
            this.printPreviewBarItem5.SuperTip = superToolTip54;
            // 
            // printPreviewBarItem6
            // 
            this.printPreviewBarItem6.Caption = "Print";
            this.printPreviewBarItem6.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Print;
            this.printPreviewBarItem6.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem6.Enabled = false;
            this.printPreviewBarItem6.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Print;
            this.printPreviewBarItem6.Id = 6;
            this.printPreviewBarItem6.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PrintLarge;
            this.printPreviewBarItem6.Name = "printPreviewBarItem6";
            superToolTip55.FixedTooltipWidth = true;
            toolTipTitleItem55.Text = "Print (Ctrl+P)";
            toolTipItem55.LeftIndent = 6;
            toolTipItem55.Text = "Select a printer, number of copies and other printing options before printing.";
            superToolTip55.Items.Add(toolTipTitleItem55);
            superToolTip55.Items.Add(toolTipItem55);
            superToolTip55.MaxWidth = 210;
            this.printPreviewBarItem6.SuperTip = superToolTip55;
            // 
            // printPreviewBarItem7
            // 
            this.printPreviewBarItem7.Caption = "Quick Print";
            this.printPreviewBarItem7.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PrintDirect;
            this.printPreviewBarItem7.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem7.Enabled = false;
            this.printPreviewBarItem7.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PrintDirect;
            this.printPreviewBarItem7.Id = 7;
            this.printPreviewBarItem7.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PrintDirectLarge;
            this.printPreviewBarItem7.Name = "printPreviewBarItem7";
            superToolTip56.FixedTooltipWidth = true;
            toolTipTitleItem56.Text = "Quick Print";
            toolTipItem56.LeftIndent = 6;
            toolTipItem56.Text = "Send the document directly to the default printer without making changes.";
            superToolTip56.Items.Add(toolTipTitleItem56);
            superToolTip56.Items.Add(toolTipItem56);
            superToolTip56.MaxWidth = 210;
            this.printPreviewBarItem7.SuperTip = superToolTip56;
            // 
            // printPreviewBarItem8
            // 
            this.printPreviewBarItem8.Caption = "Custom Margins...";
            this.printPreviewBarItem8.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageSetup;
            this.printPreviewBarItem8.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem8.Enabled = false;
            this.printPreviewBarItem8.Id = 8;
            this.printPreviewBarItem8.Name = "printPreviewBarItem8";
            superToolTip57.FixedTooltipWidth = true;
            toolTipTitleItem57.Text = "Page Setup";
            toolTipItem57.LeftIndent = 6;
            toolTipItem57.Text = "Show the Page Setup dialog.";
            superToolTip57.Items.Add(toolTipTitleItem57);
            superToolTip57.Items.Add(toolTipItem57);
            superToolTip57.MaxWidth = 210;
            this.printPreviewBarItem8.SuperTip = superToolTip57;
            // 
            // printPreviewBarItem9
            // 
            this.printPreviewBarItem9.Caption = "Header/Footer";
            this.printPreviewBarItem9.Command = DevExpress.XtraPrinting.PrintingSystemCommand.EditPageHF;
            this.printPreviewBarItem9.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem9.Enabled = false;
            this.printPreviewBarItem9.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_EditPageHF;
            this.printPreviewBarItem9.Id = 9;
            this.printPreviewBarItem9.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_EditPageHFLarge;
            this.printPreviewBarItem9.Name = "printPreviewBarItem9";
            superToolTip58.FixedTooltipWidth = true;
            toolTipTitleItem58.Text = "Header and Footer";
            toolTipItem58.LeftIndent = 6;
            toolTipItem58.Text = "Edit the header and footer of the document.";
            superToolTip58.Items.Add(toolTipTitleItem58);
            superToolTip58.Items.Add(toolTipItem58);
            superToolTip58.MaxWidth = 210;
            this.printPreviewBarItem9.SuperTip = superToolTip58;
            // 
            // printPreviewBarItem10
            // 
            this.printPreviewBarItem10.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem10.Caption = "Scale";
            this.printPreviewBarItem10.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Scale;
            this.printPreviewBarItem10.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem10.Enabled = false;
            this.printPreviewBarItem10.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Scale;
            this.printPreviewBarItem10.Id = 10;
            this.printPreviewBarItem10.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ScaleLarge;
            this.printPreviewBarItem10.Name = "printPreviewBarItem10";
            superToolTip59.FixedTooltipWidth = true;
            toolTipTitleItem59.Text = "Scale";
            toolTipItem59.LeftIndent = 6;
            toolTipItem59.Text = "Stretch or shrink the printed output to a percentage of its actual size.";
            superToolTip59.Items.Add(toolTipTitleItem59);
            superToolTip59.Items.Add(toolTipItem59);
            superToolTip59.MaxWidth = 210;
            this.printPreviewBarItem10.SuperTip = superToolTip59;
            // 
            // printPreviewBarItem11
            // 
            this.printPreviewBarItem11.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem11.Caption = "Pointer";
            this.printPreviewBarItem11.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Pointer;
            this.printPreviewBarItem11.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem11.Down = true;
            this.printPreviewBarItem11.Enabled = false;
            this.printPreviewBarItem11.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Pointer;
            this.printPreviewBarItem11.GroupIndex = 1;
            this.printPreviewBarItem11.Id = 11;
            this.printPreviewBarItem11.Name = "printPreviewBarItem11";
            this.printPreviewBarItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip60.FixedTooltipWidth = true;
            toolTipTitleItem60.Text = "Mouse Pointer";
            toolTipItem60.LeftIndent = 6;
            toolTipItem60.Text = "Show the mouse pointer.";
            superToolTip60.Items.Add(toolTipTitleItem60);
            superToolTip60.Items.Add(toolTipItem60);
            superToolTip60.MaxWidth = 210;
            this.printPreviewBarItem11.SuperTip = superToolTip60;
            // 
            // printPreviewBarItem12
            // 
            this.printPreviewBarItem12.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem12.Caption = "Hand Tool";
            this.printPreviewBarItem12.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HandTool;
            this.printPreviewBarItem12.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem12.Enabled = false;
            this.printPreviewBarItem12.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_HandTool;
            this.printPreviewBarItem12.GroupIndex = 1;
            this.printPreviewBarItem12.Id = 12;
            this.printPreviewBarItem12.Name = "printPreviewBarItem12";
            this.printPreviewBarItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip61.FixedTooltipWidth = true;
            toolTipTitleItem61.Text = "Hand Tool";
            toolTipItem61.LeftIndent = 6;
            toolTipItem61.Text = "Invoke the Hand tool to manually scroll through pages.";
            superToolTip61.Items.Add(toolTipTitleItem61);
            superToolTip61.Items.Add(toolTipItem61);
            superToolTip61.MaxWidth = 210;
            this.printPreviewBarItem12.SuperTip = superToolTip61;
            // 
            // printPreviewBarItem13
            // 
            this.printPreviewBarItem13.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem13.Caption = "Magnifier";
            this.printPreviewBarItem13.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Magnifier;
            this.printPreviewBarItem13.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem13.Enabled = false;
            this.printPreviewBarItem13.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Magnifier;
            this.printPreviewBarItem13.GroupIndex = 1;
            this.printPreviewBarItem13.Id = 13;
            this.printPreviewBarItem13.Name = "printPreviewBarItem13";
            this.printPreviewBarItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip62.FixedTooltipWidth = true;
            toolTipTitleItem62.Text = "Magnifier";
            toolTipItem62.LeftIndent = 6;
            toolTipItem62.Text = "Invoke the Magnifier tool.\r\n\r\nClicking once on a document zooms it so that a sing" +
    "le page becomes entirely visible, while clicking another time zooms it to 100% o" +
    "f the normal size.";
            superToolTip62.Items.Add(toolTipTitleItem62);
            superToolTip62.Items.Add(toolTipItem62);
            superToolTip62.MaxWidth = 210;
            this.printPreviewBarItem13.SuperTip = superToolTip62;
            // 
            // printPreviewBarItem14
            // 
            this.printPreviewBarItem14.Caption = "Zoom Out";
            this.printPreviewBarItem14.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomOut;
            this.printPreviewBarItem14.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem14.Enabled = false;
            this.printPreviewBarItem14.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ZoomOut;
            this.printPreviewBarItem14.Id = 14;
            this.printPreviewBarItem14.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ZoomOutLarge;
            this.printPreviewBarItem14.Name = "printPreviewBarItem14";
            superToolTip63.FixedTooltipWidth = true;
            toolTipTitleItem63.Text = "Zoom Out";
            toolTipItem63.LeftIndent = 6;
            toolTipItem63.Text = "Zoom out to see more of the page at a reduced size.";
            superToolTip63.Items.Add(toolTipTitleItem63);
            superToolTip63.Items.Add(toolTipItem63);
            superToolTip63.MaxWidth = 210;
            this.printPreviewBarItem14.SuperTip = superToolTip63;
            // 
            // printPreviewBarItem15
            // 
            this.printPreviewBarItem15.Caption = "Zoom In";
            this.printPreviewBarItem15.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomIn;
            this.printPreviewBarItem15.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem15.Enabled = false;
            this.printPreviewBarItem15.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ZoomIn;
            this.printPreviewBarItem15.Id = 15;
            this.printPreviewBarItem15.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ZoomInLarge;
            this.printPreviewBarItem15.Name = "printPreviewBarItem15";
            superToolTip64.FixedTooltipWidth = true;
            toolTipTitleItem64.Text = "Zoom In";
            toolTipItem64.LeftIndent = 6;
            toolTipItem64.Text = "Zoom in to get a close-up view of the document.";
            superToolTip64.Items.Add(toolTipTitleItem64);
            superToolTip64.Items.Add(toolTipItem64);
            superToolTip64.MaxWidth = 210;
            this.printPreviewBarItem15.SuperTip = superToolTip64;
            // 
            // printPreviewBarItem16
            // 
            this.printPreviewBarItem16.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem16.Caption = "Zoom";
            this.printPreviewBarItem16.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Zoom;
            this.printPreviewBarItem16.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem16.Enabled = false;
            this.printPreviewBarItem16.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Zoom;
            this.printPreviewBarItem16.Id = 16;
            this.printPreviewBarItem16.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ZoomLarge;
            this.printPreviewBarItem16.Name = "printPreviewBarItem16";
            superToolTip65.FixedTooltipWidth = true;
            toolTipTitleItem65.Text = "Zoom";
            toolTipItem65.LeftIndent = 6;
            toolTipItem65.Text = "Change the zoom level of the document preview.";
            superToolTip65.Items.Add(toolTipTitleItem65);
            superToolTip65.Items.Add(toolTipItem65);
            superToolTip65.MaxWidth = 210;
            this.printPreviewBarItem16.SuperTip = superToolTip65;
            // 
            // printPreviewBarItem17
            // 
            this.printPreviewBarItem17.Caption = "First Page";
            this.printPreviewBarItem17.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowFirstPage;
            this.printPreviewBarItem17.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem17.Enabled = false;
            this.printPreviewBarItem17.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowFirstPage;
            this.printPreviewBarItem17.Id = 17;
            this.printPreviewBarItem17.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowFirstPageLarge;
            this.printPreviewBarItem17.Name = "printPreviewBarItem17";
            superToolTip66.FixedTooltipWidth = true;
            toolTipTitleItem66.Text = "First Page (Ctrl+Home)";
            toolTipItem66.LeftIndent = 6;
            toolTipItem66.Text = "Navigate to the first page of the document.";
            superToolTip66.Items.Add(toolTipTitleItem66);
            superToolTip66.Items.Add(toolTipItem66);
            superToolTip66.MaxWidth = 210;
            this.printPreviewBarItem17.SuperTip = superToolTip66;
            // 
            // printPreviewBarItem18
            // 
            this.printPreviewBarItem18.Caption = "Previous Page";
            this.printPreviewBarItem18.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowPrevPage;
            this.printPreviewBarItem18.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem18.Enabled = false;
            this.printPreviewBarItem18.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowPrevPage;
            this.printPreviewBarItem18.Id = 18;
            this.printPreviewBarItem18.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowPrevPageLarge;
            this.printPreviewBarItem18.Name = "printPreviewBarItem18";
            superToolTip67.FixedTooltipWidth = true;
            toolTipTitleItem67.Text = "Previous Page (PageUp)";
            toolTipItem67.LeftIndent = 6;
            toolTipItem67.Text = "Navigate to the previous page of the document.";
            superToolTip67.Items.Add(toolTipTitleItem67);
            superToolTip67.Items.Add(toolTipItem67);
            superToolTip67.MaxWidth = 210;
            this.printPreviewBarItem18.SuperTip = superToolTip67;
            // 
            // printPreviewBarItem19
            // 
            this.printPreviewBarItem19.Caption = "Next  Page ";
            this.printPreviewBarItem19.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowNextPage;
            this.printPreviewBarItem19.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem19.Enabled = false;
            this.printPreviewBarItem19.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowNextPage;
            this.printPreviewBarItem19.Id = 19;
            this.printPreviewBarItem19.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowNextPageLarge;
            this.printPreviewBarItem19.Name = "printPreviewBarItem19";
            superToolTip68.FixedTooltipWidth = true;
            toolTipTitleItem68.Text = "Next Page (PageDown)";
            toolTipItem68.LeftIndent = 6;
            toolTipItem68.Text = "Navigate to the next page of the document.";
            superToolTip68.Items.Add(toolTipTitleItem68);
            superToolTip68.Items.Add(toolTipItem68);
            superToolTip68.MaxWidth = 210;
            this.printPreviewBarItem19.SuperTip = superToolTip68;
            // 
            // printPreviewBarItem20
            // 
            this.printPreviewBarItem20.Caption = "Last  Page ";
            this.printPreviewBarItem20.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowLastPage;
            this.printPreviewBarItem20.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem20.Enabled = false;
            this.printPreviewBarItem20.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowLastPage;
            this.printPreviewBarItem20.Id = 20;
            this.printPreviewBarItem20.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ShowLastPageLarge;
            this.printPreviewBarItem20.Name = "printPreviewBarItem20";
            superToolTip69.FixedTooltipWidth = true;
            toolTipTitleItem69.Text = "Last Page (Ctrl+End)";
            toolTipItem69.LeftIndent = 6;
            toolTipItem69.Text = "Navigate to the last page of the document.";
            superToolTip69.Items.Add(toolTipTitleItem69);
            superToolTip69.Items.Add(toolTipItem69);
            superToolTip69.MaxWidth = 210;
            this.printPreviewBarItem20.SuperTip = superToolTip69;
            // 
            // printPreviewBarItem21
            // 
            this.printPreviewBarItem21.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem21.Caption = "Many Pages";
            this.printPreviewBarItem21.Command = DevExpress.XtraPrinting.PrintingSystemCommand.MultiplePages;
            this.printPreviewBarItem21.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem21.Enabled = false;
            this.printPreviewBarItem21.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_MultiplePages;
            this.printPreviewBarItem21.Id = 21;
            this.printPreviewBarItem21.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_MultiplePagesLarge;
            this.printPreviewBarItem21.Name = "printPreviewBarItem21";
            superToolTip70.FixedTooltipWidth = true;
            toolTipTitleItem70.Text = "View Many Pages";
            toolTipItem70.LeftIndent = 6;
            toolTipItem70.Text = "Choose the page layout to arrange the document pages in preview.";
            superToolTip70.Items.Add(toolTipTitleItem70);
            superToolTip70.Items.Add(toolTipItem70);
            superToolTip70.MaxWidth = 210;
            this.printPreviewBarItem21.SuperTip = superToolTip70;
            // 
            // printPreviewBarItem22
            // 
            this.printPreviewBarItem22.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem22.Caption = "Page Color";
            this.printPreviewBarItem22.Command = DevExpress.XtraPrinting.PrintingSystemCommand.FillBackground;
            this.printPreviewBarItem22.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem22.Enabled = false;
            this.printPreviewBarItem22.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_FillBackground;
            this.printPreviewBarItem22.Id = 22;
            this.printPreviewBarItem22.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_FillBackgroundLarge;
            this.printPreviewBarItem22.Name = "printPreviewBarItem22";
            superToolTip71.FixedTooltipWidth = true;
            toolTipTitleItem71.Text = "Background Color";
            toolTipItem71.LeftIndent = 6;
            toolTipItem71.Text = "Choose a color for the background of the document pages.";
            superToolTip71.Items.Add(toolTipTitleItem71);
            superToolTip71.Items.Add(toolTipItem71);
            superToolTip71.MaxWidth = 210;
            this.printPreviewBarItem22.SuperTip = superToolTip71;
            // 
            // printPreviewBarItem23
            // 
            this.printPreviewBarItem23.Caption = "Watermark";
            this.printPreviewBarItem23.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Watermark;
            this.printPreviewBarItem23.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem23.Enabled = false;
            this.printPreviewBarItem23.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Watermark;
            this.printPreviewBarItem23.Id = 23;
            this.printPreviewBarItem23.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_WatermarkLarge;
            this.printPreviewBarItem23.Name = "printPreviewBarItem23";
            superToolTip72.FixedTooltipWidth = true;
            toolTipTitleItem72.Text = "Watermark";
            toolTipItem72.LeftIndent = 6;
            toolTipItem72.Text = "Insert ghosted text or image behind the content of a page.\r\n\r\nThis is often used " +
    "to indicate that a document is to be treated specially.";
            superToolTip72.Items.Add(toolTipTitleItem72);
            superToolTip72.Items.Add(toolTipItem72);
            superToolTip72.MaxWidth = 210;
            this.printPreviewBarItem23.SuperTip = superToolTip72;
            // 
            // printPreviewBarItem24
            // 
            this.printPreviewBarItem24.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem24.Caption = "Export To";
            this.printPreviewBarItem24.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportFile;
            this.printPreviewBarItem24.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem24.Enabled = false;
            this.printPreviewBarItem24.Glyph = ((System.Drawing.Image)(resources.GetObject("printPreviewBarItem24.Glyph")));
            this.printPreviewBarItem24.Id = 24;
            this.printPreviewBarItem24.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("printPreviewBarItem24.LargeGlyph")));
            this.printPreviewBarItem24.Name = "printPreviewBarItem24";
            superToolTip73.FixedTooltipWidth = true;
            toolTipTitleItem73.Text = "Export To...";
            toolTipItem73.LeftIndent = 6;
            toolTipItem73.Text = "Export the current document in one of the available formats, and save it to the f" +
    "ile on a disk.";
            superToolTip73.Items.Add(toolTipTitleItem73);
            superToolTip73.Items.Add(toolTipItem73);
            superToolTip73.MaxWidth = 210;
            this.printPreviewBarItem24.SuperTip = superToolTip73;
            // 
            // printPreviewBarItem25
            // 
            this.printPreviewBarItem25.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem25.Caption = "E-Mail As";
            this.printPreviewBarItem25.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendFile;
            this.printPreviewBarItem25.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem25.Enabled = false;
            this.printPreviewBarItem25.Glyph = ((System.Drawing.Image)(resources.GetObject("printPreviewBarItem25.Glyph")));
            this.printPreviewBarItem25.Id = 25;
            this.printPreviewBarItem25.LargeGlyph = ((System.Drawing.Image)(resources.GetObject("printPreviewBarItem25.LargeGlyph")));
            this.printPreviewBarItem25.Name = "printPreviewBarItem25";
            superToolTip74.FixedTooltipWidth = true;
            toolTipTitleItem74.Text = "E-Mail As...";
            toolTipItem74.LeftIndent = 6;
            toolTipItem74.Text = "Export the current document in one of the available formats, and attach it to the" +
    " e-mail.";
            superToolTip74.Items.Add(toolTipTitleItem74);
            superToolTip74.Items.Add(toolTipItem74);
            superToolTip74.MaxWidth = 210;
            this.printPreviewBarItem25.SuperTip = superToolTip74;
            // 
            // printPreviewBarItem26
            // 
            this.printPreviewBarItem26.Caption = "Close";
            this.printPreviewBarItem26.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ClosePreview;
            this.printPreviewBarItem26.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem26.Enabled = false;
            this.printPreviewBarItem26.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ClosePreview;
            this.printPreviewBarItem26.Id = 26;
            this.printPreviewBarItem26.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ClosePreviewLarge;
            this.printPreviewBarItem26.Name = "printPreviewBarItem26";
            superToolTip75.FixedTooltipWidth = true;
            toolTipTitleItem75.Text = "Close Print Preview";
            toolTipItem75.LeftIndent = 6;
            toolTipItem75.Text = "Close Print Preview of the document.";
            superToolTip75.Items.Add(toolTipTitleItem75);
            superToolTip75.Items.Add(toolTipItem75);
            superToolTip75.MaxWidth = 210;
            this.printPreviewBarItem26.SuperTip = superToolTip75;
            // 
            // printPreviewBarItem27
            // 
            this.printPreviewBarItem27.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem27.Caption = "Orientation";
            this.printPreviewBarItem27.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageOrientation;
            this.printPreviewBarItem27.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem27.Enabled = false;
            this.printPreviewBarItem27.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PageOrientation;
            this.printPreviewBarItem27.Id = 27;
            this.printPreviewBarItem27.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PageOrientationLarge;
            this.printPreviewBarItem27.Name = "printPreviewBarItem27";
            superToolTip76.FixedTooltipWidth = true;
            toolTipTitleItem76.Text = "Page Orientation";
            toolTipItem76.LeftIndent = 6;
            toolTipItem76.Text = "Switch the pages between portrait and landscape layouts.";
            superToolTip76.Items.Add(toolTipTitleItem76);
            superToolTip76.Items.Add(toolTipItem76);
            superToolTip76.MaxWidth = 210;
            this.printPreviewBarItem27.SuperTip = superToolTip76;
            // 
            // printPreviewBarItem28
            // 
            this.printPreviewBarItem28.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem28.Caption = "Size";
            this.printPreviewBarItem28.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PaperSize;
            this.printPreviewBarItem28.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem28.Enabled = false;
            this.printPreviewBarItem28.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PaperSize;
            this.printPreviewBarItem28.Id = 28;
            this.printPreviewBarItem28.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PaperSizeLarge;
            this.printPreviewBarItem28.Name = "printPreviewBarItem28";
            superToolTip77.FixedTooltipWidth = true;
            toolTipTitleItem77.Text = "Page Size";
            toolTipItem77.LeftIndent = 6;
            toolTipItem77.Text = "Choose the paper size of the document.";
            superToolTip77.Items.Add(toolTipTitleItem77);
            superToolTip77.Items.Add(toolTipItem77);
            superToolTip77.MaxWidth = 210;
            this.printPreviewBarItem28.SuperTip = superToolTip77;
            // 
            // printPreviewBarItem29
            // 
            this.printPreviewBarItem29.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem29.Caption = "Margins";
            this.printPreviewBarItem29.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageMargins;
            this.printPreviewBarItem29.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem29.Enabled = false;
            this.printPreviewBarItem29.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PageMargins;
            this.printPreviewBarItem29.Id = 29;
            this.printPreviewBarItem29.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PageMarginsLarge;
            this.printPreviewBarItem29.Name = "printPreviewBarItem29";
            superToolTip78.FixedTooltipWidth = true;
            toolTipTitleItem78.Text = "Page Margins";
            toolTipItem78.LeftIndent = 6;
            toolTipItem78.Text = "Select the margin sizes for the entire document.\r\n\r\nTo apply specific margin size" +
    "s to the document, click Custom Margins.";
            superToolTip78.Items.Add(toolTipTitleItem78);
            superToolTip78.Items.Add(toolTipItem78);
            superToolTip78.MaxWidth = 210;
            this.printPreviewBarItem29.SuperTip = superToolTip78;
            // 
            // printPreviewBarItem30
            // 
            this.printPreviewBarItem30.Caption = "PDF File";
            this.printPreviewBarItem30.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendPdf;
            this.printPreviewBarItem30.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem30.Description = "Adobe Portable Document Format";
            this.printPreviewBarItem30.Enabled = false;
            this.printPreviewBarItem30.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendPdf;
            this.printPreviewBarItem30.Id = 30;
            this.printPreviewBarItem30.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendPdfLarge;
            this.printPreviewBarItem30.Name = "printPreviewBarItem30";
            superToolTip79.FixedTooltipWidth = true;
            toolTipTitleItem79.Text = "E-Mail As PDF";
            toolTipItem79.LeftIndent = 6;
            toolTipItem79.Text = "Export the document to PDF and attach it to the e-mail.";
            superToolTip79.Items.Add(toolTipTitleItem79);
            superToolTip79.Items.Add(toolTipItem79);
            superToolTip79.MaxWidth = 210;
            this.printPreviewBarItem30.SuperTip = superToolTip79;
            // 
            // printPreviewBarItem31
            // 
            this.printPreviewBarItem31.Caption = "Text File";
            this.printPreviewBarItem31.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendTxt;
            this.printPreviewBarItem31.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem31.Description = "Plain Text";
            this.printPreviewBarItem31.Enabled = false;
            this.printPreviewBarItem31.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendTxt;
            this.printPreviewBarItem31.Id = 31;
            this.printPreviewBarItem31.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendTxtLarge;
            this.printPreviewBarItem31.Name = "printPreviewBarItem31";
            superToolTip80.FixedTooltipWidth = true;
            toolTipTitleItem80.Text = "E-Mail As Text";
            toolTipItem80.LeftIndent = 6;
            toolTipItem80.Text = "Export the document to Text and attach it to the e-mail.";
            superToolTip80.Items.Add(toolTipTitleItem80);
            superToolTip80.Items.Add(toolTipItem80);
            superToolTip80.MaxWidth = 210;
            this.printPreviewBarItem31.SuperTip = superToolTip80;
            // 
            // printPreviewBarItem32
            // 
            this.printPreviewBarItem32.Caption = "CSV File";
            this.printPreviewBarItem32.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendCsv;
            this.printPreviewBarItem32.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem32.Description = "Comma-Separated Values Text";
            this.printPreviewBarItem32.Enabled = false;
            this.printPreviewBarItem32.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendCsv;
            this.printPreviewBarItem32.Id = 32;
            this.printPreviewBarItem32.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendCsvLarge;
            this.printPreviewBarItem32.Name = "printPreviewBarItem32";
            superToolTip81.FixedTooltipWidth = true;
            toolTipTitleItem81.Text = "E-Mail As CSV";
            toolTipItem81.LeftIndent = 6;
            toolTipItem81.Text = "Export the document to CSV and attach it to the e-mail.";
            superToolTip81.Items.Add(toolTipTitleItem81);
            superToolTip81.Items.Add(toolTipItem81);
            superToolTip81.MaxWidth = 210;
            this.printPreviewBarItem32.SuperTip = superToolTip81;
            // 
            // printPreviewBarItem33
            // 
            this.printPreviewBarItem33.Caption = "MHT File";
            this.printPreviewBarItem33.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendMht;
            this.printPreviewBarItem33.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem33.Description = "Single File Web Page";
            this.printPreviewBarItem33.Enabled = false;
            this.printPreviewBarItem33.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendMht;
            this.printPreviewBarItem33.Id = 33;
            this.printPreviewBarItem33.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendMhtLarge;
            this.printPreviewBarItem33.Name = "printPreviewBarItem33";
            superToolTip82.FixedTooltipWidth = true;
            toolTipTitleItem82.Text = "E-Mail As MHT";
            toolTipItem82.LeftIndent = 6;
            toolTipItem82.Text = "Export the document to MHT and attach it to the e-mail.";
            superToolTip82.Items.Add(toolTipTitleItem82);
            superToolTip82.Items.Add(toolTipItem82);
            superToolTip82.MaxWidth = 210;
            this.printPreviewBarItem33.SuperTip = superToolTip82;
            // 
            // printPreviewBarItem34
            // 
            this.printPreviewBarItem34.Caption = "XLS File";
            this.printPreviewBarItem34.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXls;
            this.printPreviewBarItem34.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem34.Description = "Microsoft Excel 2000-2003 Workbook";
            this.printPreviewBarItem34.Enabled = false;
            this.printPreviewBarItem34.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendXls;
            this.printPreviewBarItem34.Id = 34;
            this.printPreviewBarItem34.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendXlsLarge;
            this.printPreviewBarItem34.Name = "printPreviewBarItem34";
            superToolTip83.FixedTooltipWidth = true;
            toolTipTitleItem83.Text = "E-Mail As XLS";
            toolTipItem83.LeftIndent = 6;
            toolTipItem83.Text = "Export the document to XLS and attach it to the e-mail.";
            superToolTip83.Items.Add(toolTipTitleItem83);
            superToolTip83.Items.Add(toolTipItem83);
            superToolTip83.MaxWidth = 210;
            this.printPreviewBarItem34.SuperTip = superToolTip83;
            // 
            // printPreviewBarItem35
            // 
            this.printPreviewBarItem35.Caption = "XLSX File";
            this.printPreviewBarItem35.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXlsx;
            this.printPreviewBarItem35.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem35.Description = "Microsoft Excel 2007 Workbook";
            this.printPreviewBarItem35.Enabled = false;
            this.printPreviewBarItem35.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendXlsx;
            this.printPreviewBarItem35.Id = 35;
            this.printPreviewBarItem35.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendXlsxLarge;
            this.printPreviewBarItem35.Name = "printPreviewBarItem35";
            superToolTip84.FixedTooltipWidth = true;
            toolTipTitleItem84.Text = "E-Mail As XLSX";
            toolTipItem84.LeftIndent = 6;
            toolTipItem84.Text = "Export the document to XLSX and attach it to the e-mail.";
            superToolTip84.Items.Add(toolTipTitleItem84);
            superToolTip84.Items.Add(toolTipItem84);
            superToolTip84.MaxWidth = 210;
            this.printPreviewBarItem35.SuperTip = superToolTip84;
            // 
            // printPreviewBarItem36
            // 
            this.printPreviewBarItem36.Caption = "RTF File";
            this.printPreviewBarItem36.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendRtf;
            this.printPreviewBarItem36.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem36.Description = "Rich Text Format";
            this.printPreviewBarItem36.Enabled = false;
            this.printPreviewBarItem36.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendRtf;
            this.printPreviewBarItem36.Id = 36;
            this.printPreviewBarItem36.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendRtfLarge;
            this.printPreviewBarItem36.Name = "printPreviewBarItem36";
            superToolTip85.FixedTooltipWidth = true;
            toolTipTitleItem85.Text = "E-Mail As RTF";
            toolTipItem85.LeftIndent = 6;
            toolTipItem85.Text = "Export the document to RTF and attach it to the e-mail.";
            superToolTip85.Items.Add(toolTipTitleItem85);
            superToolTip85.Items.Add(toolTipItem85);
            superToolTip85.MaxWidth = 210;
            this.printPreviewBarItem36.SuperTip = superToolTip85;
            // 
            // printPreviewBarItem37
            // 
            this.printPreviewBarItem37.Caption = "Image File";
            this.printPreviewBarItem37.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendGraphic;
            this.printPreviewBarItem37.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem37.Description = "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF";
            this.printPreviewBarItem37.Enabled = false;
            this.printPreviewBarItem37.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendGraphic;
            this.printPreviewBarItem37.Id = 37;
            this.printPreviewBarItem37.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SendGraphicLarge;
            this.printPreviewBarItem37.Name = "printPreviewBarItem37";
            superToolTip86.FixedTooltipWidth = true;
            toolTipTitleItem86.Text = "E-Mail As Image";
            toolTipItem86.LeftIndent = 6;
            toolTipItem86.Text = "Export the document to Image and attach it to the e-mail.";
            superToolTip86.Items.Add(toolTipTitleItem86);
            superToolTip86.Items.Add(toolTipItem86);
            superToolTip86.MaxWidth = 210;
            this.printPreviewBarItem37.SuperTip = superToolTip86;
            // 
            // printPreviewBarItem38
            // 
            this.printPreviewBarItem38.Caption = "PDF File";
            this.printPreviewBarItem38.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportPdf;
            this.printPreviewBarItem38.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem38.Description = "Adobe Portable Document Format";
            this.printPreviewBarItem38.Enabled = false;
            this.printPreviewBarItem38.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportPdf;
            this.printPreviewBarItem38.Id = 38;
            this.printPreviewBarItem38.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportPdfLarge;
            this.printPreviewBarItem38.Name = "printPreviewBarItem38";
            superToolTip87.FixedTooltipWidth = true;
            toolTipTitleItem87.Text = "Export to PDF";
            toolTipItem87.LeftIndent = 6;
            toolTipItem87.Text = "Export the document to PDF and save it to the file on a disk.";
            superToolTip87.Items.Add(toolTipTitleItem87);
            superToolTip87.Items.Add(toolTipItem87);
            superToolTip87.MaxWidth = 210;
            this.printPreviewBarItem38.SuperTip = superToolTip87;
            // 
            // printPreviewBarItem39
            // 
            this.printPreviewBarItem39.Caption = "HTML File";
            this.printPreviewBarItem39.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportHtm;
            this.printPreviewBarItem39.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem39.Description = "Web Page";
            this.printPreviewBarItem39.Enabled = false;
            this.printPreviewBarItem39.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportHtm;
            this.printPreviewBarItem39.Id = 39;
            this.printPreviewBarItem39.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportHtmLarge;
            this.printPreviewBarItem39.Name = "printPreviewBarItem39";
            superToolTip88.FixedTooltipWidth = true;
            toolTipTitleItem88.Text = "Export to HTML";
            toolTipItem88.LeftIndent = 6;
            toolTipItem88.Text = "Export the document to HTML and save it to the file on a disk.";
            superToolTip88.Items.Add(toolTipTitleItem88);
            superToolTip88.Items.Add(toolTipItem88);
            superToolTip88.MaxWidth = 210;
            this.printPreviewBarItem39.SuperTip = superToolTip88;
            // 
            // printPreviewBarItem40
            // 
            this.printPreviewBarItem40.Caption = "Text File";
            this.printPreviewBarItem40.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportTxt;
            this.printPreviewBarItem40.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem40.Description = "Plain Text";
            this.printPreviewBarItem40.Enabled = false;
            this.printPreviewBarItem40.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportTxt;
            this.printPreviewBarItem40.Id = 40;
            this.printPreviewBarItem40.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportTxtLarge;
            this.printPreviewBarItem40.Name = "printPreviewBarItem40";
            superToolTip89.FixedTooltipWidth = true;
            toolTipTitleItem89.Text = "Export to Text";
            toolTipItem89.LeftIndent = 6;
            toolTipItem89.Text = "Export the document to Text and save it to the file on a disk.";
            superToolTip89.Items.Add(toolTipTitleItem89);
            superToolTip89.Items.Add(toolTipItem89);
            superToolTip89.MaxWidth = 210;
            this.printPreviewBarItem40.SuperTip = superToolTip89;
            // 
            // printPreviewBarItem41
            // 
            this.printPreviewBarItem41.Caption = "CSV File";
            this.printPreviewBarItem41.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportCsv;
            this.printPreviewBarItem41.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem41.Description = "Comma-Separated Values Text";
            this.printPreviewBarItem41.Enabled = false;
            this.printPreviewBarItem41.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportCsv;
            this.printPreviewBarItem41.Id = 41;
            this.printPreviewBarItem41.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportCsvLarge;
            this.printPreviewBarItem41.Name = "printPreviewBarItem41";
            superToolTip90.FixedTooltipWidth = true;
            toolTipTitleItem90.Text = "Export to CSV";
            toolTipItem90.LeftIndent = 6;
            toolTipItem90.Text = "Export the document to CSV and save it to the file on a disk.";
            superToolTip90.Items.Add(toolTipTitleItem90);
            superToolTip90.Items.Add(toolTipItem90);
            superToolTip90.MaxWidth = 210;
            this.printPreviewBarItem41.SuperTip = superToolTip90;
            // 
            // printPreviewBarItem42
            // 
            this.printPreviewBarItem42.Caption = "MHT File";
            this.printPreviewBarItem42.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportMht;
            this.printPreviewBarItem42.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem42.Description = "Single File Web Page";
            this.printPreviewBarItem42.Enabled = false;
            this.printPreviewBarItem42.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportMht;
            this.printPreviewBarItem42.Id = 42;
            this.printPreviewBarItem42.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportMhtLarge;
            this.printPreviewBarItem42.Name = "printPreviewBarItem42";
            superToolTip91.FixedTooltipWidth = true;
            toolTipTitleItem91.Text = "Export to MHT";
            toolTipItem91.LeftIndent = 6;
            toolTipItem91.Text = "Export the document to MHT and save it to the file on a disk.";
            superToolTip91.Items.Add(toolTipTitleItem91);
            superToolTip91.Items.Add(toolTipItem91);
            superToolTip91.MaxWidth = 210;
            this.printPreviewBarItem42.SuperTip = superToolTip91;
            // 
            // printPreviewBarItem43
            // 
            this.printPreviewBarItem43.Caption = "XLS File";
            this.printPreviewBarItem43.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXls;
            this.printPreviewBarItem43.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem43.Description = "Microsoft Excel 2000-2003 Workbook";
            this.printPreviewBarItem43.Enabled = false;
            this.printPreviewBarItem43.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportXls;
            this.printPreviewBarItem43.Id = 43;
            this.printPreviewBarItem43.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportXlsLarge;
            this.printPreviewBarItem43.Name = "printPreviewBarItem43";
            superToolTip92.FixedTooltipWidth = true;
            toolTipTitleItem92.Text = "Export to XLS";
            toolTipItem92.LeftIndent = 6;
            toolTipItem92.Text = "Export the document to XLS and save it to the file on a disk.";
            superToolTip92.Items.Add(toolTipTitleItem92);
            superToolTip92.Items.Add(toolTipItem92);
            superToolTip92.MaxWidth = 210;
            this.printPreviewBarItem43.SuperTip = superToolTip92;
            // 
            // printPreviewBarItem44
            // 
            this.printPreviewBarItem44.Caption = "XLSX File";
            this.printPreviewBarItem44.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXlsx;
            this.printPreviewBarItem44.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem44.Description = "Microsoft Excel 2007 Workbook";
            this.printPreviewBarItem44.Enabled = false;
            this.printPreviewBarItem44.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportXlsx;
            this.printPreviewBarItem44.Id = 44;
            this.printPreviewBarItem44.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportXlsxLarge;
            this.printPreviewBarItem44.Name = "printPreviewBarItem44";
            superToolTip93.FixedTooltipWidth = true;
            toolTipTitleItem93.Text = "Export to XLSX";
            toolTipItem93.LeftIndent = 6;
            toolTipItem93.Text = "Export the document to XLSX and save it to the file on a disk.";
            superToolTip93.Items.Add(toolTipTitleItem93);
            superToolTip93.Items.Add(toolTipItem93);
            superToolTip93.MaxWidth = 210;
            this.printPreviewBarItem44.SuperTip = superToolTip93;
            // 
            // printPreviewBarItem45
            // 
            this.printPreviewBarItem45.Caption = "RTF File";
            this.printPreviewBarItem45.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportRtf;
            this.printPreviewBarItem45.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem45.Description = "Rich Text Format";
            this.printPreviewBarItem45.Enabled = false;
            this.printPreviewBarItem45.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportRtf;
            this.printPreviewBarItem45.Id = 45;
            this.printPreviewBarItem45.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportRtfLarge;
            this.printPreviewBarItem45.Name = "printPreviewBarItem45";
            superToolTip94.FixedTooltipWidth = true;
            toolTipTitleItem94.Text = "Export to RTF";
            toolTipItem94.LeftIndent = 6;
            toolTipItem94.Text = "Export the document to RTF and save it to the file on a disk.";
            superToolTip94.Items.Add(toolTipTitleItem94);
            superToolTip94.Items.Add(toolTipItem94);
            superToolTip94.MaxWidth = 210;
            this.printPreviewBarItem45.SuperTip = superToolTip94;
            // 
            // printPreviewBarItem46
            // 
            this.printPreviewBarItem46.Caption = "Image File";
            this.printPreviewBarItem46.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportGraphic;
            this.printPreviewBarItem46.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem46.Description = "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF";
            this.printPreviewBarItem46.Enabled = false;
            this.printPreviewBarItem46.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportGraphic;
            this.printPreviewBarItem46.Id = 46;
            this.printPreviewBarItem46.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportGraphicLarge;
            this.printPreviewBarItem46.Name = "printPreviewBarItem46";
            superToolTip95.FixedTooltipWidth = true;
            toolTipTitleItem95.Text = "Export to Image";
            toolTipItem95.LeftIndent = 6;
            toolTipItem95.Text = "Export the document to Image and save it to the file on a disk.";
            superToolTip95.Items.Add(toolTipTitleItem95);
            superToolTip95.Items.Add(toolTipItem95);
            superToolTip95.MaxWidth = 210;
            this.printPreviewBarItem46.SuperTip = superToolTip95;
            // 
            // printPreviewBarItem47
            // 
            this.printPreviewBarItem47.Caption = "Open";
            this.printPreviewBarItem47.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Open;
            this.printPreviewBarItem47.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem47.Enabled = false;
            this.printPreviewBarItem47.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Open;
            this.printPreviewBarItem47.Id = 47;
            this.printPreviewBarItem47.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_OpenLarge;
            this.printPreviewBarItem47.Name = "printPreviewBarItem47";
            superToolTip96.FixedTooltipWidth = true;
            toolTipTitleItem96.Text = "Open (Ctrl + O)";
            toolTipItem96.LeftIndent = 6;
            toolTipItem96.Text = "Open a document.";
            superToolTip96.Items.Add(toolTipTitleItem96);
            superToolTip96.Items.Add(toolTipItem96);
            superToolTip96.MaxWidth = 210;
            this.printPreviewBarItem47.SuperTip = superToolTip96;
            // 
            // printPreviewBarItem48
            // 
            this.printPreviewBarItem48.Caption = "Save";
            this.printPreviewBarItem48.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Save;
            this.printPreviewBarItem48.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem48.Enabled = false;
            this.printPreviewBarItem48.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Save;
            this.printPreviewBarItem48.Id = 48;
            this.printPreviewBarItem48.LargeGlyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_SaveLarge;
            this.printPreviewBarItem48.Name = "printPreviewBarItem48";
            superToolTip97.FixedTooltipWidth = true;
            toolTipTitleItem97.Text = "Save (Ctrl + S)";
            toolTipItem97.LeftIndent = 6;
            toolTipItem97.Text = "Save the document.";
            superToolTip97.Items.Add(toolTipTitleItem97);
            superToolTip97.Items.Add(toolTipItem97);
            superToolTip97.MaxWidth = 210;
            this.printPreviewBarItem48.SuperTip = superToolTip97;
            // 
            // printPreviewStaticItem1
            // 
            this.printPreviewStaticItem1.Caption = "Nothing";
            this.printPreviewStaticItem1.Id = 49;
            this.printPreviewStaticItem1.LeftIndent = 1;
            this.printPreviewStaticItem1.Name = "printPreviewStaticItem1";
            this.printPreviewStaticItem1.RightIndent = 1;
            this.printPreviewStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            this.printPreviewStaticItem1.Type = "PageOfPages";
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Id = 50;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            this.barStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInRuntime;
            // 
            // progressBarEditItem1
            // 
            this.progressBarEditItem1.ContextSpecifier = this.documentViewerRibbonController1;
            this.progressBarEditItem1.Edit = this.repositoryItemProgressBar1;
            this.progressBarEditItem1.EditHeight = 12;
            this.progressBarEditItem1.Id = 51;
            this.progressBarEditItem1.Name = "progressBarEditItem1";
            this.progressBarEditItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            this.progressBarEditItem1.Width = 150;
            // 
            // repositoryItemProgressBar1
            // 
            this.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1";
            // 
            // printPreviewBarItem49
            // 
            this.printPreviewBarItem49.Caption = "Stop";
            this.printPreviewBarItem49.Command = DevExpress.XtraPrinting.PrintingSystemCommand.StopPageBuilding;
            this.printPreviewBarItem49.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewBarItem49.Enabled = false;
            this.printPreviewBarItem49.Hint = "Stop";
            this.printPreviewBarItem49.Id = 52;
            this.printPreviewBarItem49.Name = "printPreviewBarItem49";
            this.printPreviewBarItem49.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.barButtonItem1.Enabled = false;
            this.barButtonItem1.Id = 53;
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInRuntime;
            // 
            // printPreviewStaticItem2
            // 
            this.printPreviewStaticItem2.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.printPreviewStaticItem2.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None;
            this.printPreviewStaticItem2.Caption = "100%";
            this.printPreviewStaticItem2.Id = 54;
            this.printPreviewStaticItem2.Name = "printPreviewStaticItem2";
            this.printPreviewStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            this.printPreviewStaticItem2.Type = "ZoomFactorText";
            // 
            // zoomTrackBarEditItem1
            // 
            this.zoomTrackBarEditItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.zoomTrackBarEditItem1.ContextSpecifier = this.documentViewerRibbonController1;
            this.zoomTrackBarEditItem1.Edit = this.repositoryItemZoomTrackBar1;
            this.zoomTrackBarEditItem1.EditValue = 90;
            this.zoomTrackBarEditItem1.Enabled = false;
            this.zoomTrackBarEditItem1.Id = 55;
            this.zoomTrackBarEditItem1.Name = "zoomTrackBarEditItem1";
            this.zoomTrackBarEditItem1.Range = new int[] {
        10,
        500};
            this.zoomTrackBarEditItem1.Width = 140;
            // 
            // repositoryItemZoomTrackBar1
            // 
            this.repositoryItemZoomTrackBar1.Alignment = DevExpress.Utils.VertAlignment.Center;
            this.repositoryItemZoomTrackBar1.AllowFocused = false;
            this.repositoryItemZoomTrackBar1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.repositoryItemZoomTrackBar1.Maximum = 180;
            this.repositoryItemZoomTrackBar1.Middle = 5;
            this.repositoryItemZoomTrackBar1.Name = "repositoryItemZoomTrackBar1";
            this.repositoryItemZoomTrackBar1.ScrollThumbStyle = DevExpress.XtraEditors.Repository.ScrollThumbStyle.ArrowDownRight;
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.ContextSpecifier = this.documentViewerRibbonController1;
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.printPreviewRibbonPageGroup1,
            this.printPreviewRibbonPageGroup2,
            this.printPreviewRibbonPageGroup3,
            this.printPreviewRibbonPageGroup4,
            this.printPreviewRibbonPageGroup5,
            this.printPreviewRibbonPageGroup6,
            this.printPreviewRibbonPageGroup7,
            this.printPreviewRibbonPageGroup8});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Print Preview";
            // 
            // printPreviewRibbonPageGroup1
            // 
            this.printPreviewRibbonPageGroup1.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup1.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup1.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Document;
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem47);
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem48);
            this.printPreviewRibbonPageGroup1.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Document;
            this.printPreviewRibbonPageGroup1.Name = "printPreviewRibbonPageGroup1";
            this.printPreviewRibbonPageGroup1.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup1.Text = "Document";
            // 
            // printPreviewRibbonPageGroup2
            // 
            this.printPreviewRibbonPageGroup2.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup2.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup2.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PrintDirect;
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem6);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem7);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem5);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem2);
            this.printPreviewRibbonPageGroup2.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Print;
            this.printPreviewRibbonPageGroup2.Name = "printPreviewRibbonPageGroup2";
            this.printPreviewRibbonPageGroup2.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup2.Text = "Print";
            // 
            // printPreviewRibbonPageGroup3
            // 
            this.printPreviewRibbonPageGroup3.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup3.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup3.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_PageMargins;
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem9);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem10);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem29);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem27);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem28);
            this.printPreviewRibbonPageGroup3.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.PageSetup;
            this.printPreviewRibbonPageGroup3.Name = "printPreviewRibbonPageGroup3";
            superToolTip98.FixedTooltipWidth = true;
            toolTipTitleItem98.Text = "Page Setup";
            toolTipItem98.LeftIndent = 6;
            toolTipItem98.Text = "Show the Page Setup dialog.";
            superToolTip98.Items.Add(toolTipTitleItem98);
            superToolTip98.Items.Add(toolTipItem98);
            superToolTip98.MaxWidth = 210;
            this.printPreviewRibbonPageGroup3.SuperTip = superToolTip98;
            this.printPreviewRibbonPageGroup3.Text = "Page Setup";
            // 
            // printPreviewRibbonPageGroup4
            // 
            this.printPreviewRibbonPageGroup4.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup4.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup4.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Find;
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem3);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem4);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem1);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem17, true);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem18);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem19);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem20);
            this.printPreviewRibbonPageGroup4.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Navigation;
            this.printPreviewRibbonPageGroup4.Name = "printPreviewRibbonPageGroup4";
            this.printPreviewRibbonPageGroup4.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup4.Text = "Navigation";
            // 
            // printPreviewRibbonPageGroup5
            // 
            this.printPreviewRibbonPageGroup5.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup5.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup5.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Zoom;
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem11);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem12);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem13);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem21);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem14);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem16);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem15);
            this.printPreviewRibbonPageGroup5.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Zoom;
            this.printPreviewRibbonPageGroup5.Name = "printPreviewRibbonPageGroup5";
            this.printPreviewRibbonPageGroup5.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup5.Text = "Zoom";
            // 
            // printPreviewRibbonPageGroup6
            // 
            this.printPreviewRibbonPageGroup6.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup6.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup6.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_Watermark;
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem22);
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem23);
            this.printPreviewRibbonPageGroup6.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Background;
            this.printPreviewRibbonPageGroup6.Name = "printPreviewRibbonPageGroup6";
            this.printPreviewRibbonPageGroup6.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup6.Text = "Page Background";
            // 
            // printPreviewRibbonPageGroup7
            // 
            this.printPreviewRibbonPageGroup7.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup7.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup7.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ExportFile;
            this.printPreviewRibbonPageGroup7.ItemLinks.Add(this.printPreviewBarItem24);
            this.printPreviewRibbonPageGroup7.ItemLinks.Add(this.printPreviewBarItem25);
            this.printPreviewRibbonPageGroup7.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Export;
            this.printPreviewRibbonPageGroup7.Name = "printPreviewRibbonPageGroup7";
            this.printPreviewRibbonPageGroup7.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup7.Text = "Export";
            // 
            // printPreviewRibbonPageGroup8
            // 
            this.printPreviewRibbonPageGroup8.AllowTextClipping = false;
            this.printPreviewRibbonPageGroup8.ContextSpecifier = this.documentViewerRibbonController1;
            this.printPreviewRibbonPageGroup8.Glyph = global::QuanLy_DoAn.PrintRibbonControllerResources.RibbonPrintPreview_ClosePreview;
            this.printPreviewRibbonPageGroup8.ItemLinks.Add(this.printPreviewBarItem26);
            this.printPreviewRibbonPageGroup8.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Close;
            this.printPreviewRibbonPageGroup8.Name = "printPreviewRibbonPageGroup8";
            this.printPreviewRibbonPageGroup8.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup8.Text = "Close";
            // 
            // ribbonStatusBar1
            // 
            this.ribbonStatusBar1.ItemLinks.Add(this.printPreviewStaticItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.barStaticItem1, true);
            this.ribbonStatusBar1.ItemLinks.Add(this.progressBarEditItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.printPreviewBarItem49);
            this.ribbonStatusBar1.ItemLinks.Add(this.barButtonItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.printPreviewStaticItem2);
            this.ribbonStatusBar1.ItemLinks.Add(this.zoomTrackBarEditItem1);
            this.ribbonStatusBar1.ItemLinks.Add(this.barEditItem1);
            this.ribbonStatusBar1.Location = new System.Drawing.Point(0, 732);
            this.ribbonStatusBar1.Name = "ribbonStatusBar1";
            this.ribbonStatusBar1.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar1.Size = new System.Drawing.Size(1175, 29);
            this.ribbonStatusBar1.Click += new System.EventHandler(this.ribbonStatusBar1_Click);
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "barEditItem1";
            this.barEditItem1.Edit = this.repositoryItemTextEdit1;
            this.barEditItem1.Id = 56;
            this.barEditItem1.Name = "barEditItem1";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // txtmahd
            // 
            this.txtmahd.Location = new System.Drawing.Point(77, 738);
            this.txtmahd.Name = "txtmahd";
            this.txtmahd.Size = new System.Drawing.Size(155, 23);
            this.txtmahd.TabIndex = 3;
            // 
            // InHopDongForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1175, 761);
            this.Controls.Add(this.txtmahd);
            this.Controls.Add(this.documentViewer1);
            this.Controls.Add(this.ribbonStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "InHopDongForm";
            this.Text = "InHopDongForm";
            this.Load += new System.EventHandler(this.InHopDongForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.documentViewerRibbonController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemZoomTrackBar1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraPrinting.Preview.DocumentViewer documentViewer1;
        private DevExpress.XtraPrinting.Preview.DocumentViewerRibbonController documentViewerRibbonController1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem2;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem3;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem4;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem5;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem6;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem7;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem8;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem9;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem10;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem11;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem12;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem13;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem14;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem15;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem16;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem17;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem18;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem19;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem20;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem21;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem22;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem23;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem24;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem25;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem26;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem27;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem28;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem29;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem30;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem31;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem32;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem33;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem34;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem35;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem36;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem37;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem38;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem39;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem40;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem41;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem42;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem43;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem44;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem45;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem46;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem47;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem48;
        private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraPrinting.Preview.ProgressBarEditItem progressBarEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemProgressBar1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem49;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem2;
        private DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem zoomTrackBarEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar repositoryItemZoomTrackBar1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage ribbonPage1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup1;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup2;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup3;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup4;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup5;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup6;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup7;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar1;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        public System.Windows.Forms.TextBox txtmahd;

    }
}