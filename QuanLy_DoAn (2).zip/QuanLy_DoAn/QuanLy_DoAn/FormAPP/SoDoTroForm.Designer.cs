﻿namespace QuanLy_DoAn.FormAPP
{
    partial class SoDoTroForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SoDoTroForm));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.btnsua = new DevExpress.XtraEditors.SimpleButton();
            this.btnxoa = new DevExpress.XtraEditors.SimpleButton();
            this.btnThem = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl5 = new DevExpress.XtraEditors.PanelControl();
            this.probarcooldow = new System.Windows.Forms.ProgressBar();
            this.btndatphong = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.comboGiaPhong = new System.Windows.Forms.ComboBox();
            this.combotinhtrang = new System.Windows.Forms.ComboBox();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.combokhuphong = new System.Windows.Forms.ComboBox();
            this.txtmanoiquy = new DevExpress.XtraEditors.TextEdit();
            this.txtghichu = new DevExpress.XtraEditors.TextEdit();
            this.txtoaiphong = new DevExpress.XtraEditors.TextEdit();
            this.txttenphong = new DevExpress.XtraEditors.TextEdit();
            this.txtmaphong = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.panelLoadSodo = new System.Windows.Forms.FlowLayoutPanel();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.comboGia = new System.Windows.Forms.ComboBox();
            this.comboTR = new System.Windows.Forms.ComboBox();
            this.comboLoaiPhong = new System.Windows.Forms.ComboBox();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.btnkhuvuc4 = new DevExpress.XtraEditors.SimpleButton();
            this.btnkhuvuc3 = new DevExpress.XtraEditors.SimpleButton();
            this.btnkhuvuc2 = new DevExpress.XtraEditors.SimpleButton();
            this.btnkhuvuc1 = new DevExpress.XtraEditors.SimpleButton();
            this.timercooldown = new System.Windows.Forms.Timer(this.components);
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.comboNoiQuy = new System.Windows.Forms.ComboBox();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtnoidung = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).BeginInit();
            this.panelControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmanoiquy.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtghichu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtoaiphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.panelControl4);
            this.panelControl1.Controls.Add(this.panelControl3);
            this.panelControl1.Controls.Add(this.panelLoadSodo);
            this.panelControl1.Controls.Add(this.panelControl2);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1336, 580);
            this.panelControl1.TabIndex = 0;
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.btnsua);
            this.panelControl4.Controls.Add(this.btnxoa);
            this.panelControl4.Controls.Add(this.btnThem);
            this.panelControl4.Controls.Add(this.panelControl5);
            this.panelControl4.Location = new System.Drawing.Point(666, 236);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(665, 344);
            this.panelControl4.TabIndex = 3;
            // 
            // btnsua
            // 
            this.btnsua.Location = new System.Drawing.Point(561, 120);
            this.btnsua.Name = "btnsua";
            this.btnsua.Size = new System.Drawing.Size(97, 54);
            this.btnsua.TabIndex = 5;
            this.btnsua.Text = "Sửa";
            this.btnsua.Click += new System.EventHandler(this.btnsua_Click);
            // 
            // btnxoa
            // 
            this.btnxoa.Location = new System.Drawing.Point(563, 219);
            this.btnxoa.Name = "btnxoa";
            this.btnxoa.Size = new System.Drawing.Size(97, 54);
            this.btnxoa.TabIndex = 4;
            this.btnxoa.Text = "Xóa";
            this.btnxoa.Click += new System.EventHandler(this.btnxoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(561, 22);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(97, 54);
            this.btnThem.TabIndex = 3;
            this.btnThem.Text = "Thêm";
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // panelControl5
            // 
            this.panelControl5.Controls.Add(this.probarcooldow);
            this.panelControl5.Controls.Add(this.btndatphong);
            this.panelControl5.Controls.Add(this.labelControl12);
            this.panelControl5.Controls.Add(this.comboGiaPhong);
            this.panelControl5.Controls.Add(this.combotinhtrang);
            this.panelControl5.Controls.Add(this.labelControl11);
            this.panelControl5.Controls.Add(this.combokhuphong);
            this.panelControl5.Controls.Add(this.txtmanoiquy);
            this.panelControl5.Controls.Add(this.txtghichu);
            this.panelControl5.Controls.Add(this.txtoaiphong);
            this.panelControl5.Controls.Add(this.txttenphong);
            this.panelControl5.Controls.Add(this.txtmaphong);
            this.panelControl5.Controls.Add(this.labelControl10);
            this.panelControl5.Controls.Add(this.labelControl9);
            this.panelControl5.Controls.Add(this.labelControl8);
            this.panelControl5.Controls.Add(this.labelControl7);
            this.panelControl5.Controls.Add(this.labelControl6);
            this.panelControl5.Controls.Add(this.labelControl5);
            this.panelControl5.Controls.Add(this.labelControl4);
            this.panelControl5.Location = new System.Drawing.Point(0, 0);
            this.panelControl5.Name = "panelControl5";
            this.panelControl5.Size = new System.Drawing.Size(544, 344);
            this.panelControl5.TabIndex = 2;
            // 
            // probarcooldow
            // 
            this.probarcooldow.Location = new System.Drawing.Point(355, 203);
            this.probarcooldow.Name = "probarcooldow";
            this.probarcooldow.Size = new System.Drawing.Size(163, 23);
            this.probarcooldow.TabIndex = 19;
            // 
            // btndatphong
            // 
            this.btndatphong.Location = new System.Drawing.Point(403, 235);
            this.btndatphong.Name = "btndatphong";
            this.btndatphong.Size = new System.Drawing.Size(97, 54);
            this.btndatphong.TabIndex = 6;
            this.btndatphong.Text = "Đặt Phòng ";
            this.btndatphong.Click += new System.EventHandler(this.btndatphong_Click);
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(7, 191);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(66, 16);
            this.labelControl12.TabIndex = 18;
            this.labelControl12.Text = "Giá Phòng :";
            // 
            // comboGiaPhong
            // 
            this.comboGiaPhong.FormattingEnabled = true;
            this.comboGiaPhong.Location = new System.Drawing.Point(89, 188);
            this.comboGiaPhong.Name = "comboGiaPhong";
            this.comboGiaPhong.Size = new System.Drawing.Size(176, 24);
            this.comboGiaPhong.TabIndex = 17;
            // 
            // combotinhtrang
            // 
            this.combotinhtrang.FormattingEnabled = true;
            this.combotinhtrang.Location = new System.Drawing.Point(355, 150);
            this.combotinhtrang.Name = "combotinhtrang";
            this.combotinhtrang.Size = new System.Drawing.Size(178, 24);
            this.combotinhtrang.TabIndex = 16;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(272, 153);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(71, 17);
            this.labelControl11.TabIndex = 15;
            this.labelControl11.Text = "Tình Trạng:";
            // 
            // combokhuphong
            // 
            this.combokhuphong.FormattingEnabled = true;
            this.combokhuphong.Location = new System.Drawing.Point(88, 235);
            this.combokhuphong.Name = "combokhuphong";
            this.combokhuphong.Size = new System.Drawing.Size(175, 24);
            this.combokhuphong.TabIndex = 14;
            // 
            // txtmanoiquy
            // 
            this.txtmanoiquy.Location = new System.Drawing.Point(355, 103);
            this.txtmanoiquy.Name = "txtmanoiquy";
            this.txtmanoiquy.Size = new System.Drawing.Size(178, 22);
            this.txtmanoiquy.TabIndex = 13;
            // 
            // txtghichu
            // 
            this.txtghichu.Location = new System.Drawing.Point(355, 54);
            this.txtghichu.Name = "txtghichu";
            this.txtghichu.Size = new System.Drawing.Size(178, 22);
            this.txtghichu.TabIndex = 12;
            // 
            // txtoaiphong
            // 
            this.txtoaiphong.Location = new System.Drawing.Point(87, 147);
            this.txtoaiphong.Name = "txtoaiphong";
            this.txtoaiphong.Size = new System.Drawing.Size(178, 22);
            this.txtoaiphong.TabIndex = 10;
            // 
            // txttenphong
            // 
            this.txttenphong.Location = new System.Drawing.Point(88, 94);
            this.txttenphong.Name = "txttenphong";
            this.txttenphong.Size = new System.Drawing.Size(178, 22);
            this.txttenphong.TabIndex = 9;
            // 
            // txtmaphong
            // 
            this.txtmaphong.Location = new System.Drawing.Point(88, 51);
            this.txtmaphong.Name = "txtmaphong";
            this.txtmaphong.Size = new System.Drawing.Size(178, 22);
            this.txtmaphong.TabIndex = 8;
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(272, 106);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(79, 17);
            this.labelControl10.TabIndex = 7;
            this.labelControl10.Text = "Mã Nội Quy :";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(287, 57);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(53, 16);
            this.labelControl9.TabIndex = 6;
            this.labelControl9.Text = "Ghi Chú :";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(7, 238);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(69, 16);
            this.labelControl8.TabIndex = 5;
            this.labelControl8.Text = "Khu Phòng :";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(4, 147);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(77, 17);
            this.labelControl7.TabIndex = 4;
            this.labelControl7.Text = "Loại Phòng :";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(6, 97);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(70, 16);
            this.labelControl6.TabIndex = 3;
            this.labelControl6.Text = "Tên Phòng :";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(6, 51);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(65, 16);
            this.labelControl5.TabIndex = 2;
            this.labelControl5.Text = "Mã Phòng :";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(166, 20);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(192, 21);
            this.labelControl4.TabIndex = 1;
            this.labelControl4.Text = "THÔNG TIN VỀ PHÒNG";
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.groupControl3);
            this.panelControl3.Location = new System.Drawing.Point(666, 6);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(665, 224);
            this.panelControl3.TabIndex = 2;
            // 
            // panelLoadSodo
            // 
            this.panelLoadSodo.Location = new System.Drawing.Point(0, 236);
            this.panelLoadSodo.Name = "panelLoadSodo";
            this.panelLoadSodo.Size = new System.Drawing.Size(664, 344);
            this.panelLoadSodo.TabIndex = 1;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.groupControl2);
            this.panelControl2.Controls.Add(this.groupControl1);
            this.panelControl2.Location = new System.Drawing.Point(0, 6);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(664, 223);
            this.panelControl2.TabIndex = 0;
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.labelControl3);
            this.groupControl2.Controls.Add(this.labelControl2);
            this.groupControl2.Controls.Add(this.labelControl1);
            this.groupControl2.Controls.Add(this.comboGia);
            this.groupControl2.Controls.Add(this.comboTR);
            this.groupControl2.Controls.Add(this.comboLoaiPhong);
            this.groupControl2.Location = new System.Drawing.Point(374, 7);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(285, 216);
            this.groupControl2.TabIndex = 1;
            this.groupControl2.Text = "Thông tin theo yêu cầu";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(6, 104);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(66, 16);
            this.labelControl3.TabIndex = 5;
            this.labelControl3.Text = "Giá Phòng :";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(6, 155);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(75, 17);
            this.labelControl2.TabIndex = 4;
            this.labelControl2.Text = "Tình Trạng :";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(6, 42);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(77, 17);
            this.labelControl1.TabIndex = 3;
            this.labelControl1.Text = "Loại Phòng :";
            // 
            // comboGia
            // 
            this.comboGia.FormattingEnabled = true;
            this.comboGia.Location = new System.Drawing.Point(100, 101);
            this.comboGia.Name = "comboGia";
            this.comboGia.Size = new System.Drawing.Size(164, 24);
            this.comboGia.TabIndex = 2;
            this.comboGia.SelectedIndexChanged += new System.EventHandler(this.comboGia_SelectedIndexChanged);
            // 
            // comboTR
            // 
            this.comboTR.FormattingEnabled = true;
            this.comboTR.Location = new System.Drawing.Point(100, 152);
            this.comboTR.Name = "comboTR";
            this.comboTR.Size = new System.Drawing.Size(164, 24);
            this.comboTR.TabIndex = 1;
            this.comboTR.SelectedIndexChanged += new System.EventHandler(this.comboTR_SelectedIndexChanged);
            // 
            // comboLoaiPhong
            // 
            this.comboLoaiPhong.FormattingEnabled = true;
            this.comboLoaiPhong.Location = new System.Drawing.Point(100, 39);
            this.comboLoaiPhong.Name = "comboLoaiPhong";
            this.comboLoaiPhong.Size = new System.Drawing.Size(164, 24);
            this.comboLoaiPhong.TabIndex = 0;
            this.comboLoaiPhong.SelectedIndexChanged += new System.EventHandler(this.comboLoaiPhong_SelectedIndexChanged);
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.btnkhuvuc4);
            this.groupControl1.Controls.Add(this.btnkhuvuc3);
            this.groupControl1.Controls.Add(this.btnkhuvuc2);
            this.groupControl1.Controls.Add(this.btnkhuvuc1);
            this.groupControl1.Location = new System.Drawing.Point(0, 7);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(334, 211);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Khu Vực";
            // 
            // btnkhuvuc4
            // 
            this.btnkhuvuc4.Image = ((System.Drawing.Image)(resources.GetObject("btnkhuvuc4.Image")));
            this.btnkhuvuc4.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.btnkhuvuc4.Location = new System.Drawing.Point(195, 134);
            this.btnkhuvuc4.Name = "btnkhuvuc4";
            this.btnkhuvuc4.Size = new System.Drawing.Size(107, 72);
            this.btnkhuvuc4.TabIndex = 3;
            this.btnkhuvuc4.Text = "Khu Vực 4";
            this.btnkhuvuc4.Click += new System.EventHandler(this.btnkhuvuc4_Click);
            // 
            // btnkhuvuc3
            // 
            this.btnkhuvuc3.Image = ((System.Drawing.Image)(resources.GetObject("btnkhuvuc3.Image")));
            this.btnkhuvuc3.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.btnkhuvuc3.Location = new System.Drawing.Point(13, 134);
            this.btnkhuvuc3.Name = "btnkhuvuc3";
            this.btnkhuvuc3.Size = new System.Drawing.Size(103, 72);
            this.btnkhuvuc3.TabIndex = 2;
            this.btnkhuvuc3.Text = "Khu Vực 3";
            this.btnkhuvuc3.Click += new System.EventHandler(this.btnkhuvuc3_Click);
            // 
            // btnkhuvuc2
            // 
            this.btnkhuvuc2.Image = ((System.Drawing.Image)(resources.GetObject("btnkhuvuc2.Image")));
            this.btnkhuvuc2.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.btnkhuvuc2.Location = new System.Drawing.Point(195, 30);
            this.btnkhuvuc2.Name = "btnkhuvuc2";
            this.btnkhuvuc2.Size = new System.Drawing.Size(107, 76);
            this.btnkhuvuc2.TabIndex = 1;
            this.btnkhuvuc2.Text = "Khu Vực 2";
            this.btnkhuvuc2.Click += new System.EventHandler(this.btnkhuvuc2_Click);
            // 
            // btnkhuvuc1
            // 
            this.btnkhuvuc1.Appearance.BackColor = System.Drawing.Color.White;
            this.btnkhuvuc1.Appearance.BorderColor = System.Drawing.Color.Snow;
            this.btnkhuvuc1.Appearance.ForeColor = System.Drawing.Color.Black;
            this.btnkhuvuc1.Appearance.Options.UseBackColor = true;
            this.btnkhuvuc1.Appearance.Options.UseBorderColor = true;
            this.btnkhuvuc1.Appearance.Options.UseForeColor = true;
            this.btnkhuvuc1.Image = ((System.Drawing.Image)(resources.GetObject("btnkhuvuc1.Image")));
            this.btnkhuvuc1.ImageLocation = DevExpress.XtraEditors.ImageLocation.TopCenter;
            this.btnkhuvuc1.Location = new System.Drawing.Point(13, 30);
            this.btnkhuvuc1.LookAndFeel.SkinMaskColor = System.Drawing.Color.FloralWhite;
            this.btnkhuvuc1.Name = "btnkhuvuc1";
            this.btnkhuvuc1.Size = new System.Drawing.Size(103, 76);
            this.btnkhuvuc1.TabIndex = 0;
            this.btnkhuvuc1.Text = "Khu Vực 1";
            this.btnkhuvuc1.Click += new System.EventHandler(this.btnkhuvuc1_Click);
            // 
            // timercooldown
            // 
            this.timercooldown.Tick += new System.EventHandler(this.timercooldown_Tick);
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.txtnoidung);
            this.groupControl3.Controls.Add(this.labelControl14);
            this.groupControl3.Controls.Add(this.labelControl13);
            this.groupControl3.Controls.Add(this.comboNoiQuy);
            this.groupControl3.Location = new System.Drawing.Point(0, 0);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(665, 223);
            this.groupControl3.TabIndex = 0;
            this.groupControl3.Text = "Nội Quy Khu Trọ";
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(19, 49);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(85, 17);
            this.labelControl13.TabIndex = 7;
            this.labelControl13.Text = "Tên Nội Quy :";
            // 
            // comboNoiQuy
            // 
            this.comboNoiQuy.FormattingEnabled = true;
            this.comboNoiQuy.Location = new System.Drawing.Point(113, 46);
            this.comboNoiQuy.Name = "comboNoiQuy";
            this.comboNoiQuy.Size = new System.Drawing.Size(164, 24);
            this.comboNoiQuy.TabIndex = 6;
            this.comboNoiQuy.SelectedIndexChanged += new System.EventHandler(this.comboNoiQuy_SelectedIndexChanged);
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(38, 79);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(66, 17);
            this.labelControl14.TabIndex = 20;
            this.labelControl14.Text = "Nội Dung :";
            // 
            // txtnoidung
            // 
            this.txtnoidung.Location = new System.Drawing.Point(113, 76);
            this.txtnoidung.Multiline = true;
            this.txtnoidung.Name = "txtnoidung";
            this.txtnoidung.Size = new System.Drawing.Size(545, 137);
            this.txtnoidung.TabIndex = 21;
            // 
            // SoDoTroForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1336, 580);
            this.Controls.Add(this.panelControl1);
            this.Name = "SoDoTroForm";
            this.Text = "SoDoTroForm";
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).EndInit();
            this.panelControl5.ResumeLayout(false);
            this.panelControl5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmanoiquy.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtghichu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtoaiphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            this.groupControl3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnkhuvuc4;
        private DevExpress.XtraEditors.SimpleButton btnkhuvuc3;
        private DevExpress.XtraEditors.SimpleButton btnkhuvuc2;
        private DevExpress.XtraEditors.SimpleButton btnkhuvuc1;
        private System.Windows.Forms.FlowLayoutPanel panelLoadSodo;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.ComboBox comboGia;
        private System.Windows.Forms.ComboBox comboTR;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.SimpleButton btndatphong;
        private DevExpress.XtraEditors.SimpleButton btnsua;
        private DevExpress.XtraEditors.SimpleButton btnxoa;
        private DevExpress.XtraEditors.SimpleButton btnThem;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private System.Windows.Forms.ProgressBar probarcooldow;
        private System.Windows.Forms.Timer timercooldown;
        public DevExpress.XtraEditors.TextEdit txtmanoiquy;
        public DevExpress.XtraEditors.TextEdit txtghichu;
        public DevExpress.XtraEditors.TextEdit txtoaiphong;
        public DevExpress.XtraEditors.TextEdit txttenphong;
        public DevExpress.XtraEditors.TextEdit txtmaphong;
        public System.Windows.Forms.ComboBox combotinhtrang;
        public System.Windows.Forms.ComboBox comboGiaPhong;
        public System.Windows.Forms.ComboBox comboLoaiPhong;
        public System.Windows.Forms.ComboBox combokhuphong;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private System.Windows.Forms.ComboBox comboNoiQuy;
        private System.Windows.Forms.TextBox txtnoidung;
    }
}