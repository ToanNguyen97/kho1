﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class InHopDongForm : DevExpress.XtraEditors.XtraForm
    {
        public InHopDongForm()
        {
            InitializeComponent();
        }

        private void InHopDongForm_Load(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds = DataProvider.Instance.ExcuteQuerySet("HopDongIn @MaHopDong ", new object[] { txtmahd.Text });
            XtraReport1 rp = new XtraReport1();
            rp.DataSource = ds;
            rp.BindData();
            documentViewer1.PrintingSystem = rp.PrintingSystem;
            rp.CreateDocument();
          
        }

        private void ribbonStatusBar1_Click(object sender, EventArgs e)
        {

        }
    }
}