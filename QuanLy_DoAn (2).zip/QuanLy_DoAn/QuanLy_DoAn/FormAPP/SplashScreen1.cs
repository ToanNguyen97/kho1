﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraSplashScreen;

namespace QuanLy_DoAn.FormAPP
{
    public partial class SplashScreen1 : SplashScreen
    {
        public SplashScreen1()
        {
            InitializeComponent();
        }

        #region Overrides

        public override void ProcessCommand(Enum cmd, object arg)
        {
            base.ProcessCommand(cmd, arg);
        }

        #endregion

        public enum SplashScreenCommand
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.labelControl1.Text = "Starting " + marqueeProgressBarControl1.EditValue.ToString();
            marqueeProgressBarControl1.PerformLayout();
        }

        private void pictureEdit2_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void SplashScreen1_Load(object sender, EventArgs e)
        {
           
            marqueeProgressBarControl1.PerformLayout();
        }
    }
}