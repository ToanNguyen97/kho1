﻿namespace QuanLy_DoAn.FormAPP
{
    partial class HopDongThuePhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl7 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.txtmaHD = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.comboNV = new System.Windows.Forms.ComboBox();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.datengay = new DevExpress.XtraEditors.DateEdit();
            this.labelnv = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton4 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.GridHD = new System.Windows.Forms.DataGridView();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl6 = new DevExpress.XtraEditors.PanelControl();
            this.btnthem = new System.Windows.Forms.Button();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.Rnu = new System.Windows.Forms.RadioButton();
            this.RNam = new System.Windows.Forms.RadioButton();
            this.combomaLKhach = new System.Windows.Forms.ComboBox();
            this.txtmakhachThue = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtdiachi = new DevExpress.XtraEditors.TextEdit();
            this.txttennguoithan = new DevExpress.XtraEditors.TextEdit();
            this.lb1 = new DevExpress.XtraEditors.LabelControl();
            this.lb = new DevExpress.XtraEditors.LabelControl();
            this.txtsdt = new DevExpress.XtraEditors.TextEdit();
            this.lnsdt = new DevExpress.XtraEditors.LabelControl();
            this.lbnamsinh = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtnamsinh = new DevExpress.XtraEditors.TextEdit();
            this.txtcmnd = new DevExpress.XtraEditors.TextEdit();
            this.txttenkhach = new DevExpress.XtraEditors.TextEdit();
            this.lbcmnd = new DevExpress.XtraEditors.LabelControl();
            this.txthokhach = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.panelControl5 = new DevExpress.XtraEditors.PanelControl();
            this.comboGiaPhong = new DevExpress.XtraEditors.TextEdit();
            this.combokhuphong = new DevExpress.XtraEditors.TextEdit();
            this.combotinhtrang = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.txtmanoiquy = new DevExpress.XtraEditors.TextEdit();
            this.txtghichu = new DevExpress.XtraEditors.TextEdit();
            this.txtoaiphong = new DevExpress.XtraEditors.TextEdit();
            this.txttenphong = new DevExpress.XtraEditors.TextEdit();
            this.txtmaphong = new DevExpress.XtraEditors.TextEdit();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).BeginInit();
            this.panelControl7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaHD.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datengay.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datengay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).BeginInit();
            this.panelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridHD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).BeginInit();
            this.panelControl6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmakhachThue.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdiachi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttennguoithan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsdt.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamsinh.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenkhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthokhach.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).BeginInit();
            this.panelControl5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboGiaPhong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.combokhuphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.combotinhtrang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmanoiquy.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtghichu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtoaiphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenphong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphong.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.panelControl7);
            this.panelControl1.Controls.Add(this.panelControl4);
            this.panelControl1.Controls.Add(this.panelControl3);
            this.panelControl1.Controls.Add(this.panelControl2);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1351, 661);
            this.panelControl1.TabIndex = 0;
            // 
            // panelControl7
            // 
            this.panelControl7.Controls.Add(this.groupControl3);
            this.panelControl7.Controls.Add(this.simpleButton4);
            this.panelControl7.Controls.Add(this.simpleButton3);
            this.panelControl7.Controls.Add(this.simpleButton2);
            this.panelControl7.Controls.Add(this.simpleButton1);
            this.panelControl7.Location = new System.Drawing.Point(1022, 6);
            this.panelControl7.Name = "panelControl7";
            this.panelControl7.Size = new System.Drawing.Size(329, 440);
            this.panelControl7.TabIndex = 3;
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.txtmaHD);
            this.groupControl3.Controls.Add(this.labelControl16);
            this.groupControl3.Controls.Add(this.comboNV);
            this.groupControl3.Controls.Add(this.labelControl15);
            this.groupControl3.Controls.Add(this.datengay);
            this.groupControl3.Controls.Add(this.labelnv);
            this.groupControl3.Location = new System.Drawing.Point(5, 7);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(319, 213);
            this.groupControl3.TabIndex = 4;
            this.groupControl3.Text = "Thông tin cần thiết :";
            // 
            // txtmaHD
            // 
            this.txtmaHD.Location = new System.Drawing.Point(128, 166);
            this.txtmaHD.Name = "txtmaHD";
            this.txtmaHD.Size = new System.Drawing.Size(133, 22);
            this.txtmaHD.TabIndex = 43;
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(15, 171);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(93, 17);
            this.labelControl16.TabIndex = 42;
            this.labelControl16.Text = "Mã Hợp Đồng :";
            // 
            // comboNV
            // 
            this.comboNV.FormattingEnabled = true;
            this.comboNV.Location = new System.Drawing.Point(128, 55);
            this.comboNV.Name = "comboNV";
            this.comboNV.Size = new System.Drawing.Size(133, 24);
            this.comboNV.TabIndex = 41;
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(15, 115);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(67, 17);
            this.labelControl15.TabIndex = 40;
            this.labelControl15.Text = "Ngày Lập :";
            // 
            // datengay
            // 
            this.datengay.EditValue = null;
            this.datengay.Location = new System.Drawing.Point(128, 112);
            this.datengay.Name = "datengay";
            this.datengay.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datengay.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.datengay.Size = new System.Drawing.Size(133, 25);
            this.datengay.TabIndex = 39;
            // 
            // labelnv
            // 
            this.labelnv.Location = new System.Drawing.Point(15, 55);
            this.labelnv.Name = "labelnv";
            this.labelnv.Size = new System.Drawing.Size(98, 17);
            this.labelnv.TabIndex = 0;
            this.labelnv.Text = "Tên Người Lập :";
            // 
            // simpleButton4
            // 
            this.simpleButton4.Location = new System.Drawing.Point(5, 362);
            this.simpleButton4.Name = "simpleButton4";
            this.simpleButton4.Size = new System.Drawing.Size(137, 61);
            this.simpleButton4.TabIndex = 3;
            this.simpleButton4.Text = "Xem Chi Tiết";
            this.simpleButton4.Click += new System.EventHandler(this.simpleButton4_Click);
            // 
            // simpleButton3
            // 
            this.simpleButton3.Location = new System.Drawing.Point(187, 357);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(137, 61);
            this.simpleButton3.TabIndex = 2;
            this.simpleButton3.Text = "In Hợp Đồng";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Location = new System.Drawing.Point(5, 230);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(137, 61);
            this.simpleButton2.TabIndex = 1;
            this.simpleButton2.Text = "Lập Hợp Đồng ";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(180, 227);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(137, 61);
            this.simpleButton1.TabIndex = 0;
            this.simpleButton1.Text = "Sửa Hợp Đồng :";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // panelControl4
            // 
            this.panelControl4.Controls.Add(this.GridHD);
            this.panelControl4.Location = new System.Drawing.Point(0, 452);
            this.panelControl4.Name = "panelControl4";
            this.panelControl4.Size = new System.Drawing.Size(1346, 209);
            this.panelControl4.TabIndex = 2;
            // 
            // GridHD
            // 
            this.GridHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridHD.Location = new System.Drawing.Point(2, 2);
            this.GridHD.Name = "GridHD";
            this.GridHD.RowTemplate.Height = 24;
            this.GridHD.Size = new System.Drawing.Size(1342, 205);
            this.GridHD.TabIndex = 0;
            this.GridHD.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridHD_CellClick);
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.panelControl6);
            this.panelControl3.Location = new System.Drawing.Point(0, 232);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(1015, 214);
            this.panelControl3.TabIndex = 1;
            // 
            // panelControl6
            // 
            this.panelControl6.Controls.Add(this.btnthem);
            this.panelControl6.Controls.Add(this.groupControl2);
            this.panelControl6.Controls.Add(this.combomaLKhach);
            this.panelControl6.Controls.Add(this.txtmakhachThue);
            this.panelControl6.Controls.Add(this.labelControl14);
            this.panelControl6.Controls.Add(this.txtdiachi);
            this.panelControl6.Controls.Add(this.txttennguoithan);
            this.panelControl6.Controls.Add(this.lb1);
            this.panelControl6.Controls.Add(this.lb);
            this.panelControl6.Controls.Add(this.txtsdt);
            this.panelControl6.Controls.Add(this.lnsdt);
            this.panelControl6.Controls.Add(this.lbnamsinh);
            this.panelControl6.Controls.Add(this.labelControl13);
            this.panelControl6.Controls.Add(this.txtnamsinh);
            this.panelControl6.Controls.Add(this.txtcmnd);
            this.panelControl6.Controls.Add(this.txttenkhach);
            this.panelControl6.Controls.Add(this.lbcmnd);
            this.panelControl6.Controls.Add(this.txthokhach);
            this.panelControl6.Controls.Add(this.labelControl2);
            this.panelControl6.Controls.Add(this.labelControl3);
            this.panelControl6.Controls.Add(this.labelControl1);
            this.panelControl6.Location = new System.Drawing.Point(0, 0);
            this.panelControl6.Name = "panelControl6";
            this.panelControl6.Size = new System.Drawing.Size(1015, 213);
            this.panelControl6.TabIndex = 0;
            // 
            // btnthem
            // 
            this.btnthem.Location = new System.Drawing.Point(850, 150);
            this.btnthem.Name = "btnthem";
            this.btnthem.Size = new System.Drawing.Size(126, 47);
            this.btnthem.TabIndex = 47;
            this.btnthem.Text = "Thêm";
            this.btnthem.UseVisualStyleBackColor = true;
            this.btnthem.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.Rnu);
            this.groupControl2.Controls.Add(this.RNam);
            this.groupControl2.Location = new System.Drawing.Point(829, 42);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(170, 100);
            this.groupControl2.TabIndex = 46;
            this.groupControl2.Text = "Giới Tính";
            // 
            // Rnu
            // 
            this.Rnu.AutoSize = true;
            this.Rnu.Location = new System.Drawing.Point(100, 56);
            this.Rnu.Name = "Rnu";
            this.Rnu.Size = new System.Drawing.Size(47, 21);
            this.Rnu.TabIndex = 1;
            this.Rnu.Text = "Nữ";
            this.Rnu.UseVisualStyleBackColor = true;
            // 
            // RNam
            // 
            this.RNam.AutoSize = true;
            this.RNam.Checked = true;
            this.RNam.Location = new System.Drawing.Point(6, 56);
            this.RNam.Name = "RNam";
            this.RNam.Size = new System.Drawing.Size(57, 21);
            this.RNam.TabIndex = 0;
            this.RNam.TabStop = true;
            this.RNam.Text = "Nam";
            this.RNam.UseVisualStyleBackColor = true;
            // 
            // combomaLKhach
            // 
            this.combomaLKhach.FormattingEnabled = true;
            this.combomaLKhach.Location = new System.Drawing.Point(678, 173);
            this.combomaLKhach.Name = "combomaLKhach";
            this.combomaLKhach.Size = new System.Drawing.Size(133, 24);
            this.combomaLKhach.TabIndex = 45;
            // 
            // txtmakhachThue
            // 
            this.txtmakhachThue.Location = new System.Drawing.Point(115, 39);
            this.txtmakhachThue.Name = "txtmakhachThue";
            this.txtmakhachThue.Size = new System.Drawing.Size(133, 22);
            this.txtmakhachThue.TabIndex = 44;
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(544, 172);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(96, 17);
            this.labelControl14.TabIndex = 39;
            this.labelControl14.Text = "Mã Loại Khách :";
            // 
            // txtdiachi
            // 
            this.txtdiachi.Location = new System.Drawing.Point(678, 103);
            this.txtdiachi.Name = "txtdiachi";
            this.txtdiachi.Size = new System.Drawing.Size(133, 22);
            this.txtdiachi.TabIndex = 38;
            // 
            // txttennguoithan
            // 
            this.txttennguoithan.Location = new System.Drawing.Point(678, 42);
            this.txttennguoithan.Name = "txttennguoithan";
            this.txttennguoithan.Size = new System.Drawing.Size(133, 22);
            this.txttennguoithan.TabIndex = 37;
            // 
            // lb1
            // 
            this.lb1.Location = new System.Drawing.Point(544, 108);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(51, 17);
            this.lb1.TabIndex = 36;
            this.lb1.Text = "Địa Chỉ :";
            // 
            // lb
            // 
            this.lb.Location = new System.Drawing.Point(544, 47);
            this.lb.Name = "lb";
            this.lb.Size = new System.Drawing.Size(128, 17);
            this.lb.TabIndex = 35;
            this.lb.Text = "Họ Tên Người Thân :";
            // 
            // txtsdt
            // 
            this.txtsdt.Location = new System.Drawing.Point(393, 168);
            this.txtsdt.Name = "txtsdt";
            this.txtsdt.Size = new System.Drawing.Size(133, 22);
            this.txtsdt.TabIndex = 34;
            // 
            // lnsdt
            // 
            this.lnsdt.Location = new System.Drawing.Point(283, 173);
            this.lnsdt.Name = "lnsdt";
            this.lnsdt.Size = new System.Drawing.Size(93, 17);
            this.lnsdt.TabIndex = 33;
            this.lnsdt.Text = "Số Điện Thoại :";
            // 
            // lbnamsinh
            // 
            this.lbnamsinh.Location = new System.Drawing.Point(286, 106);
            this.lbnamsinh.Name = "lbnamsinh";
            this.lbnamsinh.Size = new System.Drawing.Size(64, 16);
            this.lbnamsinh.TabIndex = 32;
            this.lbnamsinh.Text = "Năm Sinh :";
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(6, 176);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(102, 16);
            this.labelControl13.TabIndex = 31;
            this.labelControl13.Text = "Tên Khách Thuê :";
            // 
            // txtnamsinh
            // 
            this.txtnamsinh.Location = new System.Drawing.Point(393, 103);
            this.txtnamsinh.Name = "txtnamsinh";
            this.txtnamsinh.Size = new System.Drawing.Size(133, 22);
            this.txtnamsinh.TabIndex = 30;
            // 
            // txtcmnd
            // 
            this.txtcmnd.Location = new System.Drawing.Point(393, 48);
            this.txtcmnd.Name = "txtcmnd";
            this.txtcmnd.Size = new System.Drawing.Size(133, 22);
            this.txtcmnd.TabIndex = 29;
            // 
            // txttenkhach
            // 
            this.txttenkhach.Location = new System.Drawing.Point(113, 170);
            this.txttenkhach.Name = "txttenkhach";
            this.txttenkhach.Size = new System.Drawing.Size(133, 22);
            this.txttenkhach.TabIndex = 28;
            // 
            // lbcmnd
            // 
            this.lbcmnd.Location = new System.Drawing.Point(283, 48);
            this.lbcmnd.Name = "lbcmnd";
            this.lbcmnd.Size = new System.Drawing.Size(67, 17);
            this.lbcmnd.TabIndex = 27;
            this.lbcmnd.Text = "Số CMND :";
            // 
            // txthokhach
            // 
            this.txthokhach.Location = new System.Drawing.Point(115, 103);
            this.txthokhach.Name = "txthokhach";
            this.txthokhach.Size = new System.Drawing.Size(133, 22);
            this.txthokhach.TabIndex = 26;
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(6, 106);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(103, 17);
            this.labelControl2.TabIndex = 24;
            this.labelControl2.Text = "Họ Khách Thuê :";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(6, 42);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(97, 16);
            this.labelControl3.TabIndex = 23;
            this.labelControl3.Text = "Mã Khách Thuê :";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(327, 20);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(241, 21);
            this.labelControl1.TabIndex = 22;
            this.labelControl1.Text = "THÔNG TIN VỀ KHÁCH THUÊ";
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.groupControl1);
            this.panelControl2.Location = new System.Drawing.Point(0, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(1015, 226);
            this.panelControl2.TabIndex = 0;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.panelControl5);
            this.groupControl1.Location = new System.Drawing.Point(0, 6);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(1015, 220);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Thông tin Phòng ";
            // 
            // panelControl5
            // 
            this.panelControl5.Controls.Add(this.comboGiaPhong);
            this.panelControl5.Controls.Add(this.combokhuphong);
            this.panelControl5.Controls.Add(this.combotinhtrang);
            this.panelControl5.Controls.Add(this.labelControl12);
            this.panelControl5.Controls.Add(this.labelControl11);
            this.panelControl5.Controls.Add(this.txtmanoiquy);
            this.panelControl5.Controls.Add(this.txtghichu);
            this.panelControl5.Controls.Add(this.txtoaiphong);
            this.panelControl5.Controls.Add(this.txttenphong);
            this.panelControl5.Controls.Add(this.txtmaphong);
            this.panelControl5.Controls.Add(this.labelControl10);
            this.panelControl5.Controls.Add(this.labelControl9);
            this.panelControl5.Controls.Add(this.labelControl8);
            this.panelControl5.Controls.Add(this.labelControl7);
            this.panelControl5.Controls.Add(this.labelControl6);
            this.panelControl5.Controls.Add(this.labelControl5);
            this.panelControl5.Controls.Add(this.labelControl4);
            this.panelControl5.Location = new System.Drawing.Point(0, 26);
            this.panelControl5.Name = "panelControl5";
            this.panelControl5.Size = new System.Drawing.Size(1015, 194);
            this.panelControl5.TabIndex = 3;
            // 
            // comboGiaPhong
            // 
            this.comboGiaPhong.Location = new System.Drawing.Point(746, 109);
            this.comboGiaPhong.Name = "comboGiaPhong";
            this.comboGiaPhong.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboGiaPhong.Properties.Appearance.Options.UseFont = true;
            this.comboGiaPhong.Properties.ReadOnly = true;
            this.comboGiaPhong.Size = new System.Drawing.Size(178, 22);
            this.comboGiaPhong.TabIndex = 21;
            // 
            // combokhuphong
            // 
            this.combokhuphong.Location = new System.Drawing.Point(746, 54);
            this.combokhuphong.Name = "combokhuphong";
            this.combokhuphong.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combokhuphong.Properties.Appearance.Options.UseFont = true;
            this.combokhuphong.Properties.ReadOnly = true;
            this.combokhuphong.Size = new System.Drawing.Size(178, 22);
            this.combokhuphong.TabIndex = 20;
            // 
            // combotinhtrang
            // 
            this.combotinhtrang.Location = new System.Drawing.Point(411, 147);
            this.combotinhtrang.Name = "combotinhtrang";
            this.combotinhtrang.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combotinhtrang.Properties.Appearance.Options.UseFont = true;
            this.combotinhtrang.Properties.ReadOnly = true;
            this.combotinhtrang.Size = new System.Drawing.Size(178, 22);
            this.combotinhtrang.TabIndex = 19;
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(656, 112);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(66, 16);
            this.labelControl12.TabIndex = 18;
            this.labelControl12.Text = "Giá Phòng :";
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(310, 150);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(71, 17);
            this.labelControl11.TabIndex = 15;
            this.labelControl11.Text = "Tình Trạng:";
            // 
            // txtmanoiquy
            // 
            this.txtmanoiquy.Location = new System.Drawing.Point(411, 103);
            this.txtmanoiquy.Name = "txtmanoiquy";
            this.txtmanoiquy.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmanoiquy.Properties.Appearance.Options.UseFont = true;
            this.txtmanoiquy.Properties.ReadOnly = true;
            this.txtmanoiquy.Size = new System.Drawing.Size(178, 22);
            this.txtmanoiquy.TabIndex = 13;
            // 
            // txtghichu
            // 
            this.txtghichu.Location = new System.Drawing.Point(411, 51);
            this.txtghichu.Name = "txtghichu";
            this.txtghichu.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtghichu.Properties.Appearance.Options.UseFont = true;
            this.txtghichu.Properties.ReadOnly = true;
            this.txtghichu.Size = new System.Drawing.Size(178, 22);
            this.txtghichu.TabIndex = 12;
            // 
            // txtoaiphong
            // 
            this.txtoaiphong.Location = new System.Drawing.Point(87, 147);
            this.txtoaiphong.Name = "txtoaiphong";
            this.txtoaiphong.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtoaiphong.Properties.Appearance.Options.UseFont = true;
            this.txtoaiphong.Properties.ReadOnly = true;
            this.txtoaiphong.Size = new System.Drawing.Size(178, 22);
            this.txtoaiphong.TabIndex = 10;
            // 
            // txttenphong
            // 
            this.txttenphong.Location = new System.Drawing.Point(88, 94);
            this.txttenphong.Name = "txttenphong";
            this.txttenphong.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttenphong.Properties.Appearance.Options.UseFont = true;
            this.txttenphong.Properties.ReadOnly = true;
            this.txttenphong.Size = new System.Drawing.Size(178, 22);
            this.txttenphong.TabIndex = 9;
            // 
            // txtmaphong
            // 
            this.txtmaphong.Location = new System.Drawing.Point(88, 51);
            this.txtmaphong.Name = "txtmaphong";
            this.txtmaphong.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmaphong.Properties.Appearance.Options.UseFont = true;
            this.txtmaphong.Properties.ReadOnly = true;
            this.txtmaphong.Size = new System.Drawing.Size(178, 22);
            this.txtmaphong.TabIndex = 8;
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(302, 106);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(79, 17);
            this.labelControl10.TabIndex = 7;
            this.labelControl10.Text = "Mã Nội Quy :";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(327, 57);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(53, 16);
            this.labelControl9.TabIndex = 6;
            this.labelControl9.Text = "Ghi Chú :";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(656, 57);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(69, 16);
            this.labelControl8.TabIndex = 5;
            this.labelControl8.Text = "Khu Phòng :";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(4, 147);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(77, 17);
            this.labelControl7.TabIndex = 4;
            this.labelControl7.Text = "Loại Phòng :";
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(6, 97);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(70, 16);
            this.labelControl6.TabIndex = 3;
            this.labelControl6.Text = "Tên Phòng :";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(6, 51);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(65, 16);
            this.labelControl5.TabIndex = 2;
            this.labelControl5.Text = "Mã Phòng :";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.BackColor = System.Drawing.Color.White;
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(327, 15);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(192, 21);
            this.labelControl4.TabIndex = 1;
            this.labelControl4.Text = "THÔNG TIN VỀ PHÒNG";
            // 
            // HopDongThuePhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1351, 661);
            this.Controls.Add(this.panelControl1);
            this.Name = "HopDongThuePhong";
            this.Text = "HopDongThuePhong";
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl7)).EndInit();
            this.panelControl7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            this.groupControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaHD.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datengay.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datengay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl4)).EndInit();
            this.panelControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridHD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl6)).EndInit();
            this.panelControl6.ResumeLayout(false);
            this.panelControl6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtmakhachThue.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtdiachi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttennguoithan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtsdt.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtnamsinh.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtcmnd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenkhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txthokhach.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl5)).EndInit();
            this.panelControl5.ResumeLayout(false);
            this.panelControl5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboGiaPhong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.combokhuphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.combotinhtrang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmanoiquy.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtghichu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtoaiphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txttenphong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtmaphong.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.PanelControl panelControl4;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.PanelControl panelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        public DevExpress.XtraEditors.TextEdit txtmaphong;
        public DevExpress.XtraEditors.TextEdit txtmanoiquy;
        public DevExpress.XtraEditors.TextEdit txtghichu;
        public DevExpress.XtraEditors.TextEdit txtoaiphong;
        public DevExpress.XtraEditors.TextEdit txttenphong;
        public DevExpress.XtraEditors.TextEdit comboGiaPhong;
        public DevExpress.XtraEditors.TextEdit combokhuphong;
        public DevExpress.XtraEditors.TextEdit combotinhtrang;
        private DevExpress.XtraEditors.PanelControl panelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TextEdit txthokhach;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtnamsinh;
        private DevExpress.XtraEditors.TextEdit txtcmnd;
        private DevExpress.XtraEditors.TextEdit txttenkhach;
        private DevExpress.XtraEditors.LabelControl lbcmnd;
        private DevExpress.XtraEditors.TextEdit txtsdt;
        private DevExpress.XtraEditors.LabelControl lnsdt;
        private DevExpress.XtraEditors.LabelControl lbnamsinh;
        private DevExpress.XtraEditors.TextEdit txtdiachi;
        private DevExpress.XtraEditors.TextEdit txttennguoithan;
        private DevExpress.XtraEditors.LabelControl lb1;
        private DevExpress.XtraEditors.LabelControl lb;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private System.Windows.Forms.ComboBox combomaLKhach;
        private DevExpress.XtraEditors.TextEdit txtmakhachThue;
        private System.Windows.Forms.Button btnthem;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.RadioButton Rnu;
        private System.Windows.Forms.RadioButton RNam;
        private DevExpress.XtraEditors.PanelControl panelControl7;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.SimpleButton simpleButton4;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        public DevExpress.XtraEditors.LabelControl labelnv;
        public DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.DateEdit datengay;
        private System.Windows.Forms.ComboBox comboNV;
        private DevExpress.XtraEditors.TextEdit txtmaHD;
        public DevExpress.XtraEditors.LabelControl labelControl16;
        private System.Windows.Forms.DataGridView GridHD;
    }
}