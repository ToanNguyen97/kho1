﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QuanLy_DoAn.FormAPP
{
    public partial class XtraReport1 : DevExpress.XtraReports.UI.XtraReport
    {
        public XtraReport1()
        {
            InitializeComponent();
        }
        public void BindData()
        {
            lbmaHD.DataBindings.Add("Text", DataSource, "MaHopDong");
            lbMaKhach.DataBindings.Add("Text", DataSource, "MaKhachThue");
            lbHoTen.DataBindings.Add("Text", DataSource, "HoTenKhachThue");
            lbTenP.DataBindings.Add("Text", DataSource, "TenPhong");
            lbLoaiP.DataBindings.Add("Text", DataSource, "TenLoaiPhong");
            lbKhuP.DataBindings.Add("Text", DataSource, "TenKhuPhong");
            lbGia.DataBindings.Add("Text", DataSource, "GiaPhong");
            lbngay.DataBindings.Add("Text", DataSource, "NgayLap").FormatString="{0:dd/MM/yyyy}";
            lbnv.DataBindings.Add("Text", DataSource, "HoTenNhanVien");
        }
    }
}
