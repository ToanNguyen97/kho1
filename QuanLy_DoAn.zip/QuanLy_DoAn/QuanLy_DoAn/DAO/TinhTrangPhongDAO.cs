﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
    public class TinhTrangPhongDAO
    {
        private static TinhTrangPhongDAO instance;

        public static TinhTrangPhongDAO Instance
        {
            get { if (instance == null) instance = new TinhTrangPhongDAO();
                return TinhTrangPhongDAO.instance; }
          private  set { TinhTrangPhongDAO.instance = value; }
        }
        private TinhTrangPhongDAO() { }
        public DataTable LoadCBTRINHTRANG()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM TinhTrangPhong");
        }
        public List<TinhTrangPhongDTO> LoadTRList()
        {
            List<TinhTrangPhongDTO> tablelist = new List<TinhTrangPhongDTO>();
            DataTable data = DataProvider.Instance.ExcuteQuery("SELECT * FROM TinhTrangPhong");
            foreach(DataRow item in data.Rows)
            {
                TinhTrangPhongDTO tr = new TinhTrangPhongDTO(item);
                tablelist.Add(tr);
            }
            return tablelist;
        }
        public String getTenByID(string ma)
        {
            List<TinhTrangPhongDTO> list = LoadTRList();
            for(int i = 0; i < list.Count ; i++)
            {
                if (list[i].MaTinhTrang.Equals(ma))
                    return list[i].TenTinhTrang;
            }
            return "";
        }
       
    }
}
