﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class HopDongThueDAO
    {
        private static HopDongThueDAO instance;

        public static HopDongThueDAO Instance
        {
            get { if (instance == null) instance = new HopDongThueDAO(); return HopDongThueDAO.instance; }
           private set { HopDongThueDAO.instance = value; }
        }
        private HopDongThueDAO() { }
        public DataTable LoadHD()
        {
            return DataProvider.Instance.ExcuteQuery("SELECT * FROM HopDongThue");
        }
        public void HopDongThem(HopDongThueDTO dtoHD)
        {
            string query = "HopDong_Them @MaHopDong , @MaKhachThue , @MaPhong , @NgayLap , @MaNhanVien";
            DataProvider.Instance.ExcuteNonQuery(query, new object[] { dtoHD.MaHopDong, dtoHD.MaKhachThue, dtoHD.MaPhong, dtoHD.NgayLap, dtoHD.MaNhanVien });
        }
    }
}
