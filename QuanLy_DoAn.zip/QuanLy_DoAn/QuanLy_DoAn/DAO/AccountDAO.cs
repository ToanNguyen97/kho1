﻿using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DAO
{
   public class AccountDAO
    {
        private static AccountDAO instance;

        public static AccountDAO Instance
        {
            get { if (instance == null) instance = new AccountDAO();
                    return AccountDAO.instance; }
           private set { AccountDAO.instance = value; }
        }
        private AccountDAO() { }
       public DataTable LoadTableAccount()
        {
            return DataProvider.Instance.ExcuteQuery("EXEC dbo.TaiKhoan_DS");
        }
       public List<AccountDTO> LoadListDS()
          {
              List<AccountDTO> tablelist = new List<AccountDTO>();
              DataTable data = DataProvider.Instance.ExcuteQuery("EXEC dbo.TaiKhoan_DS");
              foreach(DataRow item in data.Rows)
              {
                  AccountDTO acc = new AccountDTO(item);
                  tablelist.Add(acc);
              }
              return tablelist;

          }
       public void ThemACC(AccountDTO accdto)
         {
             String query = "TaiKhoan_Them @TenDangNhap , @TenHienThi , @MatKhau , @SoCMND , @MaNhanVien";
             DataProvider.Instance.ExcuteNonQuery(query, new object[]{accdto.TenDangNhap,accdto.TenHienThi,accdto.MatKhau,accdto.SoCMND,accdto.MaNhanVien});
         }
       public void SuaACC(AccountDTO accdto)
       {
           String query = "TaiKhoan_Sua @TenDangNhap , @TenHienThi , @MatKhau , @SoCMND , @MaNhanVien";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { accdto.TenDangNhap, accdto.TenHienThi, accdto.MatKhau, accdto.SoCMND, accdto.MaNhanVien });
       }
       public void XoaACC(AccountDTO accdto)
       {
           String query = "TaiKhoan_Xoa @TenDangNhap";
           DataProvider.Instance.ExcuteNonQuery(query, new object[] { accdto.TenDangNhap});
       }
    }
}
