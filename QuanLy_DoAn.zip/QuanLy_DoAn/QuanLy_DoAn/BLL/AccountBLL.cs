﻿using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.BLL
{
   public class AccountBLL
    {
        private static AccountBLL instance;

        public static AccountBLL Instance
        {
            get { if (instance == null) instance = new AccountBLL();
                return AccountBLL.instance; }
          private  set { AccountBLL.instance = value; }
        }
        public bool KiemtraLayMK(String tk, String cmnd , String tenhienthi) //Kiểm tra đăng nhập
        {
            if (tk == "")
            {
                XtraMessageBox.Show("Bạn phải nhập tên !!!");
            }
            else
            {
                if (tenhienthi == "")
                    XtraMessageBox.Show("Bạn Phải Nhập Tên Hiển Thị ");
                else
                {
                    if (cmnd == "")
                        XtraMessageBox.Show("Bạn Phải Nhập Số CMND ");
                    else
                    {
                        List<AccountDTO> listac = AccountDAO.Instance.LoadListDS();
                        for (int i = 0; i < listac.Count; i++)
                        {
                            if (listac[i].TenDangNhap.Equals(tk) && listac[i].SoCMND.Equals(cmnd))
                                return true;
                        }
                    }
                }
            }

            return false;
        }
       public bool Kiemtra(String tk , String pass ) //Kiểm tra đăng nhập
       {
           List<AccountDTO> listac = AccountDAO.Instance.LoadListDS();
           for (int i = 0; i < listac.Count; i++)
           {
               if (listac[i].TenDangNhap.Equals(tk) && listac[i].MatKhau.Equals(pass))
               {
                 
                   return true;
               }   
                 
           }
           return false;
       }
       public String GetTenByUserName(String name)
       {
           List<AccountDTO> listac = AccountDAO.Instance.LoadListDS();
           for (int i = 0; i < listac.Count; i++)
           {
               if (listac[i].TenDangNhap.Equals(name))
                   return listac[i].TenHienThi;

           }
           return "";
       }
       public void ThemACC(AccountDTO acdto,String xacnhan)
       {

           if (acdto.TenDangNhap == "")
           {
               XtraMessageBox.Show("Bạn phải nhập tên !!!");
           }
           else
           {
               if (acdto.MatKhau == "")
                   XtraMessageBox.Show("Bạn phải nhập mã !!");
               else
                   if (acdto.MatKhau != xacnhan)
                       XtraMessageBox.Show("Mã Xác nhận và mật khẩu không đúng!!!");
                   else
                   {
                       AccountDAO.Instance.ThemACC(acdto);
                       XtraMessageBox.Show("Thêm Thành Công!!");
                   }
           }
       }
       public void SuaACC(AccountDTO acdto,String xacnhan)
       {
           if (acdto.TenDangNhap == "")
           {
               XtraMessageBox.Show("Bạn phải nhập tên !!!");
           }
           else
           {
               if (acdto.TenHienThi == "")
                   XtraMessageBox.Show("Bạn Phải Nhập Tên Hiển Thị ");
               else {
                   if (acdto.SoCMND == "")
                       XtraMessageBox.Show("Bạn Phải Nhập Số CMND ");
                   else
                   {
                       if (acdto.MatKhau == "")
                           XtraMessageBox.Show("Bạn phải nhập mã !!");
                       else
                       { if (acdto.MatKhau != xacnhan)
                               XtraMessageBox.Show("Mã Xác nhận và mật khẩu không đúng!!!");
                           else
                           {
                               AccountDAO.Instance.SuaACC(acdto);
                               XtraMessageBox.Show("Thành Công!!");
                           }
                           }
                   }
               }
               
           }
       }
    }
}
