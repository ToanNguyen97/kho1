﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLy_DoAn.DTO
{
   public class LoaiPhongDTO
    {
        String maLoaiPhong, tenLoaiPhong;
       int  giaLoaiPhong;

        public int GiaLoaiPhong
        {
             get { return giaLoaiPhong; }
             set { giaLoaiPhong = value; }
        }
         public LoaiPhongDTO(DataRow row )
       {
          
             this.MaLoaiPhong  = row["MaLoaiPhong"].ToString();
            this.TenLoaiPhong  = row["TenLoaiPhong"].ToString();
            this.GiaLoaiPhong  = (int)row["GiaPhong"];
       }
        public LoaiPhongDTO(string ma, string ten ,int gia)
        {
            this.MaLoaiPhong = ma;
            this.TenLoaiPhong = ten;
            this.GiaLoaiPhong = gia;
        }

        public String MaLoaiPhong
        {
            get { return maLoaiPhong; }
            set { maLoaiPhong = value; }
        }

        public String TenLoaiPhong
        {
            get { return tenLoaiPhong; }
            set { tenLoaiPhong = value; }
        }

       
    }
}
