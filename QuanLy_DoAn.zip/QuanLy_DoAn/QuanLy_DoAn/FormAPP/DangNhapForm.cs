﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DTO;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.BLL;

namespace QuanLy_DoAn.FormAPP
{
    public partial class DangNhapForm : DevExpress.XtraEditors.XtraForm
    {
        public DangNhapForm()
        {
            InitializeComponent();
            
        }
        private void btnlogin_Click(object sender, EventArgs e)
        {

            if (txtlogin.Text == "")
            {
                XtraMessageBox.Show("Vui lòng nhập tên tài khoản !!");

            }
            else
            {
                if (txtmatkhau.Text == "")
                {
                    XtraMessageBox.Show("Vui lòng nhập mật khẩu !");

                }
                else
                {
                    try
                    {

                        if (AccountBLL.Instance.Kiemtra(txtlogin.Text, txtmatkhau.Text) == true )// && txtlogin.Text.Equals("Admin"))
                        {
                            XtraMessageBox.Show("Đăng Nhập Thành Công!!!");
                            Form1 frm = new Form1();
                            frm.Show();
                            frm.lbUser.Text = "User Hiện Tại : " + AccountBLL.Instance.GetTenByUserName(txtlogin.Text);
                            this.Close();
                        }
                        else
                        {
                            XtraMessageBox.Show("Đăng Nhập Thất Bại !!");
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
            }
        }

        private void btnthoat_Click(object sender, EventArgs e)
        {
              if ( XtraMessageBox.Show("Bạn có chắc chắn muốn thoát ?", "Thông Báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.OK)
              {
                  this.Close();
                  new Form1().ShowDialog();
              }
        }

        private void checkEdit1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void checkmk_MouseClick(object sender, MouseEventArgs e)
        {
            if (checkmk.Checked == false)
            {
                txtmatkhau.Properties.UseSystemPasswordChar = false;
            }
            else
            {
                txtmatkhau.Properties.UseSystemPasswordChar = true;
            }
        }

        private void hyperlinkLabelControl1_Click(object sender, EventArgs e)
        {
            new DangKyForm().ShowDialog();
        }

        private void hyperlinkLabelControl2_Click(object sender, EventArgs e)
        {
            new QuenMKForm().ShowDialog();
        }
    }
}