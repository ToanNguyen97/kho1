﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class KhachThueForm : DevExpress.XtraEditors.XtraForm
    {
        public KhachThueForm()
        {
            InitializeComponent();
            Load();
        }
        private void Load()
        {
            GridKH.DataSource = KhachThueDAO.Instance.KhachThue_DS();
            GridKH.Columns[8].Width = 135;
            comboLoaikhach.DataSource = KhachThueDAO.Instance.LoaiKhachThue_DS();
            comboLoaikhach.DisplayMember = "TenLoaiKhach";
            comboLoaikhach.ValueMember = "MaLoaiKhach";
        }

        private void btnthem_Click(object sender, EventArgs e)
        {
            try {
                int gt;
                if (RNam.Checked)
                    gt = 1;
                else
                    gt = 0;
                KhachThueDTO khachdto = new KhachThueDTO(txtmakhach.Text,txthokhach.Text,txttenkhach.Text,txtcmnd.Text,txtnamsinh.Text,gt,txtsdt.Text,txttennguoithan.Text,txtdiachi.Text,comboLoaikhach.SelectedValue.ToString());
                KhachThueDAO.Instance.KhachThue_Them(khachdto);
                GridKH.DataSource = KhachThueDAO.Instance.KhachThue_DS();
                XtraMessageBox.Show("Thành Công!!!");
            }catch(Exception ex)
            { }

        }

        private void GridKH_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtmakhach.Text = GridKH.CurrentRow.Cells[0].Value.ToString();
            txthokhach.Text = GridKH.CurrentRow.Cells[1].Value.ToString();
            txttenkhach.Text = GridKH.CurrentRow.Cells[2].Value.ToString();
            txtcmnd.Text = GridKH.CurrentRow.Cells[3].Value.ToString();
            txtnamsinh.Text = GridKH.CurrentRow.Cells[4].Value.ToString();
            if(GridKH.CurrentRow.Cells[5].Value.ToString().Equals("Nam"))
                RNam.Checked = true;
            else
                Rnu.Checked = true;
            txtsdt.Text = GridKH.CurrentRow.Cells[6].Value.ToString();
            txttennguoithan.Text = GridKH.CurrentRow.Cells[7].Value.ToString();
            txtdiachi.Text = GridKH.CurrentRow.Cells[8].Value.ToString();
            comboLoaikhach.SelectedValue = GridKH.CurrentRow.Cells[9].Value.ToString();
        }

        private void btnsua_Click(object sender, EventArgs e)
        {
            try
            {
                int gt;
                if (RNam.Checked)
                    gt = 1;
                else
                    gt = 0;
                KhachThueDTO khachdto = new KhachThueDTO(txtmakhach.Text, txthokhach.Text, txttenkhach.Text, txtcmnd.Text, txtnamsinh.Text, gt, txtsdt.Text, txttennguoithan.Text, txtdiachi.Text, comboLoaikhach.SelectedValue.ToString());
                KhachThueDAO.Instance.KhachThue_Sưa(khachdto);
                GridKH.DataSource = KhachThueDAO.Instance.KhachThue_DS();
                XtraMessageBox.Show("Thành Công!!!");
            }
            catch (Exception ex)
            { }
        }

        private void btnxoa_Click(object sender, EventArgs e)
        {
            KhachThueDTO khachdto = new KhachThueDTO(txtmakhach.Text);
            KhachThueDAO.Instance.KhachThue_Xoa(khachdto);
            GridKH.DataSource = KhachThueDAO.Instance.KhachThue_DS();
            XtraMessageBox.Show("Thành Công!!!");
        }

        private void panelControl3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lnsdt_Click(object sender, EventArgs e)
        {

        }

        private void txtsdt_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void lbnamsinh_Click(object sender, EventArgs e)
        {

        }
    }
}