﻿using DevExpress.XtraBars.Helpers;
using QuanLy_DoAn.FormAPP;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace QuanLy_DoAn
{
    public partial class Form1 : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        public Form1()
        {
            InitializeComponent();
            labledate.Text = "Ngày : " + System.DateTime.Now.ToShortDateString();
            labeltime.Text = "Giờ: " + System.DateTime.Now.ToLongTimeString();
           // timer1_Tick( sender,  e);   
           
        }
        private Form KiemTraTonTai(Type fType)
        {
            foreach (Form f in this.MdiChildren)
            {
                if (f.GetType() == fType)    // Neu Form duoc truyen vao da duoc mo
                {
                    return f;
                }
            }
            return null;
        }
        private void btnlogin_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DangNhapForm frm = new DangNhapForm();
            this.Hide();      
            frm.ShowDialog();
              
        }

        private void hideContainerLeft_Click(object sender, EventArgs e)
        {

        }

        private void dockPanel1_Click(object sender, EventArgs e)
        {

        }

        private void btntaikhoan_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
             Form frm = this.KiemTraTonTai(typeof(TaiKhoanForm));
            if (frm != null)
                frm.Activate();
            else
            {
                TaiKhoanForm f = new TaiKhoanForm();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void labelControl1_Click(object sender, EventArgs e)
        {
          
        }

        private void labledate_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            labeltime.Text = "Giờ: " + System.DateTime.Now.ToLongTimeString();
        }
    }
}
