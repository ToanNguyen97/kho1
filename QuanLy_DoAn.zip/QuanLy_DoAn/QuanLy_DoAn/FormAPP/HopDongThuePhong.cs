﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class HopDongThuePhong : DevExpress.XtraEditors.XtraForm
    {
        public HopDongThuePhong()
        {
            InitializeComponent();
            Load();
            Form1 frm = new Form1();
            datengay.Text = System.DateTime.Now.ToShortDateString();
        }
        
        private void Load()
        {
            GridHD.DataSource = HopDongThueDAO.Instance.LoadHD();
            combomaLKhach.DataSource = KhachThueDAO.Instance.LoaiKhachThue_DS();
            combomaLKhach.DisplayMember = "TenLoaiKhach";
            combomaLKhach.ValueMember = "MaLoaiKhach";
            comboNV.DataSource = NhanVienDAO.Instance.LoadNV();
            comboNV.DisplayMember = "HoTenNhanVien";
            comboNV.ValueMember = "MaNhanVien";
        }

        private void txtmakhach_EditValueChanged(object sender, EventArgs e)
        {


        }

        private void comboKH_SelectedIndexChanged(object sender, EventArgs e)
        {
        

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int gt;
                if (RNam.Checked)
                    gt = 1;
                else
                    gt = 0;
                KhachThueDTO khachdto = new KhachThueDTO(txtmakhachThue.Text, txthokhach.Text, txttenkhach.Text, txtcmnd.Text, txtnamsinh.Text, gt, txtsdt.Text, txttennguoithan.Text, txtdiachi.Text, combomaLKhach.SelectedValue.ToString());
                KhachThueDAO.Instance.KhachThue_Them(khachdto);
                
                XtraMessageBox.Show("Thành Công!!!");
            }
            catch (Exception ex)
            { }
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            try {
                HopDongThueDTO hd = new HopDongThueDTO(txtmaHD.Text, txtmakhachThue.Text, txtmaphong.Text, datengay.Text, comboNV.SelectedValue.ToString());
                HopDongThueDAO.Instance.HopDongThem(hd);
                GridHD.DataSource = HopDongThueDAO.Instance.LoadHD();
                XtraMessageBox.Show("Thành Công!! Hợp tác vui vẻ !!");
            }catch(Exception ex)
            {

            }
        }
    }
}