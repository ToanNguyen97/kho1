﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.DAO;
using QuanLy_DoAn.DTO;
using QuanLy_DoAn.BLL;

namespace QuanLy_DoAn.FormAPP
{
    public partial class TaiKhoanForm : DevExpress.XtraEditors.XtraForm
    {
        public TaiKhoanForm()
        {
            InitializeComponent();
            Load();
            
        }
        private void Load()
        {
            GridTK.DataSource = AccountDAO.Instance.LoadTableAccount();
            GridTK.Columns[0].Width = 135;
            lookNV.DataSource = NhanVienDAO.Instance.LoadNV();
            lookNV.DisplayMember = "HoTenNhanVien";
            lookNV.ValueMember = "MaNhanVien";
        }
        private void GridTK_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void simpleButton1_Click(object sender, EventArgs e) // Thêm Tài Khoản
        {
            try
            {
                AccountDTO accdto = new AccountDTO(txtenlogin.Text, txttenhienthi.Text, txtpass.Text, txtcmnd.Text, lookNV.SelectedValue.ToString());
                AccountBLL.Instance.ThemACC(accdto,txtxacnhan.Text);              
                Load();
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Thêm Thất Bại!!");
            }
        }

        private void GridTK_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtenlogin.Text = GridTK.CurrentRow.Cells[0].Value.ToString();
            txttenhienthi.Text = GridTK.CurrentRow.Cells[1].Value.ToString();
            txtpass.Text = GridTK.CurrentRow.Cells[2].Value.ToString();
            txtcmnd.Text = GridTK.CurrentRow.Cells[3].Value.ToString();
            lookNV.SelectedValue = GridTK.CurrentRow.Cells[4].Value.ToString();
        }

        private void simpleButton2_Click(object sender, EventArgs e) // Sửa Tài Khoản
        {
            try
            {
                AccountDTO accdto = new AccountDTO(txtenlogin.Text, txttenhienthi.Text, txtpass.Text, txtcmnd.Text, lookNV.SelectedValue.ToString());
                AccountBLL.Instance.SuaACC(accdto,txtxacnhan.Text);
                XtraMessageBox.Show("Sửa Thành Công!!");
                Load();
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Sửa Thất Bại!!");
            }
        }

        private void simpleButton3_Click(object sender, EventArgs e) // Xóa
        {
            try
            {
                AccountDTO accdto = new AccountDTO(txtenlogin.Text);
                AccountDAO.Instance.XoaACC(accdto);
                XtraMessageBox.Show("Xóa Thành Công!!");
                Load();
            }
            catch (Exception ex)
            {
                XtraMessageBox.Show("Xóa Thất Bại!!");
            }
        }

        private void lookNV_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}