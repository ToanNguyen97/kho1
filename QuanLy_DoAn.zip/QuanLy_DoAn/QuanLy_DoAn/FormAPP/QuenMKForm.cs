﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using QuanLy_DoAn.BLL;
using QuanLy_DoAn.DTO;
using QuanLy_DoAn.DAO;

namespace QuanLy_DoAn.FormAPP
{
    public partial class QuenMKForm : DevExpress.XtraEditors.XtraForm
    {
        public QuenMKForm()
        {
            InitializeComponent();
            Panelmk.Visible = false;
            Load();
        }
        private void Load()
        {
            comboNV.DataSource = NhanVienDAO.Instance.LoadNV();
            comboNV.DisplayMember = "HoTenNhanVien";
            comboNV.ValueMember = "MaNhanVien";
        }
        private void simpleButton1_Click(object sender, EventArgs e) //Kiểm tra tài khoản và cmnd có đúng hay không
        {
            try {
                if (AccountBLL.Instance.KiemtraLayMK(txtendangnhap.Text, txtcmnd.Text,txttenhienthi.Text) == true)
                {
                    Panelmk.Visible = true;
                    XtraMessageBox.Show("Mở thành công!!");
                }
                else
                {
                    XtraMessageBox.Show("Rất tiếc có thông tin không khớp!!");
                }
            }catch(Exception ex)
            {
                XtraMessageBox.Show("thất bại!!");
            }
            
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            try { 
                AccountDTO accdto = new AccountDTO(txtendangnhap.Text,txttenhienthi.Text,txtmatkhau.Text,txtcmnd.Text,comboNV.SelectedValue.ToString());
                AccountBLL.Instance.SuaACC(accdto, txtxacnhan.Text);
            }catch(Exception ex)
            {
                XtraMessageBox.Show("Thất Bại!!");
            }
        }// sửa mật khẩu nếu btnkiemtra đúng

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if ( XtraMessageBox.Show("Bạn có muốn xóa ?", "Thông Báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == System.Windows.Forms.DialogResult.OK)
            {    txtendangnhap.Text = "";
                 txttenhienthi.Text = "";
                 txtcmnd.Text = "";
                 txtmatkhau.Text = "";
                 txtxacnhan.Text = "";
            }
        } 

    }
}